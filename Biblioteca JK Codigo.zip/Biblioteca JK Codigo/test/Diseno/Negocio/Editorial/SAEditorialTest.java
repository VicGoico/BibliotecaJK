package Diseno.Negocio.Editorial;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import Diseno.Negocio.Editorial.SAEditorialImp;
import Diseno.Negocio.Editorial.TEditorial;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class SAEditorialTest
{
	private TEditorial tEditorial;
	private SAEditorialImp saEditorial;
	
	@Before
	public void setUp() throws Exception
	{
		this.saEditorial = new SAEditorialImp();
		this.tEditorial = new TEditorial("Editorial Test 4", "Calle Test 45 2", true, 0);	
	}

	@Test
	public void testAltaEditorial()
	{
		int altaKO = -1;
		int res = this.saEditorial.altaEditorial(tEditorial);
		
		if(res != altaKO)
			assertNotEquals(res, altaKO);
		else
			assertEquals(res, altaKO);
	}

	@Test
	public void testBajaEditorial() 
	{
		int bajaKO = -1;
		int res = this.saEditorial.bajaEditorial(5);
		
		if(res != bajaKO)
			assertNotEquals(res, bajaKO);
		else
			assertEquals(res, bajaKO);
	}

	@Test
	public void testactualizarEditorial()
	{
		int actKO = -1;
		this.tEditorial.setNombre("Editorial Test Actualizar 1");
		this.tEditorial.setIdEditorial(2);
		int res = this.saEditorial.actualizarEditorial(tEditorial);
		
		if(res != actKO)
			assertNotEquals(res, actKO);
		else
			assertEquals(res, actKO);
	}

	@Test
	public void testBuscarEditorial()
	{
		TEditorial tEd = this.saEditorial.buscarEditorial(2);
		
		if(tEd != null)
			assertNotEquals(tEd, null);
		else
			assertEquals(tEd, null);
	}

	@Test
	public void testMostrarEditoriales()
	{
		ArrayList<TEditorial> editoriales = this.saEditorial.mostrarEditoriales();
		
		if(editoriales != null)
			assertNotEquals(editoriales, null);
		else
			assertEquals(editoriales, null);
	}

}
