package Diseno.Negocio.Libro;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class SALibroTest 
{
	private SALibroImp saLibro;
	private TLibroLiteratura tLibroLit1, tLibroLit2;
	private TLibroTexto tLibroTexto1, tLibroTexto2;
	
	@Before
	public void setUp() throws Exception
	{
		this.saLibro = new SALibroImp();
		
		this.tLibroLit1 = new TLibroLiteratura("Harry Potter 8", "JK Rowling", "9186736455264", 390, 50, 0, 6, true, Genero.CIENCIA_FICCION);
		this.tLibroTexto1 = new TLibroTexto("Ejercicios propuestos MDL", "Miguel", "8907462635363", 84, 34, 0, 2, true, Asignatura.MDL);
		
		this.tLibroLit2 = new TLibroLiteratura("Animales Fantasticos", "JK Rowling", "9189936452474", 680, 10, 0, 6, true, Genero.CIENCIA_FICCION);
		this.tLibroTexto2 = new TLibroTexto("Examenes FP", "Gerardo", "8982473415363", 94, 4, 0, 2, true, Asignatura.FP);
	}

	@Test
	public void testAltaLibroLiteratura()
	{
		int altaLitKO1 = -1;
		int resLit1 = this.saLibro.altaLibro(tLibroLit1);
		
		if(resLit1 != altaLitKO1)
			assertNotEquals(resLit1, altaLitKO1);
		else
			assertEquals(resLit1, altaLitKO1);
		
		int altaLitKO2 = -1;
		int resLit2 = this.saLibro.altaLibro(tLibroLit2);
		
		if(resLit2 != altaLitKO2)
			assertNotEquals(resLit2, altaLitKO2);
		else
			assertEquals(resLit2, altaLitKO2);
	}

	@Test
	public void testAltaLibroTexto()
	{
		int altaTextoKO1 = -1;
		int resTexto1 = this.saLibro.altaLibro(tLibroTexto1);
		
		if(resTexto1 != altaTextoKO1)
			assertNotEquals(resTexto1, altaTextoKO1);
		else
			assertEquals(resTexto1, altaTextoKO1);
		
		int altaTextoKO2 = -1;
		int resTexto2 = this.saLibro.altaLibro(tLibroTexto2);
		
		if(resTexto2 != altaTextoKO2)
			assertNotEquals(resTexto2, altaTextoKO2);
		else
			assertEquals(resTexto2, altaTextoKO2);
	}
	
	@Test
	public void testBajaLibroLiteratura()
	{
		int bajaLitKO = -1;
		int resLit = this.saLibro.bajaLibro(8);
		
		if(resLit != bajaLitKO)
			assertNotEquals(resLit, bajaLitKO);
		else
			assertEquals(resLit, bajaLitKO);
	}

	@Test
	public void testBajaLibroTexto()
	{
		int bajaTextoKO = -1;
		int resTexto = this.saLibro.bajaLibro(9);
		
		if(resTexto != bajaTextoKO)
			assertNotEquals(resTexto, bajaTextoKO);
		else
			assertEquals(resTexto, bajaTextoKO);
	}
	
	@Test
	public void testActualizarLibroLiteratura()
	{
		int actLitKO = -1;
		this.tLibroLit2.setTitulo("Animales Fantasticos 2");
		int resActLit = this.saLibro.actualizarLibro(this.tLibroLit2);
		
		if(resActLit != actLitKO)
			assertNotEquals(resActLit, actLitKO);
		else
			assertEquals(resActLit, actLitKO);
	}

	@Test
	public void testActualizarLibroTexto() 
	{
		int actLitKO = -1;
		this.tLibroTexto2.setTitulo("Examenes propuestos FP");
		int resActLit = this.saLibro.actualizarLibro(this.tLibroTexto2);
		
		if(resActLit != actLitKO)
			assertNotEquals(resActLit, actLitKO);
		else
			assertEquals(resActLit, actLitKO);
	}
	
	@Test
	public void testBuscarLibro() 
	{	
		TLibro tLibro = this.saLibro.buscarLibro(2);
		
		if(tLibro != null)
			assertNotEquals(tLibro, null);
		else
			assertEquals(tLibro, null);
	}

	@Test
	public void testMostrarLibros() 
	{
		ArrayList<TLibro> libros = this.saLibro.mostrarLibros();
		
		if(libros != null)
			assertNotEquals(libros, null);
		else
			assertEquals(libros, null);
	}

	@Test
	public void testBuscarPorAutor() 
	{
		ArrayList<TLibro> libros = this.saLibro.buscarPorAutor("JK Rowling");
		
		if(libros != null)
			assertNotEquals(libros, null);
		else
			assertEquals(libros, null);
	}

	@Test
	public void testBuscarPorISBN()
	{
		TLibro tLibro = this.saLibro.buscarPorISBN("8960473415363");
		
		if(tLibro != null)
			assertNotEquals(tLibro, null);
		else
			assertEquals(tLibro, null);
	}

}
