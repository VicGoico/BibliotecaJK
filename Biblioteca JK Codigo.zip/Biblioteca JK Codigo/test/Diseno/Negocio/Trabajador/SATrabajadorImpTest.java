package Diseno.Negocio.Trabajador;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import Diseno.Negocio.Curso.SACursoImp;
import Diseno.Negocio.Curso.TCurso;
import Diseno.Negocio.Curso.TCursoADistancia;
import Diseno.Negocio.Curso.TCursoPresencial;

public class SATrabajadorImpTest {

	private SATrabajadorImp saTrabajador;
	
	private TTrabajador tTrabajador1, tTrabajador2, tTrabajador3, tTrabajador4;
	private TMatricula matricula1, matricula2;
	
	@Before
	public void setUp() throws Exception {
		this.tTrabajador1 = new TTrabajador("Manolo","Garcia", "12345678A", "Jefe1", 123.0, true);
		this.tTrabajador2 = new TTrabajador("Pepe","Garcia", "12345678B", "Jefe2", 123.0, true);
		this.tTrabajador3 = new TTrabajador("Ramon","Garcia", "12345678C", "Jefe3", 123.0, true);
		// Trabajador dado de baja
		this.tTrabajador4 = new TTrabajador("Miguel","Garcia", "12345678D", "Jefe4", 123.0, true);
		
		this.matricula1 = new TMatricula(1, 1, true);
		this.matricula2 = new TMatricula(2, 2, true);
		
		this.saTrabajador = new SATrabajadorImp();
		
	}

	@Test
	public void testAltaTrabajador() {
		assertEquals(this.saTrabajador.altaTrabajador(this.tTrabajador1), 1);
		assertEquals(this.saTrabajador.altaTrabajador(this.tTrabajador2), 2);
		assertEquals(this.saTrabajador.altaTrabajador(this.tTrabajador3), 3);
		// Intento dar de alta un trabajador que ya existe, y me salta error
		assertEquals(this.saTrabajador.altaTrabajador(this.tTrabajador1), -3);
	}

	@Test
	public void testBuscarTrabajador() {
		assertNotNull(this.saTrabajador.buscarTrabajador(1));
		// Busco un trabajador con id 6, que no existe 
		assertNull(this.saTrabajador.buscarTrabajador(6));
	}

	@Test
	public void testMostrarTrabajadores() {
		assertNotNull(this.saTrabajador.mostrarTrabajadores());
	}

	@Test
	public void testActualizarTrabajador() {
		// No existe el id en la BBDD
		assertEquals(this.saTrabajador.actualizarTrabajador(this.tTrabajador4), -3);
		// El id es valido, pero el trabajador no esta activo
		this.tTrabajador3.setId(3);
		assertEquals(this.saTrabajador.actualizarTrabajador(this.tTrabajador3), -4);
		// Caso valido
		this.tTrabajador1.setId(1);
		this.tTrabajador1.setApellido("Gonzalez");
		this.tTrabajador1.setCargo("BOSS FINAL");
		assertEquals(this.saTrabajador.actualizarTrabajador(this.tTrabajador1), 1);
	}

	@Test
	public void testBajaTrabajador() {
		assertEquals(this.saTrabajador.bajaTrabajador(2), 2);
		assertEquals(this.saTrabajador.bajaTrabajador(3), 3);
		// Reactivo el trabajdor 2
		assertEquals(this.saTrabajador.altaTrabajador(this.tTrabajador2), 2);
	}

	@Test
	public void testMatricularse() {
		assertEquals(this.saTrabajador.matricularse(matricula1), 2);
		assertEquals(this.saTrabajador.matricularse(matricula2), 4);
	}

	@Test
	public void testMostrarMatricular() {
		assertNotNull(this.saTrabajador.mostrarMatricular());
	}

	@Test
	public void testDesmatricularse() {
		assertEquals(this.saTrabajador.desmatricularse(matricula2), 4);
	}

}
