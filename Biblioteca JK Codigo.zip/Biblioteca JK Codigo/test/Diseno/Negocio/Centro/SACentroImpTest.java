package Diseno.Negocio.Centro;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import Diseno.Negocio.Curso.SACursoImp;
import Diseno.Negocio.Curso.TCursoPresencial;

public class SACentroImpTest {

	private TCentro tCentro1, tCentro2, tCentro3, tCentro4;
	private SACentroImp saCentro;
	private TCursoPresencial tCursoPresencial; 
	private SACursoImp saCurso;

	@SuppressWarnings("deprecation")
	@Before
	public void setUp() throws Exception {
		this.tCentro1 = new TCentro("Centro 1", "Calle 1", 0, true);
		this.tCentro2 = new TCentro("Centro 2", "Calle 2", 0, true);
		this.tCentro3 = new TCentro("Centro 3", "Calle 3", 0, true);
		this.tCentro4 = new TCentro("Centro 4", "Calle 4", 0, true);
		this.tCursoPresencial = new TCursoPresencial("Curso 1", "MMI", new Date(2018, 10, 11),
									new Date(2018, 11, 20), 15, 50.0, 10, 1, true, 1, 2.0);
		this.saCentro = new SACentroImp();
		this.saCurso = new SACursoImp();
	}
/*
	@Test
	public void testAltaCentro() {
		assertEquals(saCentro.altaCentro(tCentro1), 1);
		assertEquals(saCentro.altaCentro(tCentro2), 2);
		assertEquals(saCentro.altaCentro(tCentro3), 3);
		assertEquals(saCentro.altaCentro(tCentro1), -2);

	}

	@Test
	public void testBajaCentro() {
		assertEquals(saCentro.bajaCentro(2), 2);
		assertEquals(saCentro.bajaCentro(3), 3);
		//Reactivo el centro 2
		assertEquals(saCentro.altaCentro(tCentro2), 2);
	}
	
	@Test
	public void testActualizarCentro() {
		// No existe el id en la BBDD
		this.tCentro4.setIdCentro(6);
		assertEquals(saCentro.actualizarCentro(tCentro4), -2);
		// El id es valido, pero el centro no esta activo
		this.tCentro3.setIdCentro(3);
		assertEquals(saCentro.actualizarCentro(tCentro3), -3);
		// Caso valido
		this.tCentro1.setIdCentro(1);
		this.tCentro1.setDireccion("Plaza 1");
		this.tCentro1.setNombre("Centro act 1");
		assertEquals(saCentro.actualizarCentro(tCentro1), 1);
	}

	@Test
	public void testBuscarCentro() {
		assertNotNull(saCentro.buscarCentro(1));
		assertNull(saCentro.buscarCentro(6));
	}

	@Test
	public void testMostrarCentros() {
		assertNotNull(saCentro.mostrarCentros());
	}
*/
	@Test
	public void testCalcularCosteCursos() {
		// No existe el id en la BBDD
		assertEquals(saCentro.calcularCosteCursos(4), -2);
		// El id es valido, pero el centro no esta activo
		assertEquals(saCentro.calcularCosteCursos(3), -3);
		// El id es valido, pero el centro no tiene cursos asociados
		assertEquals(saCentro.calcularCosteCursos(1), -4);
		// Caso valido
		this.saCurso.altaCurso(tCursoPresencial);
		assertEquals(saCentro.calcularCosteCursos(1), 52);
	}

}
