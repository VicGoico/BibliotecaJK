package Diseno.Negocio.Cliente;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import Diseno.Negocio.Editorial.SAEditorialImp;
import Diseno.Negocio.Editorial.TEditorial;
import Diseno.Negocio.Libro.Genero;
import Diseno.Negocio.Libro.SALibroImp;
import Diseno.Negocio.Libro.TLibroLiteratura;

public class SAClienteImpTest {
		private TCliente tcliAltaOK;
		private TCliente tcliAltaKO;
		private TCliente tcliConID;
		
		private TPrestamo tPresID;
		
		private TLibroEditorial tLibroEdit;
		
		private TGeneroPaginas tGP;
		
		private SAClienteImp saClien;
		@Before
		public void setUp() throws Exception {
			this.saClien = new SAClienteImp();
			
			this.tcliAltaOK = new TCliente("pepito", "grillo", "12345678D", "12345", "pepitoGrillo@gmail.com", 123456789, true);
			this.tcliAltaKO = new TCliente("pepito", "grillo", "12345678D", "12345", "pepitoGrillo@gmail.com", 123456789, true);
			
			
			
			this.tcliConID = new TCliente(7, "pepito2", "grillo", "12345778D", "12445", "pepitoGrillo@gmail.com", 123456789, true);
			
			
			
			
			SAEditorialImp saEdi = new SAEditorialImp();
			TEditorial edi = new TEditorial("nombre", "direccion", true, 0);
			edi.setIdEditorial(saEdi.altaEditorial(edi));
			
			//TLibro libro = new TLibro(1, "Como hacer un buen JUnit", "manolo" ,"1234567891234", 200, 2, 0, edi.getIdEditorial(), true);
			TLibroLiteratura libroLi = new TLibroLiteratura(1, "Como hacer un buen JUnit", "manolo" ,"1234567891234", 200, 2, 0, edi.getIdEditorial(), true, Genero.AVENTURA);
			SALibroImp saLibro= new SALibroImp();
			
			libroLi.setID(saLibro.altaLibro(libroLi));
			
			Date FechaI = new Date();
			FechaI.setYear(2012);
			FechaI.setMonth(10);
			FechaI.setDate(10);
			
			Date FechaF = new Date();
			FechaF.setYear(2012);
			FechaF.setMonth(10);
			FechaF.setDate(12);
			
			this.tPresID = new TPrestamo(this.tcliConID.getIdCliente(), libroLi.getID(), FechaI, FechaF, true);
			
			this.tLibroEdit = new TLibroEditorial(edi.getIdEditorial(), 2);
			
			this.tGP = new TGeneroPaginas(Genero.AVENTURA, 200);
			
		}



	@Test
	public void testAltaCliente() {
		int altaKO = -1, falloReactivacion = -5, falloBBDD = -100;
		int res = this.saClien.altaCliente(this.tcliAltaOK);
		if(res == falloReactivacion){
			// Meto un cliente ya existente (Reactivacion)
			res = this.saClien.altaCliente(this.tcliAltaKO);
			assertEquals(res, falloReactivacion);
			assertNotEquals(res, altaKO);
			assertNotEquals(res, falloBBDD);
		}
		else{// Meto un caso en el que el cliente no existe en la base de datos y no tiene que salir ningun fallo
			assertNotEquals(res, altaKO);
			assertNotEquals(res, falloReactivacion);
			assertNotEquals(res, falloBBDD);
		}	
	}

	@Test
	public void testBajaCliente() {
		int bajaKO = -1, noExisteID = -2, clienteDadoDeBaja = -3, falloBBDD = -100;
		// Metemos un cliente que damos bien de baja
		
		int res = this.saClien.bajaCliente(2);
		if(res == 2){
			assertNotEquals(res, bajaKO);
			assertNotEquals(res, noExisteID);
			assertNotEquals(res, clienteDadoDeBaja);
			assertNotEquals(res, falloBBDD);
		}
		else if(res == clienteDadoDeBaja){	
			//Metemos un cliente que esta dado de baja
			assertNotEquals(res, bajaKO);
			assertNotEquals(res, noExisteID);
			assertEquals(res, clienteDadoDeBaja);
			assertNotEquals(res, falloBBDD);
		}
		// Metemos un cliente que no existe
		res = this.saClien.bajaCliente(100);
		assertNotEquals(res, bajaKO);
		assertEquals(res, noExisteID);
		assertNotEquals(res, clienteDadoDeBaja);
		assertNotEquals(res, falloBBDD);
	}

	

	@Test
	public void testBuscarCliente() {
		TCliente res = this.saClien.buscarCliente(this.tcliConID.getIdCliente());
		if(res == null){// No existe el cliente con ese id
			assertEquals(res, null);
		}
		else{// Existe el cliente con ese id
			assertNotEquals(res, null);
		}
	}

	@Test
	public void testMostrarPrestamos() {
		ArrayList<TPrestamo> lista = this.saClien.mostrarPrestamos();
		if(lista == null){
			assertEquals(lista, null);
		}
		else{
			assertNotEquals(lista, null);
		}
	}

	@Test
	public void testMostrarClientes() {
		ArrayList<TCliente> lista = this.saClien.mostrarClientes();
		if(lista == null){
			assertEquals(lista, null);
		}
		else{
			assertNotEquals(lista, null);
		}
	}


	@Test
	public void testDevolverPrestamo() {
		boolean res = this.saClien.devolverPrestamo(this.tPresID);
		if(res){
			assertEquals(res, true);
		}
		else{
			assertNotEquals(res, true);
		}
	}

	@Test
	public void testClientesAlMenosNLibrosDeUnaEditorial() {
		ArrayList<TCliente> lista = this.saClien.clientesAlMenosNLibrosDeUnaEditorial(this.tLibroEdit);
		if(lista == null){
			assertEquals(lista, null);
		}
		else{
			assertNotEquals(lista, null);
		}
	}

	@Test
	public void testClientesConLibrosDeUnGeneroYNPaginas() {
		ArrayList<TCliente> lista = this.saClien.clientesConLibrosDeUnGeneroYNPaginas(this.tGP);
		if(lista == null){
			assertEquals(lista, null);
		}
		else{
			assertNotEquals(lista, null);
		}
	}

}
