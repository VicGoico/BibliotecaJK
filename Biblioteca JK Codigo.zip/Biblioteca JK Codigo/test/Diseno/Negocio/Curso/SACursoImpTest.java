package Diseno.Negocio.Curso;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import Diseno.Negocio.Centro.SACentroImp;
import Diseno.Negocio.Centro.TCentro;

public class SACursoImpTest {

	private SACursoImp saCurso;
	private SACentroImp saCentro;
	private TCursoPresencial cPres1, cPres2, cPres3;
	private TCursoADistancia cDist1, cDist2, cDist3;
	private TCentro tCentro1, tCentro2, tCentro3;
	
	@Before
	public void setUp() throws Exception {
		this.saCurso = new SACursoImp();
		this.saCentro = new SACentroImp();
		
		this.tCentro1 = new TCentro("Centro 1", "Calle 1", 0, true);
		this.tCentro2 = new TCentro("Centro 2", "Calle 2", 0, true);
		this.tCentro3 = new TCentro("Centro 3", "Calle 3", 0, true);
		
		this.cPres1 = new TCursoPresencial("C Pres 1", "Curso Presencial 1", new Date(2018, 10, 10), new Date(2018, 10, 20), 10, 50.0, 0, 1, true, 1, 1.5);
		this.cPres2 = new TCursoPresencial("C Pres 2", "Curso Presencial 2", new Date(2018, 10, 10), new Date(2018, 10, 20), 20, 45.0, 15, 1, true, 1, 1.5);
		this.cPres3 = new TCursoPresencial("C Pres 3", "Curso Presencial 3", new Date(2018, 10, 10), new Date(2018, 10, 20), 15, 35.0, 12, 1, true, 1, 1.5);
		
		this.cDist1 = new TCursoADistancia("C Dist 1", "Curso Distancia 1", new Date(2018, 10, 10), new Date(2018, 10, 20), 10, 60.0, 6, 2, true, "correo1@ucm.es", 20);
		this.cDist2 = new TCursoADistancia("C Dist 2", "Curso Distancia 2", new Date(2018, 10, 10), new Date(2018, 10, 20), 30, 60.0, 24, 2, true, "correo2@ucm.es", 20);
		this.cDist3 = new TCursoADistancia("C Dist 3", "Curso Distancia 3", new Date(2018, 10, 10), new Date(2018, 10, 20), 50, 60.0, 45, 3, true, "correo3@ucm.es", 20);
	}

	@Test
	public void testAltaCurso() {
		this.saCentro.altaCentro(tCentro1);
		this.saCentro.altaCentro(tCentro2);
		this.saCentro.altaCentro(tCentro3);
		this.saCentro.bajaCentro(3);
		
		assertEquals(this.saCurso.altaCurso(cPres1), 1);
		assertEquals(this.saCurso.altaCurso(cPres2), 2);
		assertEquals(this.saCurso.altaCurso(cPres3), 3);
		
		assertEquals(this.saCurso.altaCurso(cDist1), 4);
		assertEquals(this.saCurso.altaCurso(cDist2), 5);
		assertEquals(this.saCurso.altaCurso(cDist3), -5); //No puede asignar un curso a un centro que no este activo
		
	}

	@Test
	public void testBajaCurso() {
		assertEquals(this.saCurso.bajaCurso(1), 1);
		assertEquals(this.saCurso.bajaCurso(6), -1); //El id de curso no existe
		assertEquals(this.saCurso.bajaCurso(1), -3); //El curso ya esta dado de baja
	}

	@Test
	public void testBuscarCurso() {
		assertNotNull(this.saCurso.buscarCurso(2));
		assertNull(this.saCurso.buscarCurso(8));
	}

	@Test
	public void testActualizarCurso() {
		this.cPres1.setID(1);
		this.cPres1.setAula(2);
		this.cPres1.setDescripcion("Curso Actualizado 1");
		assertEquals(this.saCurso.actualizarCurso(cPres1), 1);
	}

	@Test
	public void testMostrarCursos() {
		assertNotNull(this.saCurso.mostrarCursos());
	}

}
