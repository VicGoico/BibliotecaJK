
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

CREATE OR REPLACE TABLE `Cliente` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellidos` varchar(40) NOT NULL,
  `dni` varchar(9) NOT NULL,
  `carnet` varchar(5) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` int(9) NOT NULL,
  `activo` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE OR REPLACE TABLE `Libro` (
  `id` int(11) NOT NULL,
  `titulo` varchar(60) NOT NULL,
  `autores` varchar(90) NOT NULL,
  `ISBN` varchar(13) NOT NULL,
  `nPag` int(11) NOT NULL,
  `unidades_totales` int(11) NOT NULL,
  `unidades_prestadas` int(11) NOT NULL,
  `idEditorial` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE OR REPLACE TABLE `LibroTexto` (
  `id` int(11) NOT NULL,
  `asignatura` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE OR REPLACE TABLE `LibroLiteratura` (
  `id` int(11) NOT NULL,
  `genero` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE OR REPLACE TABLE `Prestamo` (
  `idCliente` int(11) NOT NULL,
  `idLibro` int(11) NOT NULL,
  `fechaI` Date NOT NULL,
  `fechaF` Date NOT NULL,
  `devuelto` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE OR REPLACE TABLE `Editorial` (
  `id` int(11) NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `direccion` varchar(90) NOT NULL,
  `libros_activos` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE `Cliente`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `Libro`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `Editorial`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `LibroTexto`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `LibroLiteratura`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `Prestamo`
  ADD PRIMARY KEY (`idCliente`,`idLibro`, `fechaI`),
  ADD KEY `Prestamo_Libro_FK` (`idLibro`);



ALTER TABLE `Cliente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `Libro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Editorial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `LibroTexto`
  ADD CONSTRAINT `LibroTexto_FK` FOREIGN KEY (`id`) REFERENCES `Libro` (`id`) ON DELETE CASCADE;


ALTER TABLE `LibroLiteratura`
  ADD CONSTRAINT `LibroLiteratura_FK` FOREIGN KEY (`id`) REFERENCES `Libro` (`id`) ON DELETE CASCADE;

ALTER TABLE `Prestamo`
  ADD CONSTRAINT `FK_Prestamo_Cliente_Id` FOREIGN KEY (`idCliente`) REFERENCES `Cliente` (`id`),
  ADD CONSTRAINT `FK_Prestamo_Libro_Id` FOREIGN KEY (`idLibro`) REFERENCES `Libro` (`id`);

  ALTER TABLE `Libro`
  ADD CONSTRAINT `LibroEditorial_FK` FOREIGN KEY (`idEditorial`) REFERENCES `Editorial` (`id`) ON DELETE CASCADE;
