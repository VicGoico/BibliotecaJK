/**
 * Copyright © Todos los derechos reservados a los autores
 * @author Ana Corral Descargue
 * @author Guillermo Delgado Yepes
 * @author Víctor Goicoechea Enrique
 * @author Natalia Rodríguez-Peral Valiente
 * @author Bruno Torralbo Fernández
 * @author Jorge Velasco Conde
 */
package Main;

import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Controlador.Controlador;

public class Main {

	public static void main(String[] args) {
		Controlador.getInstance().accion( new Contexto(Events.GUI_MAIN, null) );
	}

}
