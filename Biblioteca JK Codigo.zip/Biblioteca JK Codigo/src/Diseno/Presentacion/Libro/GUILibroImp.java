package Diseno.Presentacion.Libro;

import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUIMensaje;
import Diseno.Presentacion.Controlador.Controlador;

public class GUILibroImp extends GUILibro {
	
	private GUIAltaLibro gUIAltaLibro;
	private GUIBajaLibro gUIBajaLibro;
	private GUIActualizarLibro gUIActualizarLibro;
	private GUIBuscarLibro gUIBuscarLibro;
	private GUIBuscarLibrosAutor gUIBuscarLibroPorAutor;
	private GUIBuscarLibroISBN gUIBuscarLibroPorISBN;
	private GUIMostrarLibros gUIMostrarLibros;
	private GUIBuscarActualizarLibro gUIBuscarActualizar;
	private GUIMostrarLibrosAutor gUIMostrarLibrosAutor;
	
	public GUILibroImp() {
		this.gUIAltaLibro = new GUIAltaLibro();
		this.gUIBajaLibro = new GUIBajaLibro();
		this.gUIActualizarLibro = new GUIActualizarLibro();
		this.gUIBuscarLibro = new GUIBuscarLibro();
		this.gUIBuscarLibroPorAutor = new GUIBuscarLibrosAutor();
		this.gUIBuscarLibroPorISBN = new GUIBuscarLibroISBN();
		this.gUIMostrarLibros = new GUIMostrarLibros();
		this.gUIBuscarActualizar = new GUIBuscarActualizarLibro();
		this.gUIMostrarLibrosAutor = new GUIMostrarLibrosAutor();
		initGUI();
		this.setLocationRelativeTo(null);
	}
	
    @SuppressWarnings("unchecked")                          
    private void initGUI() {

        jLabelTitle = new javax.swing.JLabel();
        jButtonAltaLibro = new javax.swing.JButton();
        jButtonBuscarLibro = new javax.swing.JButton();
        jButtonBuscarISBN = new javax.swing.JButton();
        jButtonBuscarPorAutor = new javax.swing.JButton();
        jButtonActualizarLibros = new javax.swing.JButton();
        jButtonMenuInicio = new javax.swing.JButton();
        jButtonCerrar = new javax.swing.JButton();
        jButtonMostrarLibros = new javax.swing.JButton();
        jButtonBajaLibros = new javax.swing.JButton();
        jLabelFont = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitle.setText("Biblioteca J.K");
        getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jButtonAltaLibro.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonAltaLibro.setForeground(new java.awt.Color(255, 255, 255));
        jButtonAltaLibro.setText("Alta Libro");
        jButtonAltaLibro.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonAltaLibro.setContentAreaFilled(false);
        jButtonAltaLibro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAltaLibroActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAltaLibro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 450, 30));

        jButtonBuscarLibro.setBackground(new java.awt.Color(255, 255, 255));
        jButtonBuscarLibro.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBuscarLibro.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBuscarLibro.setText("Buscar Libro");
        jButtonBuscarLibro.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBuscarLibro.setContentAreaFilled(false);
        jButtonBuscarLibro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuscarLibroActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonBuscarLibro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 450, -1));

        jButtonBuscarISBN.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBuscarISBN.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBuscarISBN.setText("Buscar Libro por ISBN");
        jButtonBuscarISBN.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBuscarISBN.setContentAreaFilled(false);
        jButtonBuscarISBN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuscarISBNActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonBuscarISBN, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 450, -1));

        jButtonBuscarPorAutor.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBuscarPorAutor.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBuscarPorAutor.setText("Buscar Libros por Autor");
        jButtonBuscarPorAutor.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBuscarPorAutor.setContentAreaFilled(false);
        jButtonBuscarPorAutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuscarPorAutorActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonBuscarPorAutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 450, -1));

        jButtonActualizarLibros.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonActualizarLibros.setForeground(new java.awt.Color(255, 255, 255));
        jButtonActualizarLibros.setText("Actualizar Libro");
        jButtonActualizarLibros.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonActualizarLibros.setContentAreaFilled(false);
        jButtonActualizarLibros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActualizarLibrosActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonActualizarLibros, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, 450, -1));

        jButtonMenuInicio.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMenuInicio.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMenuInicio.setText("Menu de Inicio");
        jButtonMenuInicio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMenuInicio.setContentAreaFilled(false);
        jButtonMenuInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenuInicioActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMenuInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 670, 450, -1));

        jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCerrar.setText("Cerrar");
        jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCerrar.setContentAreaFilled(false);
        jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 610, 450, -1));

        jButtonMostrarLibros.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMostrarLibros.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMostrarLibros.setText("Mostrar Libros");
        jButtonMostrarLibros.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMostrarLibros.setContentAreaFilled(false);
        jButtonMostrarLibros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMostrarLibrosActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMostrarLibros, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 450, -1));

        jButtonBajaLibros.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBajaLibros.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBajaLibros.setText("Baja Libro");
        jButtonBajaLibros.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBajaLibros.setContentAreaFilled(false);
        jButtonBajaLibros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBajaLibrosActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonBajaLibros, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 550, 450, -1));

        jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
        getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 710));

        pack();
    }                   

    private void jButtonAltaLibroActionPerformed(java.awt.event.ActionEvent evt) {                                                 
    	this.setVisible(false);
    	this.gUIAltaLibro.setVisible(true);
    }                                                

    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {                                              
        System.exit(0);
    }                                             

    private void jButtonBuscarISBNActionPerformed(java.awt.event.ActionEvent evt) {                                                  
    	this.setVisible(false);
    	this.gUIBuscarLibroPorISBN.setVisible(true);
    }                                                 

    private void jButtonMenuInicioActionPerformed(java.awt.event.ActionEvent evt) {                                                  
    	this.setVisible(false);
        Controlador.getInstance().accion(new Contexto(Events.GUI_MAIN, null));
    }                                                 

    private void jButtonBajaLibrosActionPerformed(java.awt.event.ActionEvent evt) {                                                  
    	this.setVisible(false);
    	this.gUIBajaLibro.setVisible(true);
    }                                                 

    private void jButtonBuscarPorAutorActionPerformed(java.awt.event.ActionEvent evt) {                                                      
    	this.setVisible(false);
    	this.gUIBuscarLibroPorAutor.setVisible(true);
    }                                                     

    private void jButtonMostrarLibrosActionPerformed(java.awt.event.ActionEvent evt) {                                                     
    	this.setVisible(false);
    	this.gUIMostrarLibros.setVisible(true);
    }                                                    

    private void jButtonBuscarLibroActionPerformed(java.awt.event.ActionEvent evt) {                                                   
    	this.setVisible(false);
    	this.gUIBuscarLibro.setVisible(true);
    }                                                  

    private void jButtonActualizarLibrosActionPerformed(java.awt.event.ActionEvent evt) {                                                        
    	this.setVisible(false);
    	this.gUIBuscarActualizar.setVisible(true);
    }
	                   
    private javax.swing.JButton jButtonActualizarLibros;
    private javax.swing.JButton jButtonAltaLibro;
    private javax.swing.JButton jButtonBajaLibros;
    private javax.swing.JButton jButtonBuscarISBN;
    private javax.swing.JButton jButtonBuscarLibro;
    private javax.swing.JButton jButtonBuscarPorAutor;
    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonMenuInicio;
    private javax.swing.JButton jButtonMostrarLibros;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelTitle;    
    
	@Override
	public void actualizar(Contexto contexto) {
		GUIMensaje mensaje = new GUIMensaje();
		switch(contexto.getEvento()) {
		case(Events.RES_ALTA_LIBRO_OK):
			this.setVisible(true);
			this.gUIAltaLibro.clearData();
			mensaje.mostrarMensaje("Se ha creado el libro con id= " + (int) contexto.getDato(), null);
			break;
		case(Events.RES_ALTA_LIBRO_KO):
			switch((int) contexto.getDato()) {
			case(-1):
			mensaje.mostrarMensaje("El libro no es válido", null);
			break;
			case(-2):
			mensaje.mostrarMensaje("La editorial introducida en el libro no existe", null);
			break;
			case(-3):
			mensaje.mostrarMensaje("El libro esta activo", null);
			break;
			case(-5):
			mensaje.mostrarMensaje("La editorial no está activa", null);
			break;
			case(-100):
			mensaje.mostrarMensaje("Error de la base de datos", null);
			break;
			}
		break;
		case(Events.RES_ACTUALIZAR_LIBRO_OK):
			this.setVisible(true);
			this.gUIActualizarLibro.setVisible(false);
			mensaje.mostrarMensaje("Se ha actualizado el libro con id= " + (int) contexto.getDato(), null);
			break;
		case(Events.RES_ACTUALIZAR_LIBRO_KO):
			switch((int) contexto.getDato()) {
			case(-1):
			mensaje.mostrarMensaje("El libro no es válido", null);
			break;
			case(-2):
			mensaje.mostrarMensaje("La editorial actualizada en el libro no existe", null);
			break;
			case(-3):
			mensaje.mostrarMensaje("El libro no está activo", null);
			break;
			case(-5):
			mensaje.mostrarMensaje("La editorial no está activa", null);
			break;
			case(-6):
			mensaje.mostrarMensaje("Las unidades prestadas superan las totales", null);
			case(-100):
			mensaje.mostrarMensaje("Error de la base de datos", null);
			break;
			}
		break;
		case(Events.RES_BUSCAR_LIBRO_OK):
			this.gUIBuscarLibro.actualizar(contexto);
			break;
		case(Events.RES_BUSCAR_LIBRO_KO):
			mensaje.mostrarMensaje("No existe ningún libro con ese id", null);
			break;
		case(Events.RES_BUSCAR_ACTUALIZAR_LIBRO_OK):
			this.gUIBuscarActualizar.clearData();
			this.gUIActualizarLibro.actualizar(contexto);
			break;
		case(Events.RES_BUSCAR_ACTUALIZAR_LIBRO_KO):
			mensaje.mostrarMensaje("No existe ningún libro con ese id", null);
			break;
		case(Events.RES_BAJA_LIBRO_OK):
			this.setVisible(true);
			this.gUIBajaLibro.clearData();
			mensaje.mostrarMensaje("Se ha dado de baja el libro con id= " + (int) contexto.getDato(), null);
			break;
		case(Events.RES_BAJA_LIBRO_KO):
			switch((int) contexto.getDato()) {
			case(-1):
			mensaje.mostrarMensaje("El libro no es válido", null);
			break;
			case(-2):
			mensaje.mostrarMensaje("El libro no existe", null);
			break;
			case(-3):
			mensaje.mostrarMensaje("Existen libros prestados", null);
			break;
			case(-4):
			mensaje.mostrarMensaje("Libro no activo", null);
			break;
			case(-100):
			mensaje.mostrarMensaje("Error de la base de datos", null);
			break;
			}
			break;
		case(Events.RES_MOSTRAR_LIBROS_OK):
			this.gUIMostrarLibros.actualizar(contexto);
			break;
		case(Events.RES_MOSTRAR_LIBROS_KO):
			mensaje.mostrarMensaje("No hay libros", null);
			break;
		case(Events.RES_BUSCAR_LIBRO_ISBN_OK):
			this.gUIBuscarLibroPorISBN.actualizar(contexto);
			break;
		case(Events.RES_BUSCAR_LIBRO_ISBN_KO):
			mensaje.mostrarMensaje("No hay libros con ese ISBN", null);
			break;
		case(Events.RES_BUSCAR_LIBROS_AUTOR_OK):
			this.gUIBuscarLibroPorAutor.clearData();
			this.gUIMostrarLibrosAutor.setVisible(true);
			this.gUIMostrarLibrosAutor.actualizar(contexto);
			break;
		case(Events.RES_BUSCAR_LIBROS_AUTOR_KO):
			mensaje.mostrarMensaje("No hay libros de ese autor", null);
			break;
		case(Events.GUI_LIBRO):
			this.setVisible(true);
		break;
		}
	}
}