package Diseno.Presentacion.Libro;

import Diseno.Negocio.Libro.Asignatura;
import Diseno.Negocio.Libro.Genero;
import Diseno.Negocio.Libro.TLibro;
import Diseno.Negocio.Libro.TLibroLiteratura;
import Diseno.Negocio.Libro.TLibroTexto;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUI;
import Diseno.Presentacion.Controlador.Controlador;

public class GUIBuscarLibro extends javax.swing.JFrame implements GUI{

    public GUIBuscarLibro() {
        initComponents();
        this.setLocationRelativeTo(null);
        
        this.jLabelLibroLiteratura.setVisible(false);
        this.jTextFieldLibroLiteratura.setVisible(false);
        this.jLabelLibroTexto.setVisible(false);
        this.jTextFieldLibroTexto.setVisible(false);
        this.jLabelAvisoId.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

    	buttonGroup = new javax.swing.ButtonGroup();
        jLabelTitle = new javax.swing.JLabel();
        jButtonLibro = new javax.swing.JButton();
        jButtonCerrar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabelId = new javax.swing.JLabel();
        jLabelPaginas = new javax.swing.JLabel();
        jLabelAvisoId = new javax.swing.JLabel();
        jTextFieldISBN = new javax.swing.JTextField();
        jTextFieldAutores = new javax.swing.JTextField();
        jTextFieldPaginas = new javax.swing.JTextField();
        jLabelAutores = new javax.swing.JLabel();
        jLabelLibroTexto = new javax.swing.JLabel();
        jLabelISBN = new javax.swing.JLabel();
        jTextFieldTitulo = new javax.swing.JTextField();
        jTextFieldLibroLiteratura = new javax.swing.JTextField();
        jTextFieldLibroTexto = new javax.swing.JTextField();
        jLabelLibroLiteratura = new javax.swing.JLabel();
        jLabelEditorial = new javax.swing.JLabel();
        jLabelUnidadesPrestadas = new javax.swing.JLabel();
        jTextFieldIdEditorial = new javax.swing.JTextField();
        jTextFieldUnidadesPrestadas = new javax.swing.JTextField();
        jLabelUnidades = new javax.swing.JLabel();
        jTextFieldUnidades = new javax.swing.JTextField();
        jLabelTitulo = new javax.swing.JLabel();
        jTextFieldId = new javax.swing.JTextField();
        jLabelFont = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitle.setText("Biblioteca J.K");
        getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, -1, -1));

        jButtonLibro.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonLibro.setForeground(new java.awt.Color(255, 255, 255));
        jButtonLibro.setText("Buscar Libro");
        jButtonLibro.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonLibro.setContentAreaFilled(false);
        jButtonLibro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLibroActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonLibro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, 450, -1));

        jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCerrar.setText("Cancelar");
        jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCerrar.setContentAreaFilled(false);
        jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 530, 450, -1));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Buscar Libro");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 60, -1, -1));

        jLabelId.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelId.setForeground(new java.awt.Color(255, 255, 255));
        jLabelId.setText("Id del Libro:");
        getContentPane().add(jLabelId, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, 30));

        jLabelPaginas.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelPaginas.setForeground(new java.awt.Color(255, 255, 255));
        jLabelPaginas.setText("Nº páginas:");
        getContentPane().add(jLabelPaginas, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, 30));

        jLabelAvisoId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoId.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoId.setText("Debe ser un número mayor que 0");
        getContentPane().add(jLabelAvisoId, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 130, 210, 20));

        jTextFieldISBN.setEditable(false);
        jTextFieldISBN.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldISBN.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldISBN.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldISBN.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextFieldISBN.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldISBN, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 230, 210, 30));

        jTextFieldAutores.setEditable(false);
        jTextFieldAutores.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldAutores.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldAutores.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldAutores, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 190, 210, 30));

        jTextFieldPaginas.setEditable(false);
        jTextFieldPaginas.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldPaginas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldPaginas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldPaginas, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 270, 210, 30));

        jLabelAutores.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelAutores.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAutores.setText("Autores:");
        getContentPane().add(jLabelAutores, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, -1, 30));

        jLabelLibroTexto.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelLibroTexto.setForeground(new java.awt.Color(255, 255, 255));
        jLabelLibroTexto.setText("Asignatura:");
        getContentPane().add(jLabelLibroTexto, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, -1, 30));

        jLabelISBN.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelISBN.setForeground(new java.awt.Color(255, 255, 255));
        jLabelISBN.setText("ISBN:");
        getContentPane().add(jLabelISBN, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, -1, 30));

        jTextFieldTitulo.setEditable(false);
        jTextFieldTitulo.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldTitulo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldTitulo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 150, 210, 30));

        jTextFieldLibroLiteratura.setEditable(false);
        jTextFieldLibroLiteratura.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldLibroLiteratura.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldLibroLiteratura.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldLibroLiteratura, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 430, 210, 30));

        jTextFieldLibroTexto.setEditable(false);
        jTextFieldLibroTexto.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldLibroTexto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldLibroTexto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldLibroTexto, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 430, 210, 30));

        jLabelLibroLiteratura.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelLibroLiteratura.setForeground(new java.awt.Color(255, 255, 255));
        jLabelLibroLiteratura.setText("Género:");
        getContentPane().add(jLabelLibroLiteratura, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, -1, 30));

        jLabelEditorial.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelEditorial.setForeground(new java.awt.Color(255, 255, 255));
        jLabelEditorial.setText("Id de la Editorial:");
        getContentPane().add(jLabelEditorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, -1, 30));

        jLabelUnidadesPrestadas.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelUnidadesPrestadas.setForeground(new java.awt.Color(255, 255, 255));
        jLabelUnidadesPrestadas.setText("Unidades Prestadas:");
        getContentPane().add(jLabelUnidadesPrestadas, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, -1, 30));

        jTextFieldIdEditorial.setEditable(false);
        jTextFieldIdEditorial.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldIdEditorial.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldIdEditorial.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldIdEditorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 390, 210, 30));

        jTextFieldUnidadesPrestadas.setEditable(false);
        jTextFieldUnidadesPrestadas.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldUnidadesPrestadas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldUnidadesPrestadas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldUnidadesPrestadas, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 350, 210, 30));

        jLabelUnidades.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelUnidades.setForeground(new java.awt.Color(255, 255, 255));
        jLabelUnidades.setText("Unidades:");
        getContentPane().add(jLabelUnidades, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, -1, 30));

        jTextFieldUnidades.setEditable(false);
        jTextFieldUnidades.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldUnidades.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldUnidades.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldUnidades, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 310, 210, 30));

        jLabelTitulo.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelTitulo.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitulo.setText("Título:");
        getContentPane().add(jLabelTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, 30));

        jTextFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldId.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextFieldId.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 100, 210, 30));

        jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
        getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 590));

        pack();
    }

    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {
    	this.clearData();
        Controlador.getInstance().accion(new Contexto(Events.GUI_LIBRO, null));
    }

    private void jButtonLibroActionPerformed(java.awt.event.ActionEvent evt) {
    	int nErrores = 0, id = 0;
    	if(!this.jTextFieldId.getText().matches("^([1-9]{1}[0-9]*)$")) {
    		nErrores++;
    		this.jLabelAvisoId.setVisible(true);
    	}
    	else {
    		id = Integer.parseInt(this.jTextFieldId.getText());
    		this.jLabelAvisoId.setVisible(false);
    	}
    	if(nErrores == 0) {
    		Controlador.getInstance().accion(new Contexto(Events.GUI_BUSCAR_LIBRO, id));
    	}
    }

 // Variables declaration - do not modify                     
    private javax.swing.ButtonGroup buttonGroup;
    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonLibro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelAutores;
    private javax.swing.JLabel jLabelAvisoId;
    private javax.swing.JLabel jLabelEditorial;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelISBN;
    private javax.swing.JLabel jLabelId;
    private javax.swing.JLabel jLabelLibroLiteratura;
    private javax.swing.JLabel jLabelLibroTexto;
    private javax.swing.JLabel jLabelPaginas;
    private javax.swing.JLabel jLabelTitle;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JLabel jLabelUnidades;
    private javax.swing.JLabel jLabelUnidadesPrestadas;
    private javax.swing.JTextField jTextFieldAutores;
    private javax.swing.JTextField jTextFieldISBN;
    private javax.swing.JTextField jTextFieldId;
    private javax.swing.JTextField jTextFieldIdEditorial;
    private javax.swing.JTextField jTextFieldLibroLiteratura;
    private javax.swing.JTextField jTextFieldLibroTexto;
    private javax.swing.JTextField jTextFieldPaginas;
    private javax.swing.JTextField jTextFieldTitulo;
    private javax.swing.JTextField jTextFieldUnidades;
    private javax.swing.JTextField jTextFieldUnidadesPrestadas;
    // End of variables declaration                            
	@Override
	public void actualizar(Contexto contexto) {
		TLibro tLibro = (contexto.getDato() instanceof TLibroLiteratura ? (TLibroLiteratura) contexto.getDato() : (TLibroTexto) contexto.getDato());
		
		this.jTextFieldTitulo.setText(tLibro.getTitulo());
		this.jTextFieldAutores.setText(tLibro.getAutor());
		this.jTextFieldISBN.setText(tLibro.getISBN());
		this.jTextFieldPaginas.setText("" + tLibro.getPaginas());
		this.jTextFieldUnidades.setText("" + tLibro.getUnidadesTotales());
		this.jTextFieldUnidadesPrestadas.setText("" + tLibro.getUnidadesPrestadas());
		this.jTextFieldIdEditorial.setText("" + tLibro.getEditorial());
		if(tLibro instanceof TLibroLiteratura){
			TLibroLiteratura tLibroLit = (TLibroLiteratura) tLibro;
			this.jLabelLibroTexto.setVisible(false);
			this.jTextFieldLibroTexto.setVisible(false);
			this.jLabelLibroLiteratura.setVisible(true);
			this.jTextFieldLibroLiteratura.setVisible(true);
			this.jTextFieldLibroLiteratura.setText(Genero.transform(tLibroLit.getGenero()));
		}
		else{
			TLibroTexto tLibroText = (TLibroTexto) tLibro;
			this.jLabelLibroLiteratura.setVisible(false);
			this.jTextFieldLibroLiteratura.setVisible(false);
			this.jLabelLibroTexto.setVisible(true);
			this.jTextFieldLibroTexto.setVisible(true);
			this.jTextFieldLibroTexto.setText(Asignatura.transform(tLibroText.getAsignatura()));
		}
	}
	
	public void clearData() {
		this.jTextFieldId.setText("");
    	this.jTextFieldTitulo.setText("");
		this.jTextFieldAutores.setText("");
		this.jTextFieldISBN.setText("");
		this.jTextFieldPaginas.setText("");
		this.jTextFieldUnidades.setText("");
		this.jTextFieldUnidadesPrestadas.setText("");
		this.jTextFieldIdEditorial.setText("");
		this.jLabelLibroTexto.setVisible(false);
		this.jTextFieldLibroTexto.setVisible(false);
		this.jLabelLibroLiteratura.setVisible(false);
		this.jTextFieldLibroLiteratura.setVisible(false);
		this.jTextFieldLibroLiteratura.setText("");
		this.jTextFieldLibroTexto.setText("");
    	this.setVisible(false);
	}
}
