/**
 * 
 */
package Diseno.Presentacion.Libro;

import Diseno.Presentacion.GUI;
import javax.swing.JFrame;
import Diseno.Presentacion.Contexto;

public abstract class GUILibro extends JFrame implements GUI {

	private static GUILibro instance;

	public static GUILibro getInstance() {
		if(instance == null){
			instance = new GUILibroImp();
		}
		return instance;
	}

	public abstract void actualizar(Contexto contexto);
}