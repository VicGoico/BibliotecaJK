/**
 * 
 */
package Diseno.Presentacion.Command.CommandTrabajador;

import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Negocio.Trabajador.TTrabajador;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandActualizarTrabajador implements Command {

	public Contexto execute(java.lang.Object dato) {
		TTrabajador trabajador = (TTrabajador) dato;
		int res = FactoriaSA.getInstance().crearSATrabajador().actualizarTrabajador(trabajador);
		if(res > 0) return new Contexto(Events.RES_ACTUALIZAR_TRABAJADOR_OK, res);
		else return new Contexto(Events.RES_ACTUALIZAR_TRABAJADOR_KO, res);
	}
}