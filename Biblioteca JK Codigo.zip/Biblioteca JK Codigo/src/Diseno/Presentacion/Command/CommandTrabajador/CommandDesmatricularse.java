/**
 * 
 */
package Diseno.Presentacion.Command.CommandTrabajador;

import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Negocio.Trabajador.TMatricula;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandDesmatricularse implements Command {

	public Contexto execute(java.lang.Object dato) {
		TMatricula matricula = (TMatricula) dato;
		int res = FactoriaSA.getInstance().crearSATrabajador().desmatricularse(matricula);
		if(res > 0) return new Contexto(Events.RES_DESMATRICULAR_OK, res);
		else return new Contexto(Events.RES_DESMATRICULAR_KO, res);
	}
}