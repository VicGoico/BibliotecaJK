/**
 * 
 */
package Diseno.Presentacion.Command.CommandTrabajador;

import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandBajaTrabajador implements Command {

	public Contexto execute(java.lang.Object dato) {
		int id = (int) dato;
		int res = FactoriaSA.getInstance().crearSATrabajador().bajaTrabajador(id);
		if(res > 0) return new Contexto(Events.RES_BAJA_TRABAJADOR_OK, res);
		else return new Contexto(Events.RES_BAJA_TRABAJADOR_KO, res);
	}
}