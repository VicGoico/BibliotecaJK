/**
 * 
 */
package Diseno.Presentacion.Command.CommandTrabajador;

import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Negocio.Trabajador.TTrabajador;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandBuscarTrabajador implements Command {

	public Contexto execute(java.lang.Object dato) {
		int id = (int) dato;
		TTrabajador trabajador = FactoriaSA.getInstance().crearSATrabajador().buscarTrabajador(id);
		if(trabajador != null) return new Contexto(Events.RES_BUSCAR_TRABAJADOR_OK, trabajador);
		else return new Contexto(Events.RES_BUSCAR_TRABAJADOR_KO, trabajador);
	}
}