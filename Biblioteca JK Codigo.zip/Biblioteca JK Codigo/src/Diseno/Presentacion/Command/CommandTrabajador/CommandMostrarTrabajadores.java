/**
 * 
 */
package Diseno.Presentacion.Command.CommandTrabajador;

import java.util.ArrayList;

import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Negocio.Trabajador.TTrabajador;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandMostrarTrabajadores implements Command {

	public Contexto execute(java.lang.Object dato) {
		ArrayList<TTrabajador> trabajadores = FactoriaSA.getInstance().crearSATrabajador().mostrarTrabajadores();
		if(trabajadores != null) return new Contexto(Events.RES_MOSTRAR_TRABAJADOR_OK, trabajadores);
		else return new Contexto(Events.RES_MOSTRAR_TRABAJADOR_KO, trabajadores);
	}
}