/**
 * 
 */
package Diseno.Presentacion.Command;

import Diseno.Presentacion.Contexto;

public interface Command {

	public Contexto execute(Object dato);
}