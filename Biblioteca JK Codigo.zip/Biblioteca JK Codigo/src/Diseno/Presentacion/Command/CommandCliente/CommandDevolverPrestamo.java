/**
 * 
 */
package Diseno.Presentacion.Command.CommandCliente;

import Diseno.Negocio.Cliente.TPrestamo;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandDevolverPrestamo implements Command {

	public Contexto execute(java.lang.Object dato) {
		TPrestamo tPrestamo = (TPrestamo) dato;
		boolean res = FactoriaSA.getInstance().crearSACliente().devolverPrestamo(tPrestamo);
		if(res) return new Contexto(Events.RES_DEVOLVER_PRESTAMO_OK, res);
		else return new Contexto(Events.RES_DEVOLVER_PRESTAMO_KO, res);
	}
}