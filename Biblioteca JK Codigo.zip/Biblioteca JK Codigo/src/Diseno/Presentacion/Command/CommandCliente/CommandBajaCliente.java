/**
 * 
 */
package Diseno.Presentacion.Command.CommandCliente;

import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

/** 
* <!-- begin-UML-doc -->
* <!-- end-UML-doc -->
* @author Bolil
* @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
*/
public class CommandBajaCliente implements Command {
	/** 
	* (non-Javadoc)
	* @see Command#execute(java.lang.Object dato)
	* @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public Contexto execute(java.lang.Object dato) {
		int id = (int) dato;
		int res = FactoriaSA.getInstance().crearSACliente().bajaCliente(id);
		if(res > 0) return new Contexto(Events.RES_BAJA_CLIENTE_OK, res);
		else return new Contexto(Events.RES_BAJA_CLIENTE_KO, res);
	}
}