/**
 * 
 */
package Diseno.Presentacion.Command.CommandCliente;

import java.util.ArrayList;

import Diseno.Negocio.Cliente.TCliente;
import Diseno.Negocio.Cliente.TGeneroPaginas;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandClientesConLibrosDeUnGeneroYNPaginas implements Command {
	
	public Contexto execute(java.lang.Object dato) {
		TGeneroPaginas tGeneroPaginas = (TGeneroPaginas) dato;
		ArrayList<TCliente> clientes = FactoriaSA.getInstance().crearSACliente().clientesConLibrosDeUnGeneroYNPaginas(tGeneroPaginas);
		if(clientes != null) return new Contexto(Events.RES_QUERY_GENERO_PAGINAS_OK, clientes);
		else return new Contexto(Events.RES_QUERY_GENERO_PAGINAS_KO, clientes);
	}
}