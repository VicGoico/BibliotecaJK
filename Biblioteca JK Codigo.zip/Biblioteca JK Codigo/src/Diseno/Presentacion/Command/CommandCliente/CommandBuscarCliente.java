/**
 * 
 */
package Diseno.Presentacion.Command.CommandCliente;

import Diseno.Negocio.Cliente.TCliente;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandBuscarCliente implements Command {

	public Contexto execute(java.lang.Object dato) {
		int id = (int) dato;
		TCliente tCliente = FactoriaSA.getInstance().crearSACliente().buscarCliente(id);
		if(tCliente != null) return new Contexto(Events.RES_BUSCAR_CLIENTE_OK, tCliente);
		else return new Contexto(Events.RES_BUSCAR_CLIENTE_KO, tCliente);
	}
}