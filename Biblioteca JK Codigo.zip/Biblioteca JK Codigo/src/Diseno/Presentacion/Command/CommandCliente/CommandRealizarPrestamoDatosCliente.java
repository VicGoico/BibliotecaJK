/**
 * 
 */
package Diseno.Presentacion.Command.CommandCliente;

import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandRealizarPrestamoDatosCliente implements Command {

	public Contexto execute(java.lang.Object dato) {
		return new Contexto(Events.GUI_REALIZAR_PRESTAMO_DATOS_LIBRO, dato);
	}
}