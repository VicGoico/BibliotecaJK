/**
 * 
 */
package Diseno.Presentacion.Command.CommandCliente;

import java.util.ArrayList;
import java.util.Set;

import Diseno.Negocio.Cliente.TPrestamo;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;


public class CommandRealizarPrestamoDatosLibro implements Command {

	public Contexto execute(java.lang.Object dato) {
		ArrayList<TPrestamo> prestamos = (ArrayList<TPrestamo>) dato;
		ArrayList<String> res = FactoriaSA.getInstance().crearSACliente().realizarPrestamo(prestamos);
		if(res != null) return new Contexto(Events.RES_REALIZAR_PRESTAMO_OK, res);
		else return new Contexto(Events.RES_REALIZAR_PRESTAMO_KO, res);
	}
}