/**
 * 
 */
package Diseno.Presentacion.Command.CommandCliente;

import java.util.ArrayList;

import Diseno.Negocio.Cliente.TPrestamo;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandMostrarPrestamos implements Command {

	public Contexto execute(java.lang.Object dato) {
		ArrayList<TPrestamo> prestamos = FactoriaSA.getInstance().crearSACliente().mostrarPrestamos();
		if(prestamos != null) return new Contexto(Events.RES_MOSTRAR_PRESTAMO_OK, prestamos);
		else return new Contexto(Events.RES_MOSTRAR_PRESTMO_KO, prestamos);
	}
}