/**
 * 
 */
package Diseno.Presentacion.Command.CommandCliente;

import java.util.ArrayList;

import Diseno.Negocio.Cliente.TCliente;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;


public class CommandMostrarClientes implements Command {

	public Contexto execute(java.lang.Object dato) {
		ArrayList<TCliente> clientes = FactoriaSA.getInstance().crearSACliente().mostrarClientes();
		if(clientes != null) return new Contexto(Events.RES_MOSTRAR_CLIENTE_OK, clientes);
		else return new Contexto(Events.RES_MOSTRAR_CLIENTE_KO, clientes);
	}
}