/**
 * 
 **/
package Diseno.Presentacion.Command.CommandCliente;

import Diseno.Negocio.Cliente.TCliente;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;


public class CommandActualizarCliente implements Command {

	public Contexto execute(Object dato) {
		TCliente tCliente = (TCliente) dato;
		int res = FactoriaSA.getInstance().crearSACliente().actualizarCliente(tCliente);
		if(res > 0) return new Contexto (Events.RES_ACTUALIZAR_CLIENTE_OK, res);
		else return new Contexto (Events.RES_ACTUALIZAR_CLIENTE_KO, res);
	}
}