package Diseno.Presentacion.Command.CommandCurso;

import Diseno.Negocio.Curso.TCurso;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandAltaCurso implements Command {
	
	public Contexto execute(Object dato) {
		TCurso curso = (TCurso) dato;
		int res = FactoriaSA.getInstance().crearSACurso().altaCurso(curso);
		if(res > 0) return new Contexto(Events.RES_ALTA_CURSO_OK, res);
		else return new Contexto(Events.RES_ALTA_CURSO_KO, res);
	}
}