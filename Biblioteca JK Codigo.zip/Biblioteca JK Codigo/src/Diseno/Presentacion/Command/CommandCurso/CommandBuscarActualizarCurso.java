package Diseno.Presentacion.Command.CommandCurso;

import Diseno.Negocio.Curso.TCurso;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandBuscarActualizarCurso implements Command {
	
	public Contexto execute(java.lang.Object dato) {
		int id = (int) dato;
		TCurso curso = FactoriaSA.getInstance().crearSACurso().buscarCurso(id);
		if(curso != null) return new Contexto(Events.RES_BUSCAR_ACTUALIZAR_CURSO_OK, curso);
		else return new Contexto(Events.RES_BUSCAR_ACTUALIZAR_CURSO_KO, curso);
	}
}