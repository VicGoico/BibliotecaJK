package Diseno.Presentacion.Command.CommandCurso;

import java.util.ArrayList;

import Diseno.Negocio.Curso.TCurso;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandMostrarCursos implements Command {
	
	public Contexto execute(java.lang.Object dato) {
		ArrayList<TCurso> cursos = FactoriaSA.getInstance().crearSACurso().mostrarCursos();
		if(cursos != null) return new Contexto(Events.RES_MOSTRAR_CURSOS_OK, cursos);
		else return new Contexto(Events.RES_MOSTRAR_CURSOS_KO, cursos);
	}
}