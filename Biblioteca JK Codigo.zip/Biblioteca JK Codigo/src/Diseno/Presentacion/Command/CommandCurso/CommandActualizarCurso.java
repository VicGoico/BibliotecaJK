package Diseno.Presentacion.Command.CommandCurso;

import Diseno.Negocio.Curso.TCurso;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandActualizarCurso implements Command {

	public Contexto execute(java.lang.Object dato) {
		TCurso curso = (TCurso) dato;
		int res = FactoriaSA.getInstance().crearSACurso().actualizarCurso(curso);
		if(res > 0) return new Contexto(Events.RES_ACTUALIZAR_CURSO_OK, res);
		else return new Contexto(Events.RES_ACTUALIZAR_CURSO_KO, res);
	}
}