package Diseno.Presentacion.Command.CommandCentro;

import java.util.ArrayList;

import Diseno.Negocio.Centro.TCentro;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandMostrarCentros implements Command {
	
	public Contexto execute(java.lang.Object dato) {
		ArrayList<TCentro> lista = FactoriaSA.getInstance().crearSACentro().mostrarCentros();
		if(lista != null) return new Contexto(Events.RES_MOSTRAR_CENTRO_OK, lista);
		else return new Contexto(Events.RES_MOSTRAR_CENTRO_KO, lista);
	}
}