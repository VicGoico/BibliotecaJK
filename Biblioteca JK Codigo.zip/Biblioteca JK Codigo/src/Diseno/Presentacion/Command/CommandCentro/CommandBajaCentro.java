package Diseno.Presentacion.Command.CommandCentro;

import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandBajaCentro implements Command {

	public Contexto execute(java.lang.Object dato) {
		int idCentro = (int) dato;
		int res = FactoriaSA.getInstance().crearSACentro().bajaCentro(idCentro);
		if(res > 0) return new Contexto(Events.RES_BAJA_CENTRO_OK, res);
		else return new Contexto(Events.RES_BAJA_CENTRO_KO, res);
	}
}