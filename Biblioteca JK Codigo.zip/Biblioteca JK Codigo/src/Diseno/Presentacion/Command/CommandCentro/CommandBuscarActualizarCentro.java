package Diseno.Presentacion.Command.CommandCentro;

import Diseno.Negocio.Centro.TCentro;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandBuscarActualizarCentro implements Command {

	public Contexto execute(java.lang.Object dato) {
		int idCentro = (int) dato;
		TCentro tCentro = FactoriaSA.getInstance().crearSACentro().buscarCentro(idCentro);
		if(tCentro != null) return new Contexto(Events.RES_BUSCAR_ACTUALIZAR_CENTRO_OK, tCentro);
		else return new Contexto(Events.RES_BUSCAR_ACTUALIZAR_CENTRO_KO, tCentro);
	}
}