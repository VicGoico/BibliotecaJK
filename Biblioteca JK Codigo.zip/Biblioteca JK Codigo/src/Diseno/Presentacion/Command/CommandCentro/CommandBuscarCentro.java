package Diseno.Presentacion.Command.CommandCentro;

import Diseno.Negocio.Centro.TCentro;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandBuscarCentro implements Command {
	
	public Contexto execute(java.lang.Object dato) {
		int id = (int) dato;
		TCentro tCentro = FactoriaSA.getInstance().crearSACentro().buscarCentro(id);
		if(tCentro != null) return new Contexto(Events.RES_BUSCAR_CENTRO_OK, tCentro);
		else return new Contexto(Events.RES_BUSCAR_CENTRO_KO, tCentro);
	}
}