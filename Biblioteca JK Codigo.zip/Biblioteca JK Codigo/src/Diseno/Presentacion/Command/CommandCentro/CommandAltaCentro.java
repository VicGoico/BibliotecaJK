/**
 * 
 */
package Diseno.Presentacion.Command.CommandCentro;

import Diseno.Negocio.Centro.TCentro;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandAltaCentro implements Command {
	
	public Contexto execute(java.lang.Object dato) {
		TCentro tCentro = (TCentro) dato;
		int res = FactoriaSA.getInstance().crearSACentro().altaCentro(tCentro);
		if(res > 0) return new Contexto(Events.RES_ALTA_CENTRO_OK, res);
		else return new Contexto(Events.RES_ALTA_CENTRO_KO, res);
	}
}