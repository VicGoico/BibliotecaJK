package Diseno.Presentacion.Command.CommandCentro;

import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandCalcularCosteCursos implements Command {
	
	public Contexto execute(java.lang.Object dato) {
		int idCentro = (int) dato;
		int result = FactoriaSA.getInstance().crearSACentro().calcularCosteCursos(idCentro);
		if(result >= 0) return new Contexto(Events.RES_CALCULAR_COSTE_CURSOS_CENTRO_OK, result);
		else return new Contexto(Events.RES_CALCULAR_COSTE_CURSOS_CENTRO_KO, result);
	}
}