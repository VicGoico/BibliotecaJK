package Diseno.Presentacion.Command.CommandLibro;

import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Negocio.Libro.TLibro;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandBuscarLibro implements Command {

	public Contexto execute(java.lang.Object dato) {
		int id = (int) dato;
		TLibro tLibro = FactoriaSA.getInstance().crearSALibro().buscarLibro(id);
		if(tLibro != null) return new Contexto(Events.RES_BUSCAR_LIBRO_OK, tLibro);
		else return new Contexto(Events.RES_BUSCAR_LIBRO_KO, tLibro);
	}
}