package Diseno.Presentacion.Command.CommandLibro;

import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Negocio.Libro.TLibro;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

public class CommandAltaLibro implements Command {

	public Contexto execute(java.lang.Object dato) {
		TLibro tLibro = (TLibro) dato;
		int res = FactoriaSA.getInstance().crearSALibro().altaLibro(tLibro);
		if(res > 0) return new Contexto(Events.RES_ALTA_LIBRO_OK, res);
		else return new Contexto(Events.RES_ALTA_LIBRO_KO, res);
	}
}