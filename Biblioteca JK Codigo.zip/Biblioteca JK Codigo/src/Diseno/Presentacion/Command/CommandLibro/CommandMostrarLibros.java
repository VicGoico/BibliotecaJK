package Diseno.Presentacion.Command.CommandLibro;

import java.util.ArrayList;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Negocio.Libro.TLibro;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;


public class CommandMostrarLibros implements Command {

	public Contexto execute(java.lang.Object dato) {
		ArrayList<TLibro> libros = FactoriaSA.getInstance().crearSALibro().mostrarLibros();
		if(libros != null) return new Contexto(Events.RES_MOSTRAR_LIBROS_OK, libros);
		else return new Contexto(Events.RES_MOSTRAR_LIBROS_KO, libros);
	}
}