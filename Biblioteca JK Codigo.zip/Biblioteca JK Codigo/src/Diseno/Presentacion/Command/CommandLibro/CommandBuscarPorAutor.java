package Diseno.Presentacion.Command.CommandLibro;

import java.util.ArrayList;
import Diseno.Negocio.Factorias.FactoriaSA;
import Diseno.Negocio.Libro.TLibro;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;


public class CommandBuscarPorAutor implements Command {

	public Contexto execute(java.lang.Object dato) {
		String autor = (String) dato;
		ArrayList<TLibro> libros = FactoriaSA.getInstance().crearSALibro().buscarPorAutor(autor);
		if(libros != null) return new Contexto(Events.RES_BUSCAR_LIBROS_AUTOR_OK, libros);
		else return new Contexto(Events.RES_BUSCAR_LIBROS_AUTOR_KO, libros);
	}
}