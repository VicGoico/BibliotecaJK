package Diseno.Presentacion.Command.CommandEditorial;

import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;
import Diseno.Negocio.Editorial.TEditorial;
import Diseno.Negocio.Factorias.FactoriaSA;


public class CommandAltaEditorial implements Command {

	public Contexto execute(Object dato) {
		TEditorial tEditorial = (TEditorial) dato;
		int res = FactoriaSA.getInstance().crearSAEditorial().altaEditorial(tEditorial);
		// Devolvio un id positivo
		if(res > 0) return new Contexto(Events.RES_ALTA_EDITORIAL_OK, res);
		// Devolvio un id malo
		else return new Contexto(Events.RES_ALTA_EDITORIAL_KO, res);
	} 
}