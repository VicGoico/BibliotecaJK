package Diseno.Presentacion.Command.CommandEditorial;

import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;
import Diseno.Negocio.Editorial.TEditorial;
import Diseno.Negocio.Factorias.FactoriaSA;

import java.util.ArrayList;

public class CommandMostrarEditorial implements Command {
	
	public Contexto execute(Object dato) {
		// No toco el dato porque basicamente no me sirve para nada
		ArrayList<TEditorial> lista = FactoriaSA.getInstance().crearSAEditorial().mostrarEditoriales();
		if(lista != null) return new Contexto(Events.RES_MOSTRAR_EDITORIAL_OK, lista);
		else return new Contexto(Events.RES_MOSTRAR_EDITORIAL_KO, lista);
	} 
}