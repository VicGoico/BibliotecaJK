package Diseno.Presentacion.Command.CommandEditorial;


import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;
import Diseno.Negocio.Editorial.TEditorial;
import Diseno.Negocio.Factorias.FactoriaSA;


public class CommandBuscarActualizarEditorial implements Command {
	
	public Contexto execute(Object dato) {
		int id = (int) dato;
		TEditorial tEditorial = FactoriaSA.getInstance().crearSAEditorial().buscarEditorial(id);
		if(tEditorial != null) return new Contexto(Events.RES_BUSCAR_ACTUALIZAR_EDITORIAL_OK, tEditorial);
		else return new Contexto (Events.RES_BUSCAR_ACTUALIZAR_EDITORIAL_KO, tEditorial);
	} 
}