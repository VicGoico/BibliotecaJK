package Diseno.Presentacion.Command.CommandEditorial;


import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.Command.Command;

import Diseno.Negocio.Factorias.FactoriaSA;



public class CommandBajaEditorial implements Command {
	
	public Contexto execute(Object dato) {
		int id = (int) dato;
		int res = FactoriaSA.getInstance().crearSAEditorial().bajaEditorial(id);
		// Lo da por bueno
		if(res > 0) return new Contexto(Events.RES_BAJA_EDITORIAL_OK, res);
		// Falla
		else return new Contexto(Events.RES_BAJA_EDITORIAL_KO, res);
	} 
}