/**
 * 
 */
package Diseno.Presentacion;


public interface GUI {

	public void actualizar(Contexto contexto);
}