/**
 * 
 */
package Diseno.Presentacion;


public class Events {

	public static final int GUI_MAIN= 1000;
	public static final int GUI_EDITORIAL= 100;
	public static final int GUI_CLIENTE = 200;
	public static final int GUI_LIBRO = 300;
	public static final int GUI_TRABAJADOR = 400;
	public static final int GUI_CURSO = 500;
	public static final int GUI_CENTRO = 600; 

	
	public static final int GUI_ACTUALIZAR_CLIENTE = 201;
	public static final int RES_ACTUALIZAR_CLIENTE_OK = 220;
	public static final int RES_ACTUALIZAR_CLIENTE_KO = 221;

	public static final int GUI_ALTA_CLIENTE = 202;
	public static final int RES_ALTA_CLIENTE_OK = 222;
	public static final int RES_ALTA_CLIENTE_KO = 223;

	public static final int GUI_BAJA_CLIENTE = 203;
	public static final int RES_BAJA_CLIENTE_OK = 224;
	public static final int RES_BAJA_CLIENTE_KO = 225;

	public static final int GUI_BUSCAR_ACTUALIZAR_CLIENTE = 204;
	public static final int RES_BUSCAR_ACTUALIZAR_CLIENTE_OK = 226;
	public static final int RES_BUSCAR_ACTUALIZAR_CLIENTE_KO = 227;

	public static final int GUI_BUSCAR_CLIENTE = 205;
	public static final int RES_BUSCAR_CLIENTE_OK = 228;
	public static final int RES_BUSCAR_CLIENTE_KO = 229;

	public static final int GUI_DEVOLVER_PRESTAMO= 206;
	public static final int RES_DEVOLVER_PRESTAMO_OK = 230;
	public static final int RES_DEVOLVER_PRESTAMO_KO = 231;

	public static final int GUI_MOSTRAR_CLIENTES = 207;
	public static final int RES_MOSTRAR_CLIENTE_OK = 232;
	public static final int RES_MOSTRAR_CLIENTE_KO = 233;

	public static final int GUI_MOSTRAR_QUERY_GENERO_PAGINA = 208;
	public static final int GUI_MOSTRAR_QUERY_LIBROS_EDITORIAL = 209;

	public static final int GUI_MOSTRAR_PRESTAMOS = 210;
	public static final int RES_MOSTRAR_PRESTAMO_OK = 234;
	public static final int RES_MOSTRAR_PRESTMO_KO = 235;

	public static final int GUI_QUERY_GENERO_PAGINAS = 211;
	public static final int RES_QUERY_GENERO_PAGINAS_OK = 236;
	public static final int RES_QUERY_GENERO_PAGINAS_KO = 237;

	public static final int GUI_QUERY_LIBROS_EDITORIAL = 212;
	public static final int RES_QUERY_LIBROS_EDITORIAL_OK = 238;
	public static final int RES_QUERY_LIBROS_EDITORIAL_KO = 239;

	public static final int GUI_REALIZAR_PRESTAMO_DATOS_CLIENTE = 213;
	
	public static final int GUI_REALIZAR_PRESTAMO_DATOS_LIBRO = 214;
	
	public static final int RES_REALIZAR_PRESTAMO_OK = 240;
	public static final int RES_REALIZAR_PRESTAMO_KO = 241;
	
	
	
	
	public static final int GUI_ALTA_LIBRO = 301;
	public static final int RES_ALTA_LIBRO_OK = 320;
	public static final int RES_ALTA_LIBRO_KO = 321;

	public static final int GUI_BAJA_LIBRO = 302;

	public static final int RES_BAJA_LIBRO_OK = 322;
	public static final int RES_BAJA_LIBRO_KO = 323;

	public static final int GUI_BUSCAR_ACTUALIZAR_LIBRO = 303;
	public static final int RES_BUSCAR_ACTUALIZAR_LIBRO_OK = 324;
	public static final int RES_BUSCAR_ACTUALIZAR_LIBRO_KO = 325;
	
	public static final int GUI_ACTUALIZAR_LIBRO = 304;
	public static final int RES_ACTUALIZAR_LIBRO_OK = 326;
	public static final int RES_ACTUALIZAR_LIBRO_KO = 327;
	
	public static final int GUI_BUSCAR_LIBRO = 305;
	public static final int RES_BUSCAR_LIBRO_OK = 328;
	public static final int RES_BUSCAR_LIBRO_KO = 329;
	
	public static final int GUI_MOSTRAR_LIBROS = 306;
	public static final int RES_MOSTRAR_LIBROS_OK = 330;
	public static final int RES_MOSTRAR_LIBROS_KO = 331;
	
	public static final int GUI_BUSCAR_LIBRO_ISBN = 307;
	public static final int RES_BUSCAR_LIBRO_ISBN_OK = 332;
	public static final int RES_BUSCAR_LIBRO_ISBN_KO = 333;
	
	public static final int GUI_BUSCAR_LIBROS_AUTOR = 308;
	public static final int RES_BUSCAR_LIBROS_AUTOR_OK = 334;
	public static final int RES_BUSCAR_LIBROS_AUTOR_KO = 335;

	public static final int GUI_MOSTRAR_LIBROS_AUTOR = 309;
	
	
	

	public static final int GUI_ALTA_EDITORIAL = 101;
	public static final int RES_ALTA_EDITORIAL_OK = 120;
	public static final int RES_ALTA_EDITORIAL_KO = 121;
	
	public static final int GUI_BAJA_EDITORIAL = 102;
	public static final int RES_BAJA_EDITORIAL_OK = 122;
	public static final int RES_BAJA_EDITORIAL_KO = 123;
	
	public static final int GUI_BUSCAR_ACTUALIZAR_EDITORIAL = 103;
	public static final int RES_BUSCAR_ACTUALIZAR_EDITORIAL_OK = 124;
	public static final int RES_BUSCAR_ACTUALIZAR_EDITORIAL_KO = 125;

	public static final int GUI_ACTUALIZAR_EDITORIAL = 104;
	public static final int RES_ACTUALIZAR_EDITORIAL_OK = 126;
	public static final int RES_ACTUALIZAR_EDITORIAL_KO = 127;
	
	public static final int GUI_BUSCAR_EDITORIAL = 105;
	public static final int RES_BUSCAR_EDITORIAL_OK = 128;
	public static final int RES_BUSCAR_EDITORIAL_KO = 129;
	
	public static final int GUI_MOSTRAR_EDITORIAL = 106;
	public static final int RES_MOSTRAR_EDITORIAL_OK = 130;
	public static final int RES_MOSTRAR_EDITORIAL_KO = 131;
	

	
	
	public static final int GUI_ALTA_TRABAJADOR = 401;
	public static final int RES_ALTA_TRABAJADOR_OK = 420;
	public static final int RES_ALTA_TRABAJADOR_KO = 421;
	
	public static final int GUI_BUSCAR_TRABAJADOR = 402;
	public static final int RES_BUSCAR_TRABAJADOR_OK = 422;
	public static final int RES_BUSCAR_TRABAJADOR_KO = 423;
	
	public static final int GUI_BAJA_TRABAJADOR = 403;
	public static final int RES_BAJA_TRABAJADOR_OK = 424;
	public static final int RES_BAJA_TRABAJADOR_KO = 425;
	
	public static final int GUI_MOSTRAR_TRABAJADOR = 404;
	public static final int RES_MOSTRAR_TRABAJADOR_OK = 426;
	public static final int RES_MOSTRAR_TRABAJADOR_KO = 427;
	
	public static final int GUI_BUSCAR_ACTUALIZAR_TRABAJADOR = 405;
	public static final int RES_BUSCAR_ACTUALIZAR_TRABAJADOR_OK = 428;
	public static final int RES_BUSCAR_ACTUALIZAR_TRABAJADOR_KO = 429;

	public static final int GUI_ACTUALIZAR_TRABAJADOR = 406;
	public static final int RES_ACTUALIZAR_TRABAJADOR_OK = 430;
	public static final int RES_ACTUALIZAR_TRABAJADOR_KO = 431;
	
	public static final int GUI_MATRICULAR = 407;
	public static final int RES_MATRICULAR_OK = 432;
	public static final int RES_MATRICULAR_KO = 433;
	
	public static final int GUI_DESMATRICULAR = 408;
	public static final int RES_DESMATRICULAR_OK = 434;
	public static final int RES_DESMATRICULAR_KO = 435;

	public static final int GUI_MOSTRAR_MATRICULAS = 409;
	public static final int RES_MOSTRAR_MATRICULAS_OK = 436;
	public static final int RES_MOSTRAR_MATRICULAS_KO = 437;

	
	
	public static final int GUI_ALTA_CURSO = 501;
	public static final int RES_ALTA_CURSO_OK = 520;
	public static final int RES_ALTA_CURSO_KO = 521;
	
	public static final int GUI_BAJA_CURSO = 502;
	public static final int RES_BAJA_CURSO_OK = 522;
	public static final int RES_BAJA_CURSO_KO = 523;
	
	public static final int GUI_BUSCAR_ACTUALIZAR_CURSO = 503;
	public static final int RES_BUSCAR_ACTUALIZAR_CURSO_OK = 524;
	public static final int RES_BUSCAR_ACTUALIZAR_CURSO_KO = 525;
	
	public static final int GUI_ACTUALIZAR_CURSO = 504;
	public static final int RES_ACTUALIZAR_CURSO_OK = 526;
	public static final int RES_ACTUALIZAR_CURSO_KO = 527;
	
	public static final int GUI_BUSCAR_CURSO = 505;
	public static final int RES_BUSCAR_CURSO_OK = 528;
	public static final int RES_BUSCAR_CURSO_KO = 529;
	
	public static final int GUI_MOSTRAR_CURSOS = 506;
	public static final int RES_MOSTRAR_CURSOS_OK = 530;
	public static final int RES_MOSTRAR_CURSOS_KO = 531;
	

	
	public static final int GUI_ALTA_CENTRO = 601;
	public static final int RES_ALTA_CENTRO_OK = 620;
	public static final int RES_ALTA_CENTRO_KO = 621;
	
	public static final int GUI_BAJA_CENTRO = 602;
	public static final int RES_BAJA_CENTRO_OK = 622;
	public static final int RES_BAJA_CENTRO_KO = 623;
	
	public static final int GUI_ACTUALIZAR_CENTRO = 603;
	public static final int RES_ACTUALIZAR_CENTRO_KO = 624;
	public static final int RES_ACTUALIZAR_CENTRO_OK = 625;

	public static final int GUI_BUSCAR_CENTRO = 604;
	public static final int RES_BUSCAR_CENTRO_OK = 626;
	public static final int RES_BUSCAR_CENTRO_KO = 627;
	
	public static final int GUI_MOSTRAR_CENTRO = 605;
	public static final int RES_MOSTRAR_CENTRO_OK = 628;
	public static final int RES_MOSTRAR_CENTRO_KO = 629;

	public static final int GUI_BUSCAR_ACTUALIZAR_CENTRO = 606;
	public static final int RES_BUSCAR_ACTUALIZAR_CENTRO_OK = 630;
	public static final int RES_BUSCAR_ACTUALIZAR_CENTRO_KO = 631;
	
	public static final int GUI_CALCULAR_COSTE_CURSOS_CENTRO = 607;
	public static final int RES_CALCULAR_COSTE_CURSOS_CENTRO_OK = 632;
	public static final int RES_CALCULAR_COSTE_CURSOS_CENTRO_KO = 633;
}