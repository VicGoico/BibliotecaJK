package Diseno.Presentacion.Centro;

import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUIMensaje;
import Diseno.Presentacion.Controlador.Controlador;

public class GUICentroImp extends GUICentro {
	
	private GUIAltaCentro gUIAltaCentro;
	private GUIBajaCentro gUIBajaCentro;
	private GUIActualizarCentro gUIActualizarCentro;
	private GUIBuscarActualizarCentro gUIBuscarActualizarCentro;
	private GUIBuscarCentro gUIBuscarCentro;
	private GUIMostrarCentros gUIMostrarCentros;
	private GUICosteMedio gUICalcularCosteCursos;
	
	public GUICentroImp(){
		this.gUIAltaCentro = new GUIAltaCentro();
		this.gUIBajaCentro = new GUIBajaCentro();
		this.gUIActualizarCentro = new GUIActualizarCentro();
		this.gUIBuscarActualizarCentro = new GUIBuscarActualizarCentro();
		this.gUIBuscarCentro = new GUIBuscarCentro();
		this.gUIMostrarCentros = new GUIMostrarCentros();
		this.gUICalcularCosteCursos = new GUICosteMedio();
		
		initGUI();
		this.setLocationRelativeTo(null);
		
	}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initGUI() {

        jLabelTitle = new javax.swing.JLabel();
        jButtonAltaCentro = new javax.swing.JButton();
        jButtonBuscarCentro = new javax.swing.JButton();
        jButtonMostrarCentros = new javax.swing.JButton();
        jButtonActualizarCentro = new javax.swing.JButton();
        jButtonCosteMedio = new javax.swing.JButton();
        jButtonMenuInicio = new javax.swing.JButton();
        jButtonCerrar = new javax.swing.JButton();
        jButtonBajaCentro = new javax.swing.JButton();
        jLabelFont = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitle.setText("Biblioteca J.K");
        getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jButtonAltaCentro.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonAltaCentro.setForeground(new java.awt.Color(255, 255, 255));
        jButtonAltaCentro.setText("Alta Centro");
        jButtonAltaCentro.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonAltaCentro.setContentAreaFilled(false);
        jButtonAltaCentro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAltaCentroActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAltaCentro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 450, 30));

        jButtonBuscarCentro.setBackground(new java.awt.Color(255, 255, 255));
        jButtonBuscarCentro.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBuscarCentro.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBuscarCentro.setText("Buscar Centro");
        jButtonBuscarCentro.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBuscarCentro.setContentAreaFilled(false);
        jButtonBuscarCentro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuscarCentroActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonBuscarCentro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 450, -1));

        jButtonMostrarCentros.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMostrarCentros.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMostrarCentros.setText("Mostrar Centros");
        jButtonMostrarCentros.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMostrarCentros.setContentAreaFilled(false);
        jButtonMostrarCentros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMostrarCentrosActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMostrarCentros, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 450, -1));

        jButtonActualizarCentro.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonActualizarCentro.setForeground(new java.awt.Color(255, 255, 255));
        jButtonActualizarCentro.setText("Actualizar Centro");
        jButtonActualizarCentro.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonActualizarCentro.setContentAreaFilled(false);
        jButtonActualizarCentro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActualizarCentroActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonActualizarCentro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 450, -1));

        jButtonCosteMedio.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCosteMedio.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCosteMedio.setText("Calcular Coste Medio");
        jButtonCosteMedio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCosteMedio.setContentAreaFilled(false);
        jButtonCosteMedio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCosteMedioActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCosteMedio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, 450, -1));

        jButtonMenuInicio.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMenuInicio.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMenuInicio.setText("Menu de Inicio");
        jButtonMenuInicio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMenuInicio.setContentAreaFilled(false);
        jButtonMenuInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenuInicioActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMenuInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 610, 450, -1));

        jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCerrar.setText("Cerrar");
        jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCerrar.setContentAreaFilled(false);
        jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 550, 450, -1));

        jButtonBajaCentro.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBajaCentro.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBajaCentro.setText("Baja Centro");
        jButtonBajaCentro.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBajaCentro.setContentAreaFilled(false);
        jButtonBajaCentro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBajaCentroActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonBajaCentro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 450, -1));

        jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
        getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 670));

        pack();
    }// </editor-fold>                        

    private void jButtonAltaCentroActionPerformed(java.awt.event.ActionEvent evt) {                                                  
        this.setVisible(false);
        this.gUIAltaCentro.setVisible(true);
    }                                                 

    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {                                              
        System.exit(0);
    }                                             

    private void jButtonMostrarCentrosActionPerformed(java.awt.event.ActionEvent evt) {                                                      
        this.setVisible(false);
        this.gUIMostrarCentros.setVisible(true);
    }                                                     

    private void jButtonMenuInicioActionPerformed(java.awt.event.ActionEvent evt) {                                                  
        this.setVisible(false);
        Controlador.getInstance().accion(new Contexto(Events.GUI_MAIN, null));
    }                                                 

    private void jButtonBuscarCentroActionPerformed(java.awt.event.ActionEvent evt) {                                                    
        this.setVisible(false);
        this.gUIBuscarCentro.setVisible(true);
    }                                                   

    private void jButtonActualizarCentroActionPerformed(java.awt.event.ActionEvent evt) {                                                        
        this.setVisible(false);
        this.gUIBuscarActualizarCentro.setVisible(true);
    }                                                       

    private void jButtonBajaCentroActionPerformed(java.awt.event.ActionEvent evt) {                                                  
        this.setVisible(false);
        this.gUIBajaCentro.setVisible(true);
    }                                                 

    private void jButtonCosteMedioActionPerformed(java.awt.event.ActionEvent evt) {                                                  
        this.setVisible(false);
        this.gUICalcularCosteCursos.setVisible(true);
    }
    
	@Override
	public void actualizar(Contexto contexto) {
		GUIMensaje mensaje = new GUIMensaje();
		switch(contexto.getEvento()){
		case(Events.RES_ALTA_CENTRO_OK):
			this.setVisible(true);
			this.gUIAltaCentro.clearData();
			mensaje.mostrarMensaje("Se ha creado el centro con id "+(int)contexto.getDato(), null);
		break;
		case(Events.RES_ALTA_CENTRO_KO):
			switch((int)contexto.getDato()){
			case(-1):
				mensaje.mostrarMensaje("Fallo en la transaccion", null);
			break;
			case(-2):
				mensaje.mostrarMensaje("Existe el centro con ese id, pero no esta dado de baja ", null);
			break;
			case(-100):
				mensaje.mostrarMensaje("Error en la BBDD", null);
			break;
			}
		break;
		case(Events.RES_BAJA_CENTRO_OK):
			this.setVisible(true);
			this.gUIBajaCentro.clearData();
			mensaje.mostrarMensaje("Se dio de baja el centro con id "+(int) contexto.getDato(), null);
		break;
		case(Events.RES_BAJA_CENTRO_KO):
			switch((int)contexto.getDato()){
			case(-1):
				mensaje.mostrarMensaje("Fallo en la transaccion", null);
			break;
			case(-2):
				mensaje.mostrarMensaje("No existe el centro con ese id ", null);
			break;
			case(-3):
				mensaje.mostrarMensaje("El centro con ese id, ya esta dado de baja", null);
			break;
			case (-4):
				mensaje.mostrarMensaje("El centro tiene cursos activos.", null);
			break;
			case(-100):
				mensaje.mostrarMensaje("Error en la BBDD", null);
			break;	
			}
		break;
		case (Events.RES_BUSCAR_ACTUALIZAR_CENTRO_OK):
			this.gUIBuscarActualizarCentro.clearData();
			this.gUIActualizarCentro.actualizar(contexto);
		break;
		case(Events.RES_BUSCAR_ACTUALIZAR_CENTRO_KO):
			mensaje.mostrarMensaje("No existe ningun centro con ese id ", null);
		break;
		case(Events.RES_ACTUALIZAR_CENTRO_OK):
			this.setVisible(true);
			this.gUIActualizarCentro.setVisible(false);
			mensaje.mostrarMensaje("Se ha actualizado el centro con id "+(int)contexto.getDato(), null);
		break;
		case(Events.RES_ACTUALIZAR_CENTRO_KO):
			switch((int)contexto.getDato()){
			case(-1):
				mensaje.mostrarMensaje("Fallo en la transaccion", null);
			break;
			case(-2):
				mensaje.mostrarMensaje("No existe el centro con ese id ", null);
			break;
			case(-3):
				mensaje.mostrarMensaje("El centro con ese id esta dado de baja", null);
			break;
			case(-4):
				mensaje.mostrarMensaje("El nuevo nombre del centro con ese id ya existe", null);
			break;
			case(-100):
				mensaje.mostrarMensaje("Error en la BBDD", null);
			break;	
			}
		break;
		case(Events.RES_BUSCAR_CENTRO_OK):
			this.gUIBuscarCentro.actualizar(contexto);
		break;
		case(Events.RES_BUSCAR_CENTRO_KO):
			mensaje.mostrarMensaje("No existe ningun centro con ese id ", null);
		break;
		case(Events.RES_MOSTRAR_CENTRO_OK):
			this.gUIMostrarCentros.actualizar(contexto);
		break;
		case(Events.RES_MOSTRAR_CENTRO_KO):
			mensaje.mostrarMensaje("No hay centros", null);
		break;
		/*polimorfica*/
		case(Events.RES_CALCULAR_COSTE_CURSOS_CENTRO_OK):
			this.gUICalcularCosteCursos.actualizar(contexto);
		break;
		case(Events.RES_CALCULAR_COSTE_CURSOS_CENTRO_KO):
			switch((int)contexto.getDato()){
			case(-1):
				mensaje.mostrarMensaje("Fallo en la transaccion", null);
			break;
			case(-2):
				mensaje.mostrarMensaje("No existe el centro con ese id ", null);
			break;
			case(-3):
				mensaje.mostrarMensaje("El centro con ese id, no esta activo", null);
			break;
			case(-4):
				mensaje.mostrarMensaje("No hay cursos asociados a ese centro", null);
				// Para poner un 0 en el caso de que no tenga cursos asociados
				this.gUICalcularCosteCursos.actualizar(new Contexto(Events.RES_CALCULAR_COSTE_CURSOS_CENTRO_KO, 0));
			break;
			case(-100):
				mensaje.mostrarMensaje("Fallo en la BBDD", null);
			break;
			}
		//Plimorfica
		break;
		case(Events.GUI_CENTRO):
			this.setVisible(true);
		break;
		}
		
		
			
		
	}
	
	  // Variables declaration - do not modify                     
    private javax.swing.JButton jButtonActualizarCentro;
    private javax.swing.JButton jButtonAltaCentro;
    private javax.swing.JButton jButtonBajaCentro;
    private javax.swing.JButton jButtonBuscarCentro;
    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonCosteMedio;
    private javax.swing.JButton jButtonMenuInicio;
    private javax.swing.JButton jButtonMostrarCentros;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelTitle;
    // End of variables declaration       
}