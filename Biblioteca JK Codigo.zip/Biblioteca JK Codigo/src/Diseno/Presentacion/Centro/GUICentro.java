package Diseno.Presentacion.Centro;

import Diseno.Presentacion.GUI;

import javax.swing.JFrame;

import Diseno.Presentacion.Contexto;

public abstract class GUICentro extends JFrame implements GUI {
	
	private static GUICentro instance;

	public static GUICentro getInstance() {
		
		if(instance == null) 
			instance = new GUICentroImp();
		return instance;
	}

	public abstract void actualizar(Contexto contexto);
}