/**
 * 
 */
package Diseno.Presentacion.Controlador;

import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Command.Command;
import Diseno.Presentacion.Command.FactoriaCommand.FactoriaCommand;
import Diseno.Presentacion.Dispatcher.Dispatcher;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Bolil
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class ControladorImp extends Controlador {

	@Override
	public void accion(Contexto contexto) {
		Command command = FactoriaCommand.getInstance().generarComando(contexto.getEvento());
		Contexto contextoResult = null;
		if (command != null) {
			contextoResult = command.execute(contexto.getDato());
			Dispatcher.getInstance().generarVista(contextoResult);
		}
		else Dispatcher.getInstance().generarVista(contexto);
	}
}