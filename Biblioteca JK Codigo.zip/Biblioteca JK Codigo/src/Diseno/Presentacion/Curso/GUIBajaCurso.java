package Diseno.Presentacion.Curso;

import javax.swing.JFrame;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUI;
import Diseno.Presentacion.Controlador.Controlador;

public class GUIBajaCurso  extends JFrame implements GUI {

	public GUIBajaCurso() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.jLabelAviso.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        jLabelTitle = new javax.swing.JLabel();
        jButtonCliente = new javax.swing.JButton();
        jButtonCerrar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldId = new javax.swing.JTextField();
        jLabelAviso = new javax.swing.JLabel();
        jLabelFont = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitle.setText("Biblioteca J.K");
        getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jButtonCliente.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCliente.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCliente.setText("Baja Curso");
        jButtonCliente.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCliente.setContentAreaFilled(false);
        jButtonCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBajaCursoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 450, -1));

        jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCerrar.setText("Cancelar");
        jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCerrar.setContentAreaFilled(false);
        jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 450, -1));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Baja Curso");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 160, -1, -1));

        jLabel2.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Id del Curso:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, -1, 30));

        jTextFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldId.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 240, 210, 30));

        jLabelAviso.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAviso.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAviso.setText("El id debe ser un número mayor que 0");
        getContentPane().add(jLabelAviso, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 270, 220, 20));

        jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
        getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 430));

        pack();
    }

    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {
    	this.clearData();
        Controlador.getInstance().accion(new Contexto(Events.GUI_CURSO, null));
    }

    private void jButtonBajaCursoActionPerformed(java.awt.event.ActionEvent evt) {
    	int nErrores = 0, id = 0;
        if(!this.jTextFieldId.getText().matches("^([1-9]{1}[0-9]*)$")) {
    		nErrores++;
    		this.jLabelAviso.setVisible(true);
    	}
    	else {
    		id = Integer.parseInt(this.jTextFieldId.getText());
    		this.jLabelAviso.setVisible(false);
    	}
        if(nErrores == 0) {
        	Controlador.getInstance().accion(new Contexto(Events.GUI_BAJA_CURSO, id));
        }
    }

    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonCliente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelAviso;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelTitle;
    private javax.swing.JTextField jTextFieldId;
   
	@Override
	public void actualizar(Contexto contexto) {}

	public void clearData() {
		this.jTextFieldId.setText("");
		this.jLabelAviso.setVisible(false);
    	this.setVisible(false);
	}
}
