package Diseno.Presentacion.Curso;

import java.util.Date;

import javax.swing.JFrame;

import Diseno.Negocio.Curso.TCursoADistancia;
import Diseno.Negocio.Curso.TCursoPresencial;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUI;
import Diseno.Presentacion.Controlador.Controlador;

public class GUIAltaCurso  extends JFrame implements GUI {

    public GUIAltaCurso() {
    	initComponents();
        this.setLocationRelativeTo(null);
        this.buttonGroup.add(this.jRadioButtonDistancia);
        this.buttonGroup.add(this.jRadioButtonPresencial);
        this.jLabelAvisoNombre.setVisible(false);
        this.jLabelAvisoDescripcion.setVisible(false);
        this.jLabelAvisoFechaF.setVisible(false);
        this.jLabelAvisoFechaI.setVisible(false);
        this.jLabelAvisoPlazas.setVisible(false);
        this.jLabelAvisoPrecio.setVisible(false);
        this.jLabelAvisoDescuento.setVisible(false);
        this.jLabelAvisoCorreo.setVisible(false);
        this.jLabelAvisoTasa.setVisible(false);
        this.jLabelAvisoAula.setVisible(false);
        this.jLabelAvisoIdCentro.setVisible(false);
        this.jLabelAula.setVisible(false);
        this.jLabelDescuento.setVisible(false);
        this.jLabelCorreo.setVisible(false);
        this.jLabelTasa.setVisible(false);
        this.jTextFieldAula.setVisible(false);
        this.jTextFieldCorreo.setVisible(false);
        this.jTextFieldDescuento.setVisible(false);
        this.jTextFieldTasa.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    
    private void initComponents() {
    	
    	buttonGroup = new javax.swing.ButtonGroup();
    	jLabelTitle = new javax.swing.JLabel();
        jButtonCurso = new javax.swing.JButton();
        jButtonCerrar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabelNombre = new javax.swing.JLabel();
        jLabelCarnet = new javax.swing.JLabel();
        jTextFieldNombre = new javax.swing.JTextField();
        jLabelApellidos = new javax.swing.JLabel();
        jLabelEmail = new javax.swing.JLabel();
        jLabelTelefono = new javax.swing.JLabel();
        jLabelDNI = new javax.swing.JLabel();
        jTextFieldDescripcion = new javax.swing.JTextField();
        jTextFieldPlazas = new javax.swing.JTextField();
        jTextFieldPrecio = new javax.swing.JTextField();
        jDateChooserInicio = new com.toedter.calendar.JDateChooser();
        jDateChooserFin = new com.toedter.calendar.JDateChooser();
        jLabelAvisoNombre = new javax.swing.JLabel();
        jLabelAvisoDescripcion = new javax.swing.JLabel();
        jLabelAvisoFechaI = new javax.swing.JLabel();
        jLabelAvisoFechaF = new javax.swing.JLabel();
        jLabelAvisoPlazas = new javax.swing.JLabel();
        jLabelAvisoPrecio = new javax.swing.JLabel();
        jTextFieldCorreo = new javax.swing.JTextField();
        jLabelAvisoCorreo = new javax.swing.JLabel();
        jTextFieldDescuento = new javax.swing.JTextField();
        jLabelAvisoDescuento = new javax.swing.JLabel();
        jLabelDescuento = new javax.swing.JLabel();
        jLabelCorreo = new javax.swing.JLabel();
        jLabelTasa = new javax.swing.JLabel();
        jTextFieldTasa = new javax.swing.JTextField();
        jLabelAvisoTasa = new javax.swing.JLabel();
        jLabelAula = new javax.swing.JLabel();
        jTextFieldAula = new javax.swing.JTextField();
        jLabelAvisoAula = new javax.swing.JLabel();
        jTextFieldIdCentro = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabelAvisoIdCentro = new javax.swing.JLabel();
        jRadioButtonDistancia = new javax.swing.JRadioButton();
        jRadioButtonPresencial = new javax.swing.JRadioButton();
        jLabelFont = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitle.setText("Biblioteca J.K");
        getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, -1, -1));

        jButtonCurso.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCurso.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCurso.setText("Guardar Curso");
        jButtonCurso.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCurso.setContentAreaFilled(false);
        jButtonCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAltaCursoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCurso, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 610, 450, -1));

        jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCerrar.setText("Cancelar");
        jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCerrar.setContentAreaFilled(false);
        jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 650, 450, -1));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Alta Curso");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, -1, -1));

        jLabelNombre.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelNombre.setForeground(new java.awt.Color(255, 255, 255));
        jLabelNombre.setText("Nombre del Curso:");
        getContentPane().add(jLabelNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, 30));

        jLabelCarnet.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelCarnet.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCarnet.setText("Fecha de Fin:");
        getContentPane().add(jLabelCarnet, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, 30));

        jTextFieldNombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldNombre.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextFieldNombre.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 100, 210, 30));

        jLabelApellidos.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelApellidos.setForeground(new java.awt.Color(255, 255, 255));
        jLabelApellidos.setText("Descripción:");
        getContentPane().add(jLabelApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, 30));

        jLabelEmail.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelEmail.setForeground(new java.awt.Color(255, 255, 255));
        jLabelEmail.setText("Nº de plazas:");
        getContentPane().add(jLabelEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, -1, 30));

        jLabelTelefono.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelTelefono.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTelefono.setText("Precio:");
        getContentPane().add(jLabelTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, -1, 30));

        jLabelDNI.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelDNI.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDNI.setText("Fecha Inicio:");
        getContentPane().add(jLabelDNI, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, 30));

        jTextFieldDescripcion.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldDescripcion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 150, 210, 30));

        jTextFieldPlazas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldPlazas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldPlazas, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 300, 210, 30));

        jTextFieldPrecio.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldPrecio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 350, 210, 30));
        getContentPane().add(jDateChooserInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 200, 210, 30));
        getContentPane().add(jDateChooserFin, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 250, 210, 30));

        jLabelAvisoNombre.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoNombre.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoNombre.setText("Este campo solo puede contener letras");
        getContentPane().add(jLabelAvisoNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 130, 240, 20));

        jLabelAvisoDescripcion.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoDescripcion.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoDescripcion.setText("Este campo es obligatorio");
        getContentPane().add(jLabelAvisoDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 240, 20));

        jLabelAvisoFechaI.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoFechaI.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoFechaI.setText("Este campo es obligatorio");
        getContentPane().add(jLabelAvisoFechaI, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 230, 260, 20));

        jLabelAvisoFechaF.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoFechaF.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoFechaF.setText("Este campo es obligatorio");
        getContentPane().add(jLabelAvisoFechaF, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 280, 250, 20));

        jLabelAvisoPlazas.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoPlazas.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoPlazas.setText("Este campo solo puede contener números");
        getContentPane().add(jLabelAvisoPlazas, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 330, 250, 20));

        jLabelAvisoPrecio.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoPrecio.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoPrecio.setText("Puede ser un número entero o con decimales");
        getContentPane().add(jLabelAvisoPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 380, 260, 20));

        jTextFieldCorreo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldCorreo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldCorreo.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 500, 210, 30));

        jLabelAvisoCorreo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoCorreo.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoCorreo.setText("Introduzca un email válido");
        getContentPane().add(jLabelAvisoCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 530, 210, 20));

        jTextFieldDescuento.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldDescuento.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldDescuento.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldDescuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 550, 210, 30));

        jLabelAvisoDescuento.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoDescuento.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoDescuento.setText("Debe ser un número mayor o igual que 0");
        getContentPane().add(jLabelAvisoDescuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 580, 250, 20));

        jLabelDescuento.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelDescuento.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDescuento.setText("Descuento:");
        getContentPane().add(jLabelDescuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 550, -1, 30));

        jLabelCorreo.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelCorreo.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCorreo.setText("Correo entregas:");
        getContentPane().add(jLabelCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, -1, 30));

        jLabelTasa.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelTasa.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTasa.setText("Tasa:");
        getContentPane().add(jLabelTasa, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 550, -1, 30));

        jTextFieldTasa.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldTasa.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldTasa.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldTasa, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 550, 210, 30));

        jLabelAvisoTasa.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoTasa.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoTasa.setText("Debe ser un número con o sin decimales");
        getContentPane().add(jLabelAvisoTasa, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 580, 250, 20));

        jLabelAula.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelAula.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAula.setText("Aula:");
        getContentPane().add(jLabelAula, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, -1, 30));

        jTextFieldAula.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldAula.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldAula.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldAula, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 500, 210, 30));

        jLabelAvisoAula.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoAula.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoAula.setText("Debe ser un número mayor que 0");
        getContentPane().add(jLabelAvisoAula, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 530, 210, 20));

        jTextFieldIdCentro.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldIdCentro.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldIdCentro.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldIdCentro, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 400, 210, 30));

        jLabel2.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Id del Centro:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, -1, 30));

        jLabelAvisoIdCentro.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoIdCentro.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoIdCentro.setText("Debe ser un número mayor que 0");
        getContentPane().add(jLabelAvisoIdCentro, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 430, 210, 20));

        jRadioButtonDistancia.setFont(new java.awt.Font("Old English Text MT", 0, 18)); // NOI18N
        jRadioButtonDistancia.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButtonDistancia.setText("A Distancia");
        jRadioButtonDistancia.setContentAreaFilled(false);
        jRadioButtonDistancia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonDistanciaActionPerformed(evt);
            }
        });
        getContentPane().add(jRadioButtonDistancia, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 460, -1, -1));

        jRadioButtonPresencial.setFont(new java.awt.Font("Old English Text MT", 0, 18)); // NOI18N
        jRadioButtonPresencial.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButtonPresencial.setText("Presencial");
        jRadioButtonPresencial.setContentAreaFilled(false);
        jRadioButtonPresencial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonPresencialActionPerformed(evt);
            }
        });
        getContentPane().add(jRadioButtonPresencial, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 460, -1, -1));

        jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
        getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 690));

        pack();
    }
    
    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {
    	this.clearData();
        Controlador.getInstance().accion(new Contexto(Events.GUI_CURSO, null));
    }
    
    private void jRadioButtonDistanciaActionPerformed(java.awt.event.ActionEvent evt) {                                                      
        this.jLabelAula.setVisible(false);
        this.jTextFieldAula.setVisible(false);
        this.jLabelAvisoAula.setVisible(false);
        this.jLabelTasa.setVisible(false);
        this.jTextFieldTasa.setVisible(false);
        this.jLabelAvisoTasa.setVisible(false);
        this.jLabelCorreo.setVisible(true);
        this.jTextFieldCorreo.setVisible(true);
        this.jLabelDescuento.setVisible(true);
        this.jTextFieldDescuento.setVisible(true);
        this.jTextFieldAula.setText("");
        this.jTextFieldTasa.setText("");
    }                                                     

    private void jRadioButtonPresencialActionPerformed(java.awt.event.ActionEvent evt) {                                                       
        this.jLabelAula.setVisible(true);
        this.jTextFieldAula.setVisible(true);
        this.jLabelTasa.setVisible(true);
        this.jTextFieldTasa.setVisible(true);
        this.jLabelCorreo.setVisible(false);
        this.jTextFieldCorreo.setVisible(false);
        this.jLabelAvisoCorreo.setVisible(false);
        this.jLabelDescuento.setVisible(false);
        this.jLabelAvisoDescuento.setVisible(false);
        this.jTextFieldDescuento.setVisible(false);
        this.jTextFieldCorreo.setText("");
        this.jTextFieldDescuento.setText("");
    }

    private void jButtonAltaCursoActionPerformed(java.awt.event.ActionEvent evt) {
        int nErrores = 0, plazas = 0, idCentro = 0, descuento = 0, aula = 0;
        double precio = 0, tasa = 0;
        String nombre="", descripcion="", correo = "";
        Date fechaI = null, fechaF = null;
    	if(!this.jTextFieldNombre.getText().matches("^(?!\\s*$).+")){
    		nErrores++;
    		this.jLabelAvisoNombre.setVisible(true);
    	}
    	else {
    		nombre = this.jTextFieldNombre.getText();
    		this.jLabelAvisoNombre.setVisible(false);
    	}
    	if(!this.jTextFieldDescripcion.getText().matches("^(?!\\s*$).+")){
    		nErrores++;
    		this.jLabelAvisoDescripcion.setVisible(true);
    	}
    	else {
    		descripcion = this.jTextFieldDescripcion.getText();
    		this.jLabelAvisoDescripcion.setVisible(false);
    	}
        if(this.jDateChooserInicio.getDate() == null){
    		nErrores++;
    		this.jLabelAvisoFechaI.setVisible(true);
    	}
    	else {
    		fechaI = this.jDateChooserInicio.getDate();
    		this.jLabelAvisoFechaI.setVisible(false);
    	}
    	if(this.jDateChooserFin.getDate() == null){
    		nErrores++;
    		this.jLabelAvisoFechaF.setVisible(true);
    	}
    	else {
    		fechaF = this.jDateChooserFin.getDate();
    		this.jLabelAvisoFechaF.setVisible(false);
    	}
    	if(!this.jTextFieldPlazas.getText().matches("^([1-9]{1}[0-9]*)$")) {
    		nErrores++;
    		this.jLabelAvisoPlazas.setVisible(true);
    	}
    	else {
    		plazas = Integer.parseInt(this.jTextFieldPlazas.getText());
    		this.jLabelAvisoPlazas.setVisible(false);
    	}
    	if(!this.jTextFieldPrecio.getText().matches("^([0-9]{0,1}[0-9]*.{0,1}[0-9]{1,})$")) {
    		nErrores++;
    		this.jLabelAvisoPrecio.setVisible(true);
    	}
    	else{
    		precio = Double.parseDouble(this.jTextFieldPrecio.getText());
    		this.jLabelAvisoPrecio.setVisible(false);
    	}
    	
    	if(!this.jTextFieldIdCentro.getText().matches("^([1-9]{1}[0-9]*)$")) {
    		nErrores++;
    		this.jLabelAvisoIdCentro.setVisible(true);
    	}
    	else{
    		idCentro = Integer.parseInt(this.jTextFieldIdCentro.getText());
    		this.jLabelAvisoIdCentro.setVisible(false);
    	}
    	
    	if(nErrores == 0) {
    		if(this.jRadioButtonDistancia.isSelected()){
    			if(!this.jTextFieldCorreo.getText().matches("^([^@]+@[^@]+\\.[a-zA-Z]{2,})$")) {
    	    		nErrores++;
    	    		this.jLabelAvisoCorreo.setVisible(true);
    	    	}
    	    	else {
    	    		correo = this.jTextFieldCorreo.getText();
    	    		this.jLabelAvisoCorreo.setVisible(false);
    	    	}
    	    	
    	    	if(!this.jTextFieldDescuento.getText().matches("^([1-9]{1}[0-9]*)$")) {
    	    		nErrores++;
    	    		this.jLabelAvisoDescuento.setVisible(true);
    	    	}
    	    	else{
    	    		descuento = Integer.parseInt(this.jTextFieldDescuento.getText());
    	    		this.jLabelAvisoDescuento.setVisible(false);
    	    	}
    	    	if(nErrores == 0){
    	    		TCursoADistancia tCursDist = new TCursoADistancia(nombre,descripcion, fechaI, fechaF, plazas,
        					precio, 0, idCentro, true, correo, descuento);
    	    		Controlador.getInstance().accion(new Contexto(Events.GUI_ALTA_CURSO, tCursDist));
    	    	}
    		}
    		else if(this.jRadioButtonPresencial.isSelected()){
    			if(!this.jTextFieldAula.getText().matches("^([1-9]{1}[0-9]*)$")) {
    	    		nErrores++;
    	    		this.jLabelAvisoAula.setVisible(true);
    	    	}
    	    	else{
    	    		aula = Integer.parseInt(this.jTextFieldAula.getText());
    	    		this.jLabelAvisoAula.setVisible(false);
    	    	}
    			
    			if(!this.jTextFieldTasa.getText().matches("^([0-9]{0,1}[0-9]*.{0,1}[0-9]{1,})$")) {
    	    		nErrores++;
    	    		this.jLabelAvisoTasa.setVisible(true);
    	    	}
    	    	else{
    	    		tasa = Double.parseDouble(this.jTextFieldTasa.getText());
    	    		this.jLabelAvisoTasa.setVisible(false);
    	    	}
    			
    			if(nErrores == 0){
    				TCursoPresencial tCursPres = new TCursoPresencial(nombre, descripcion, fechaI, fechaF, plazas,
    						precio, 0, idCentro, true, aula, tasa);
    				Controlador.getInstance().accion(new Contexto(Events.GUI_ALTA_CURSO, tCursPres));
    			}
    			
    		}
    	}
    }
    
 // Variables declaration - do not modify        
    private javax.swing.ButtonGroup buttonGroup;
    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonCurso;
    private com.toedter.calendar.JDateChooser jDateChooserFin;
    private com.toedter.calendar.JDateChooser jDateChooserInicio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelApellidos;
    private javax.swing.JLabel jLabelAula;
    private javax.swing.JLabel jLabelAvisoAula;
    private javax.swing.JLabel jLabelAvisoCorreo;
    private javax.swing.JLabel jLabelAvisoDescripcion;
    private javax.swing.JLabel jLabelAvisoDescuento;
    private javax.swing.JLabel jLabelAvisoFechaF;
    private javax.swing.JLabel jLabelAvisoFechaI;
    private javax.swing.JLabel jLabelAvisoIdCentro;
    private javax.swing.JLabel jLabelAvisoNombre;
    private javax.swing.JLabel jLabelAvisoPlazas;
    private javax.swing.JLabel jLabelAvisoPrecio;
    private javax.swing.JLabel jLabelAvisoTasa;
    private javax.swing.JLabel jLabelCarnet;
    private javax.swing.JLabel jLabelCorreo;
    private javax.swing.JLabel jLabelDNI;
    private javax.swing.JLabel jLabelDescuento;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelTasa;
    private javax.swing.JLabel jLabelTelefono;
    private javax.swing.JLabel jLabelTitle;
    private javax.swing.JRadioButton jRadioButtonDistancia;
    private javax.swing.JRadioButton jRadioButtonPresencial;
    private javax.swing.JTextField jTextFieldAula;
    private javax.swing.JTextField jTextFieldCorreo;
    private javax.swing.JTextField jTextFieldDescripcion;
    private javax.swing.JTextField jTextFieldDescuento;
    private javax.swing.JTextField jTextFieldIdCentro;
    private javax.swing.JTextField jTextFieldNombre;
    private javax.swing.JTextField jTextFieldPlazas;
    private javax.swing.JTextField jTextFieldPrecio;
    private javax.swing.JTextField jTextFieldTasa;
    // End of variables declaration   
	@Override
	public void actualizar(Contexto contexto) {}

	public void clearData() {
		this.jTextFieldNombre.setText("");
		this.jTextFieldDescripcion.setText("");
		this.jTextFieldPlazas.setText("");
		this.jTextFieldPrecio.setText("");
		this.jTextFieldIdCentro.setText("");
		this.jTextFieldCorreo.setText("");
		this.jTextFieldDescuento.setText("");
		this.jTextFieldAula.setText("");
		this.jTextFieldTasa.setText("");
		this.jLabelAvisoAula.setVisible(false);
		this.jLabelAvisoCorreo.setVisible(false);
		this.jLabelAvisoDescripcion.setVisible(false);
		this.jLabelAvisoDescuento.setVisible(false);
		this.jLabelAvisoFechaF.setVisible(false);
		this.jLabelAvisoFechaI.setVisible(false);
		this.jLabelAvisoIdCentro.setVisible(false);
		this.jLabelAvisoNombre.setVisible(false);
		this.jLabelAvisoPlazas.setVisible(false);
		this.jLabelAvisoPrecio.setVisible(false);
		this.jLabelAvisoTasa.setVisible(false);
		this.jDateChooserInicio.setDate(null);
		this.jDateChooserFin.setDate(null);
		this.buttonGroup.clearSelection();
		this.jTextFieldAula.setVisible(false);
		this.jTextFieldCorreo.setVisible(false);
		this.jTextFieldDescuento.setVisible(false);
		this.jTextFieldTasa.setVisible(false);
		this.jLabelAula.setVisible(false);
		this.jLabelTasa.setVisible(false);
		this.jLabelDescuento.setVisible(false);
		this.jLabelCorreo.setVisible(false);
		this.setVisible(false);
	}
}
