package Diseno.Presentacion.Curso;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import Diseno.Negocio.Curso.TCurso;
import Diseno.Negocio.Curso.TCursoADistancia;
import Diseno.Negocio.Curso.TCursoPresencial;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUI;
import Diseno.Presentacion.Controlador.Controlador;
import rojerusan.necesario.RSScrollBar;

public class GUIMostrarCursos  extends JFrame implements GUI {

    public GUIMostrarCursos() {
    	initComponents();
        this.setLocationRelativeTo(null);
        jScrollPaneTabla.getVerticalScrollBar().setUI(new RSScrollBar());
        jScrollPaneTabla.getViewport().setBackground(Color.WHITE);
        rSTableMetro1.getColumnModel().getColumn(0).setPreferredWidth(10);
        rSTableMetro1.getColumnModel().getColumn(1).setPreferredWidth(10);
        rSTableMetro1.getColumnModel().getColumn(2).setPreferredWidth(50);
        rSTableMetro1.getColumnModel().getColumn(3).setPreferredWidth(50);
        rSTableMetro1.getColumnModel().getColumn(4).setPreferredWidth(50);
        rSTableMetro1.getColumnModel().getColumn(5).setPreferredWidth(50);
        rSTableMetro1.getColumnModel().getColumn(6).setPreferredWidth(50);
        rSTableMetro1.getColumnModel().getColumn(7).setPreferredWidth(50);
        rSTableMetro1.getColumnModel().getColumn(8).setPreferredWidth(50);
        rSTableMetro1.getColumnModel().getColumn(9).setPreferredWidth(40);
        rSTableMetro1.getColumnModel().getColumn(10).setPreferredWidth(40);
        rSTableMetro1.getColumnModel().getColumn(11).setPreferredWidth(40);
        rSTableMetro1.getColumnModel().getColumn(12).setPreferredWidth(40);
        rSTableMetro1.getColumnModel().getColumn(13).setPreferredWidth(40);
    }

    @SuppressWarnings("unchecked")
   
    private void initComponents() {

    	jLabelTitle = new javax.swing.JLabel();
        jButtonMostrarClientes = new javax.swing.JButton();
        jButtonCerrar = new javax.swing.JButton();
        jLabelMostrarClientes = new javax.swing.JLabel();
        jPanelTabla = new javax.swing.JPanel();
        jScrollPaneTabla = new javax.swing.JScrollPane();
        rSTableMetro1 = new rojerusan.RSTableMetro();
        jLabelFont = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitle.setText("Biblioteca J.K");
        getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 70, -1, -1));

        jButtonMostrarClientes.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMostrarClientes.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMostrarClientes.setText("Mostrar Cursos");
        jButtonMostrarClientes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMostrarClientes.setContentAreaFilled(false);
        jButtonMostrarClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMostrarClientesActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMostrarClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 460, 450, -1));

        jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCerrar.setText("Volver");
        jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCerrar.setContentAreaFilled(false);
        jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 500, 450, -1));

        jLabelMostrarClientes.setBackground(new java.awt.Color(255, 255, 255));
        jLabelMostrarClientes.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelMostrarClientes.setForeground(new java.awt.Color(255, 255, 255));
        jLabelMostrarClientes.setText("Mostrar Cursos");
        getContentPane().add(jLabelMostrarClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 130, -1, -1));

        jPanelTabla.setBackground(new java.awt.Color(255, 255, 255));
        jPanelTabla.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPaneTabla.setBackground(new java.awt.Color(153, 51, 0));
        jScrollPaneTabla.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        rSTableMetro1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nº", "Id", "Nombre", "Descripción", "Fecha Ini", "Fecha Fin", "Plazas", "Precio", "Matriculados", "Centro", "Aula", "Tasa", "Correo", "Descuento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        rSTableMetro1.setColorBackgoundHead(new java.awt.Color(153, 51, 0));
        rSTableMetro1.setColorFilasBackgound2(new java.awt.Color(204, 102, 0));
        rSTableMetro1.setColorFilasForeground1(new java.awt.Color(0, 0, 0));
        rSTableMetro1.setColorFilasForeground2(new java.awt.Color(255, 255, 255));
        rSTableMetro1.setColorSelBackgound(new java.awt.Color(102, 51, 0));
        jScrollPaneTabla.setViewportView(rSTableMetro1);

        jPanelTabla.add(jScrollPaneTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 260));

        getContentPane().add(jPanelTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 1010, 260));

        jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
        getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1030, 540));

        pack();
    }

    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCerrarActionPerformed
    	DefaultTableModel model = (DefaultTableModel) rSTableMetro1.getModel();
		model.setRowCount(0);
		this.rSTableMetro1.setModel(model);
		this.setVisible(false);
        Controlador.getInstance().accion(new Contexto(Events.GUI_CURSO, null));
    }

    private void jButtonMostrarClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMostrarClientesActionPerformed
    	 Controlador.getInstance().accion(new Contexto(Events.GUI_MOSTRAR_CURSOS, null));
    }

    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonMostrarClientes;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelMostrarClientes;
    private javax.swing.JLabel jLabelTitle;
    private javax.swing.JPanel jPanelTabla;
    private javax.swing.JScrollPane jScrollPaneTabla;
    private rojerusan.RSTableMetro rSTableMetro1;
   
	@Override
	public void actualizar(Contexto contexto) {
		ArrayList<TCurso> tCurso = (ArrayList<TCurso>) contexto.getDato();
		DefaultTableModel model = (DefaultTableModel) rSTableMetro1.getModel();
		model.setRowCount(0);
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		for(int i = 0; i < tCurso.size(); i++) {
			Object [] fila=new Object[14];
			fila[0] = i + 1;
			fila[1] = tCurso.get(i).getID();
			fila[2] = tCurso.get(i).getNombre();
			fila[3] = tCurso.get(i).getDescripcion();
			fila[4] = sdf.format(tCurso.get(i).getFechaInicio());
			fila[5] = sdf.format(tCurso.get(i).getFechaFinal());
			fila[6] = tCurso.get(i).getNumPlazas();
			fila[7] = tCurso.get(i).getPrecio();
			fila[8] = tCurso.get(i).getNumMatriculados();
			fila[9] = tCurso.get(i).getIDCentro();
			if(tCurso.get(i) instanceof TCursoADistancia){
				TCursoADistancia tCursoDist = (TCursoADistancia) tCurso.get(i);
				fila[12] = tCursoDist.getCorreo();
				fila[13] = tCursoDist.getDescuento();
			}
			else{
				TCursoPresencial tCursoPres = (TCursoPresencial) tCurso.get(i);
				fila[10] = tCursoPres.getAula();
				fila[11] = tCursoPres.getTasa();
			}
			model.addRow(fila);
		}
		this.rSTableMetro1.setModel(model);
	}
}
