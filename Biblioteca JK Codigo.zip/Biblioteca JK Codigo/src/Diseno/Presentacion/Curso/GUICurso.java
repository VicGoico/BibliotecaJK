package Diseno.Presentacion.Curso;

import Diseno.Presentacion.GUI;

import javax.swing.JFrame;

import Diseno.Presentacion.Contexto;

public abstract class GUICurso extends JFrame implements GUI {
	
	private static GUICurso instancia;

	public static GUICurso getInstance() {
		
		if(instancia == null) {
			instancia = new GUICursoImp();
		}
		return instancia;
	}

	public abstract void actualizar(Contexto contexto);
}