package Diseno.Presentacion.Curso;

import java.util.Date;
import javax.swing.JFrame;

import Diseno.Negocio.Curso.TCurso;
import Diseno.Negocio.Curso.TCursoADistancia;
import Diseno.Negocio.Curso.TCursoPresencial;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUI;
import Diseno.Presentacion.Controlador.Controlador;

public class GUIActualizarCurso  extends JFrame implements GUI {

    public GUIActualizarCurso() {
    	initComponents();
        this.setLocationRelativeTo(null);
        this.jLabelAvisoId.setVisible(false);
        this.jLabelAvisoCorreo.setVisible(false);
        this.jLabelAvisoDescripcion.setVisible(false);
        this.jLabelAvisoDescuento.setVisible(false);
        this.jLabelAvisoFechaF.setVisible(false);
        this.jLabelAvisoFechaI.setVisible(false);
        this.jLabelAvisoNombre.setVisible(false);
        this.jLabelAvisoPlazas.setVisible(false);
        this.jLabelAvisoPrecio.setVisible(false);
        this.jLabelAvisoIdCentro.setVisible(false);
        this.jLabelAvisoTasa.setVisible(false);
        this.jLabelAvisoAula.setVisible(false);
    }

     @SuppressWarnings("unchecked")
     
     private void initComponents() {

    	 jLabelTitle = new javax.swing.JLabel();
         jButtonCurso = new javax.swing.JButton();
         jButtonCerrar = new javax.swing.JButton();
         jLabel1 = new javax.swing.JLabel();
         jLabelId = new javax.swing.JLabel();
         jLabelAvisoId = new javax.swing.JLabel();
         jTextFieldId = new javax.swing.JTextField();
         jLabelNombre = new javax.swing.JLabel();
         jTextFieldNombre = new javax.swing.JTextField();
         jTextFieldDescripcion = new javax.swing.JTextField();
         jLabelApellidos = new javax.swing.JLabel();
         jLabelDNI = new javax.swing.JLabel();
         jLabelCarnet = new javax.swing.JLabel();
         jLabelEmail = new javax.swing.JLabel();
         jTextFieldPlazas = new javax.swing.JTextField();
         jLabelTelefono = new javax.swing.JLabel();
         jTextFieldPrecio = new javax.swing.JTextField();
         jLabelAvisoNombre = new javax.swing.JLabel();
         jLabelAvisoDescripcion = new javax.swing.JLabel();
         jLabelAvisoFechaI = new javax.swing.JLabel();
         jLabelAvisoFechaF = new javax.swing.JLabel();
         jLabelAvisoPlazas = new javax.swing.JLabel();
         jLabelAvisoPrecio = new javax.swing.JLabel();
         jDateChooserInicio = new com.toedter.calendar.JDateChooser();
         jDateChooserFin = new com.toedter.calendar.JDateChooser();
         jLabel2 = new javax.swing.JLabel();
         jTextFieldIdCentro = new javax.swing.JTextField();
         jLabelAvisoIdCentro = new javax.swing.JLabel();
         jLabelCorreo = new javax.swing.JLabel();
         jTextFieldCorreo = new javax.swing.JTextField();
         jLabelDescuento = new javax.swing.JLabel();
         jTextFieldDescuento = new javax.swing.JTextField();
         jLabelTasa = new javax.swing.JLabel();
         jLabelAula = new javax.swing.JLabel();
         jTextFieldTasa = new javax.swing.JTextField();
         jTextFieldAula = new javax.swing.JTextField();
         jLabelAvisoCorreo = new javax.swing.JLabel();
         jLabelAvisoDescuento = new javax.swing.JLabel();
         jLabelAvisoTasa = new javax.swing.JLabel();
         jLabelAvisoAula = new javax.swing.JLabel();
         jLabelFont = new javax.swing.JLabel();

         setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
         setUndecorated(true);
         getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

         jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
         jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
         jLabelTitle.setText("Biblioteca J.K");
         getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, -1, -1));

         jButtonCurso.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jButtonCurso.setForeground(new java.awt.Color(255, 255, 255));
         jButtonCurso.setText("Guardar Curso");
         jButtonCurso.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
         jButtonCurso.setContentAreaFilled(false);
         jButtonCurso.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 jButtonActualizarCursoActionPerformed(evt);
             }
         });
         getContentPane().add(jButtonCurso, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 620, 450, -1));

         jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
         jButtonCerrar.setText("Cancelar");
         jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
         jButtonCerrar.setContentAreaFilled(false);
         jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 jButtonCerrarActionPerformed(evt);
             }
         });
         getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 660, 450, -1));

         jLabel1.setBackground(new java.awt.Color(255, 255, 255));
         jLabel1.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabel1.setForeground(new java.awt.Color(255, 255, 255));
         jLabel1.setText("Actualizar Curso");
         getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, -1, -1));

         jLabelId.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabelId.setForeground(new java.awt.Color(255, 255, 255));
         jLabelId.setText("Id:");
         getContentPane().add(jLabelId, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, 30));

         jLabelAvisoId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoId.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoId.setText("Debe ser un número mayor que 0");
         getContentPane().add(jLabelAvisoId, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 140, 230, 20));
         
         jTextFieldId.setEditable(false);
         jTextFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
         jTextFieldId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
         jTextFieldId.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
         jTextFieldId.setSelectionColor(new java.awt.Color(153, 51, 0));
         getContentPane().add(jTextFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 110, 230, 30));

         jLabelNombre.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabelNombre.setForeground(new java.awt.Color(255, 255, 255));
         jLabelNombre.setText("Nombre del Curso:");
         getContentPane().add(jLabelNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, 30));

         jTextFieldNombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
         jTextFieldNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
         jTextFieldNombre.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
         jTextFieldNombre.setSelectionColor(new java.awt.Color(153, 51, 0));
         getContentPane().add(jTextFieldNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 160, 230, 30));

         jTextFieldDescripcion.setHorizontalAlignment(javax.swing.JTextField.CENTER);
         jTextFieldDescripcion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
         getContentPane().add(jTextFieldDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 210, 230, 30));

         jLabelApellidos.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabelApellidos.setForeground(new java.awt.Color(255, 255, 255));
         jLabelApellidos.setText("Descripción:");
         getContentPane().add(jLabelApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, -1, 30));

         jLabelDNI.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabelDNI.setForeground(new java.awt.Color(255, 255, 255));
         jLabelDNI.setText("Fecha Inicio:");
         getContentPane().add(jLabelDNI, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, -1, 30));

         jLabelCarnet.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabelCarnet.setForeground(new java.awt.Color(255, 255, 255));
         jLabelCarnet.setText("Fecha de Fin:");
         getContentPane().add(jLabelCarnet, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, -1, 30));

         jLabelEmail.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabelEmail.setForeground(new java.awt.Color(255, 255, 255));
         jLabelEmail.setText("Nº de plazas:");
         getContentPane().add(jLabelEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, -1, 30));

         jTextFieldPlazas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
         jTextFieldPlazas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
         getContentPane().add(jTextFieldPlazas, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 360, 230, 30));

         jLabelTelefono.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabelTelefono.setForeground(new java.awt.Color(255, 255, 255));
         jLabelTelefono.setText("Precio:");
         getContentPane().add(jLabelTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, -1, 30));

         jTextFieldPrecio.setHorizontalAlignment(javax.swing.JTextField.CENTER);
         jTextFieldPrecio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
         getContentPane().add(jTextFieldPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 410, 230, 30));

         jLabelAvisoNombre.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoNombre.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoNombre.setText("Este campo solo puede contener letras");
         getContentPane().add(jLabelAvisoNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 190, 250, 20));

         jLabelAvisoDescripcion.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoDescripcion.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoDescripcion.setText("Este campo es obligatorio");
         getContentPane().add(jLabelAvisoDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 240, 250, 20));

         jLabelAvisoFechaI.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoFechaI.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoFechaI.setText("Este campo es obligatorio");
         getContentPane().add(jLabelAvisoFechaI, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 290, 270, 20));

         jLabelAvisoFechaF.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoFechaF.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoFechaF.setText("Este campo es obligatorio");
         getContentPane().add(jLabelAvisoFechaF, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 340, 260, 20));

         jLabelAvisoPlazas.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoPlazas.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoPlazas.setText("Este campo solo puede contener números");
         getContentPane().add(jLabelAvisoPlazas, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 390, 260, 20));

         jLabelAvisoPrecio.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoPrecio.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoPrecio.setText("Puede ser un número entero o con decimales");
         getContentPane().add(jLabelAvisoPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 440, 270, 20));
         getContentPane().add(jDateChooserInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 260, 230, 30));
         getContentPane().add(jDateChooserFin, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 310, 230, 30));

         jLabel2.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabel2.setForeground(new java.awt.Color(255, 255, 255));
         jLabel2.setText("Id del Centro:");
         getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, -1, 30));

         jTextFieldIdCentro.setHorizontalAlignment(javax.swing.JTextField.CENTER);
         jTextFieldIdCentro.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
         jTextFieldIdCentro.setSelectionColor(new java.awt.Color(153, 51, 0));
         getContentPane().add(jTextFieldIdCentro, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 460, 230, 30));

         jLabelAvisoIdCentro.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoIdCentro.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoIdCentro.setText("Debe ser un número mayor que 0");
         getContentPane().add(jLabelAvisoIdCentro, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 490, 210, 20));

         jLabelCorreo.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabelCorreo.setForeground(new java.awt.Color(255, 255, 255));
         jLabelCorreo.setText("Correo entregas:");
         getContentPane().add(jLabelCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, -1, 30));

         jTextFieldCorreo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
         jTextFieldCorreo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
         jTextFieldCorreo.setSelectionColor(new java.awt.Color(153, 51, 0));
         getContentPane().add(jTextFieldCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 510, 230, 30));

         jLabelDescuento.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabelDescuento.setForeground(new java.awt.Color(255, 255, 255));
         jLabelDescuento.setText("Descuento:");
         getContentPane().add(jLabelDescuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 560, -1, 30));

         jTextFieldDescuento.setHorizontalAlignment(javax.swing.JTextField.CENTER);
         jTextFieldDescuento.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
         jTextFieldDescuento.setSelectionColor(new java.awt.Color(153, 51, 0));
         getContentPane().add(jTextFieldDescuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 560, 230, 30));

         jLabelTasa.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabelTasa.setForeground(new java.awt.Color(255, 255, 255));
         jLabelTasa.setText("Tasa:");
         getContentPane().add(jLabelTasa, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 560, -1, 30));

         jLabelAula.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
         jLabelAula.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAula.setText("Aula:");
         getContentPane().add(jLabelAula, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, -1, 30));

         jTextFieldTasa.setHorizontalAlignment(javax.swing.JTextField.CENTER);
         jTextFieldTasa.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
         jTextFieldTasa.setSelectionColor(new java.awt.Color(153, 51, 0));
         getContentPane().add(jTextFieldTasa, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 560, 230, 30));

         jTextFieldAula.setHorizontalAlignment(javax.swing.JTextField.CENTER);
         jTextFieldAula.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
         jTextFieldAula.setSelectionColor(new java.awt.Color(153, 51, 0));
         getContentPane().add(jTextFieldAula, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 510, 230, 30));

         jLabelAvisoCorreo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoCorreo.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoCorreo.setText("Introduzca un email válido");
         getContentPane().add(jLabelAvisoCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 540, 210, 20));

         jLabelAvisoDescuento.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoDescuento.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoDescuento.setText("Debe ser un número mayor o igual que 0");
         getContentPane().add(jLabelAvisoDescuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 590, 250, 20));

         jLabelAvisoTasa.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoTasa.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoTasa.setText("Debe ser un número con o sin decimales");
         getContentPane().add(jLabelAvisoTasa, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 590, 250, 20));

         jLabelAvisoAula.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
         jLabelAvisoAula.setForeground(new java.awt.Color(255, 255, 255));
         jLabelAvisoAula.setText("Debe ser un número mayor que 0");
         getContentPane().add(jLabelAvisoAula, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 540, 210, 20));

         jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
         getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 700));

         pack();
    }

    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {
    	this.setVisible(false);
        Controlador.getInstance().accion(new Contexto(Events.GUI_CURSO, null));
    }

    private void jButtonActualizarCursoActionPerformed(java.awt.event.ActionEvent evt) {
    	int nErrores = 0, plazas = 0, id = 0, descuento = 0, idCentro = 0, aula = 0;
        double precio = 0, tasa = 0;
        String nombre="", descripcion="", correo = "";
        Date fechaI = null, fechaF = null;
        if(!this.jTextFieldId.getText().matches("^([1-9]{1}[0-9]*)$")) {
    		nErrores++;
    		this.jLabelAvisoId.setVisible(true);
    	}
    	else {
    		id = Integer.parseInt(this.jTextFieldId.getText());
    		this.jLabelAvisoId.setVisible(false);
    	}
    	if(!this.jTextFieldNombre.getText().matches("^(?!\\s*$).+")){
    		nErrores++;
    		this.jLabelAvisoNombre.setVisible(true);
    	}
    	else {
    		nombre = this.jTextFieldNombre.getText();
    		this.jLabelAvisoNombre.setVisible(false);
    	}
    	if(!this.jTextFieldDescripcion.getText().matches("^(?!\\s*$).+")){
    		nErrores++;
    		this.jLabelAvisoDescripcion.setVisible(true);
    	}
    	else {
    		descripcion = this.jTextFieldDescripcion.getText();
    		this.jLabelAvisoDescripcion.setVisible(false);
    	}
        if(this.jDateChooserInicio.getDate() == null){
    		nErrores++;
    		this.jLabelAvisoFechaI.setVisible(true);
    	}
    	else {
    		fechaI = this.jDateChooserInicio.getDate();
    		this.jLabelAvisoFechaI.setVisible(false);
    	}
    	if(this.jDateChooserFin.getDate() == null){
    		nErrores++;
    		this.jLabelAvisoFechaF.setVisible(true);
    	}
    	else {
    		fechaF = this.jDateChooserFin.getDate();
    		this.jLabelAvisoFechaF.setVisible(false);
    	}
    	if(!this.jTextFieldPlazas.getText().matches("^([1-9]{1}[0-9]*)$")) {
    		nErrores++;
    		this.jLabelAvisoPlazas.setVisible(true);
    	}
    	else {
    		plazas = Integer.parseInt(this.jTextFieldPlazas.getText());
    		this.jLabelAvisoPlazas.setVisible(false);
    	}
    	if(!this.jTextFieldPrecio.getText().matches("^([0-9]{0,1}[0-9]*.{0,1}[0-9]{1,})$")) {
    		nErrores++;
    		this.jLabelAvisoPrecio.setVisible(true);
    	}
    	else{
    		precio = Double.parseDouble(this.jTextFieldPrecio.getText());
    		this.jLabelAvisoPrecio.setVisible(false);
    	}
    	
    	if(!this.jTextFieldIdCentro.getText().matches("^([1-9]{1}[0-9]*)$")) {
    		nErrores++;
    		this.jLabelAvisoIdCentro.setVisible(true);
    	}
    	else{
    		idCentro = Integer.parseInt(this.jTextFieldIdCentro.getText());
    		this.jLabelAvisoIdCentro.setVisible(false);
    	}
    	
    	if(nErrores == 0) {
    		if(jTextFieldCorreo.isVisible()){
    			if(!this.jTextFieldCorreo.getText().matches("^([^@]+@[^@]+\\.[a-zA-Z]{2,})$")) {
    	    		nErrores++;
    	    		this.jLabelAvisoCorreo.setVisible(true);
    	    	}
    	    	else {
    	    		correo = this.jTextFieldCorreo.getText();
    	    		this.jLabelAvisoCorreo.setVisible(false);
    	    	}
    	    	
    	    	if(!this.jTextFieldDescuento.getText().matches("^([1-9]{1}[0-9]*)$")) {
    	    		nErrores++;
    	    		this.jLabelAvisoDescuento.setVisible(true);
    	    	}
    	    	else{
    	    		descuento = Integer.parseInt(this.jTextFieldDescuento.getText());
    	    		this.jLabelAvisoDescuento.setVisible(false);
    	    	}
    	    	if(nErrores == 0){
    	    		TCursoADistancia tCursDist = new TCursoADistancia(id, nombre,descripcion, fechaI, fechaF, plazas,
        					precio, 0, idCentro, true, correo, descuento);
    	    		Controlador.getInstance().accion(new Contexto(Events.GUI_ACTUALIZAR_CURSO, tCursDist));
    	    	}
    		}
    		else if(jTextFieldAula.isVisible()){
    			if(!this.jTextFieldAula.getText().matches("^([1-9]{1}[0-9]*)$")) {
    	    		nErrores++;
    	    		this.jLabelAvisoAula.setVisible(true);
    	    	}
    	    	else{
    	    		aula = Integer.parseInt(this.jTextFieldAula.getText());
    	    		this.jLabelAvisoAula.setVisible(false);
    	    	}
    			
    			if(!this.jTextFieldTasa.getText().matches("^([0-9]{0,1}[0-9]*.{0,1}[0-9]{1,})$")) {
    	    		nErrores++;
    	    		this.jLabelAvisoTasa.setVisible(true);
    	    	}
    	    	else{
    	    		tasa = Double.parseDouble(this.jTextFieldTasa.getText());
    	    		this.jLabelAvisoTasa.setVisible(false);
    	    	}
    			
    			if(nErrores == 0){
    				TCursoPresencial tCursPres = new TCursoPresencial(id, nombre, descripcion, fechaI, fechaF, plazas,
    						precio, 0, idCentro, true, aula, tasa);
    				Controlador.getInstance().accion(new Contexto(Events.GUI_ACTUALIZAR_CURSO, tCursPres));
    			}
    		}
    	}
    }

 // Variables declaration - do not modify                     
    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonCurso;
    private com.toedter.calendar.JDateChooser jDateChooserFin;
    private com.toedter.calendar.JDateChooser jDateChooserInicio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelApellidos;
    private javax.swing.JLabel jLabelAula;
    private javax.swing.JLabel jLabelAvisoAula;
    private javax.swing.JLabel jLabelAvisoCorreo;
    private javax.swing.JLabel jLabelAvisoDescripcion;
    private javax.swing.JLabel jLabelAvisoDescuento;
    private javax.swing.JLabel jLabelAvisoFechaF;
    private javax.swing.JLabel jLabelAvisoFechaI;
    private javax.swing.JLabel jLabelAvisoId;
    private javax.swing.JLabel jLabelAvisoIdCentro;
    private javax.swing.JLabel jLabelAvisoNombre;
    private javax.swing.JLabel jLabelAvisoPlazas;
    private javax.swing.JLabel jLabelAvisoPrecio;
    private javax.swing.JLabel jLabelAvisoTasa;
    private javax.swing.JLabel jLabelCarnet;
    private javax.swing.JLabel jLabelCorreo;
    private javax.swing.JLabel jLabelDNI;
    private javax.swing.JLabel jLabelDescuento;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelId;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelTasa;
    private javax.swing.JLabel jLabelTelefono;
    private javax.swing.JLabel jLabelTitle;
    private javax.swing.JTextField jTextFieldAula;
    private javax.swing.JTextField jTextFieldCorreo;
    private javax.swing.JTextField jTextFieldDescripcion;
    private javax.swing.JTextField jTextFieldDescuento;
    private javax.swing.JTextField jTextFieldId;
    private javax.swing.JTextField jTextFieldIdCentro;
    private javax.swing.JTextField jTextFieldNombre;
    private javax.swing.JTextField jTextFieldPlazas;
    private javax.swing.JTextField jTextFieldPrecio;
    private javax.swing.JTextField jTextFieldTasa;
    // End of variables declaration  
  
	@Override
	public void actualizar(Contexto contexto) {
		TCurso tCurso = (TCurso) contexto.getDato();
		this.jTextFieldId.setText(""+tCurso.getID());
		this.jTextFieldNombre.setText(tCurso.getNombre());
		this.jTextFieldDescripcion.setText(tCurso.getDescripcion());
		this.jTextFieldPrecio.setText(""+tCurso.getPrecio());
		this.jTextFieldPlazas.setText(""+tCurso.getNumPlazas());
		this.jDateChooserInicio.setDate(tCurso.getFechaInicio());
		this.jDateChooserFin.setDate(tCurso.getFechaFinal());
		this.jTextFieldIdCentro.setText(""+tCurso.getIDCentro());
		if(tCurso instanceof TCursoPresencial){
			TCursoPresencial tCursoPres = (TCursoPresencial) tCurso;
			this.jLabelTasa.setVisible(true);
			this.jTextFieldTasa.setText(""+tCursoPres.getTasa());
			this.jTextFieldTasa.setVisible(true);
			this.jLabelAula.setVisible(true);
			this.jTextFieldAula.setText(""+tCursoPres.getAula());
			this.jTextFieldAula.setVisible(true);
			this.jLabelCorreo.setVisible(false);
			this.jTextFieldCorreo.setVisible(false);
			this.jLabelDescuento.setVisible(false);
			this.jTextFieldDescuento.setVisible(false);
		}
		else{
			TCursoADistancia tCursoDist = (TCursoADistancia) tCurso;
			this.jLabelCorreo.setVisible(true);
			this.jTextFieldCorreo.setText(tCursoDist.getCorreo());
			this.jTextFieldCorreo.setVisible(true);
			this.jLabelDescuento.setVisible(true);
			this.jTextFieldDescuento.setVisible(true);
			this.jTextFieldDescuento.setText(""+tCursoDist.getDescuento());
			this.jLabelTasa.setVisible(false);
			this.jTextFieldTasa.setVisible(false);
			this.jLabelAula.setVisible(false);
			this.jTextFieldAula.setVisible(false);
		}
		this.setVisible(true);
	}
}
