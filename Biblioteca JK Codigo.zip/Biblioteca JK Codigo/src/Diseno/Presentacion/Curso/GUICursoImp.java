package Diseno.Presentacion.Curso;

import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUIMensaje;
import Diseno.Presentacion.Controlador.Controlador;
import Diseno.Presentacion.Trabajador.GUIActualizarTrabajador;
import Diseno.Presentacion.Trabajador.GUIAltaTrabajador;
import Diseno.Presentacion.Trabajador.GUIBajaTrabajador;
import Diseno.Presentacion.Trabajador.GUIBuscarActualizarTrabajador;
import Diseno.Presentacion.Trabajador.GUIBuscarTrabajador;
import Diseno.Presentacion.Trabajador.GUIDesmatricularse;
import Diseno.Presentacion.Trabajador.GUIMatricularse;
import Diseno.Presentacion.Trabajador.GUIMostrarMatriculas;
import Diseno.Presentacion.Trabajador.GUIMostrarTrabajadores;

public class GUICursoImp extends GUICurso {
	
	private GUIActualizarCurso gUIActualizarCurso;
	private GUIBuscarCurso gUIBuscarCurso;
	private GUIMostrarCursos gUIMostrarCursos;
	private GUIBuscarActualizarCurso gUIBuscarActualizar;
	private GUIBajaCurso gUIBajaCurso;
	private GUIAltaCurso gUIAltaCurso;
	
	public GUICursoImp() {
		 this.gUIAltaCurso = new GUIAltaCurso();
		 this.gUIActualizarCurso = new GUIActualizarCurso();
		 this.gUIBajaCurso= new GUIBajaCurso();
		 this.gUIBuscarActualizar = new GUIBuscarActualizarCurso();
		 this.gUIBuscarCurso = new GUIBuscarCurso();
		 this.gUIMostrarCursos = new GUIMostrarCursos();
		 this.initGUI();
		 this.setLocationRelativeTo(null);
	}
	
	@SuppressWarnings("unchecked")
                            
    private void initGUI() {

        jLabelTitle = new javax.swing.JLabel();
        jButtonAltaCurso = new javax.swing.JButton();
        jButtonBuscarCurso = new javax.swing.JButton();
        jButtonMostrarCursos = new javax.swing.JButton();
        jButtonActualizarCurso = new javax.swing.JButton();
        jButtonBajaCurso = new javax.swing.JButton();
        jButtonMenuInicio = new javax.swing.JButton();
        jButtonCerrar = new javax.swing.JButton();
        jLabelFont = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitle.setText("Biblioteca J.K");
        getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jButtonAltaCurso.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonAltaCurso.setForeground(new java.awt.Color(255, 255, 255));
        jButtonAltaCurso.setText("Alta Curso");
        jButtonAltaCurso.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonAltaCurso.setContentAreaFilled(false);
        jButtonAltaCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAltaCursoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAltaCurso, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 450, 30));

        jButtonBuscarCurso.setBackground(new java.awt.Color(255, 255, 255));
        jButtonBuscarCurso.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBuscarCurso.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBuscarCurso.setText("Buscar Curso");
        jButtonBuscarCurso.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBuscarCurso.setContentAreaFilled(false);
        jButtonBuscarCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuscarCursoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonBuscarCurso, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 450, -1));

        jButtonMostrarCursos.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMostrarCursos.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMostrarCursos.setText("Mostrar Cursos");
        jButtonMostrarCursos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMostrarCursos.setContentAreaFilled(false);
        jButtonMostrarCursos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMostrarCursosActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMostrarCursos, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 450, -1));

        jButtonActualizarCurso.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonActualizarCurso.setForeground(new java.awt.Color(255, 255, 255));
        jButtonActualizarCurso.setText("Actualizar Curso");
        jButtonActualizarCurso.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonActualizarCurso.setContentAreaFilled(false);
        jButtonActualizarCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActualizarCursoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonActualizarCurso, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 450, -1));

        jButtonBajaCurso.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBajaCurso.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBajaCurso.setText("Baja Curso");
        jButtonBajaCurso.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBajaCurso.setContentAreaFilled(false);
        jButtonBajaCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBajaCursoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonBajaCurso, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 450, -1));

        jButtonMenuInicio.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMenuInicio.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMenuInicio.setText("Menu de Inicio");
        jButtonMenuInicio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMenuInicio.setContentAreaFilled(false);
        jButtonMenuInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenuInicioActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMenuInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, 450, -1));

        jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCerrar.setText("Cerrar");
        jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCerrar.setContentAreaFilled(false);
        jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 550, 450, -1));

        jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
        getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 640));

        pack();
    }                       

    private void jButtonAltaCursoActionPerformed(java.awt.event.ActionEvent evt) {                                                 
    	 this.setVisible(false);
         this.gUIAltaCurso.setVisible(true);
    }                                                

    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {                                              
        System.exit(0);
    }                                             

    private void jButtonMostrarCursosActionPerformed(java.awt.event.ActionEvent evt) {                                                     
    	 this.setVisible(false);
         this.gUIMostrarCursos.setVisible(true);
    }                                                    

    private void jButtonMenuInicioActionPerformed(java.awt.event.ActionEvent evt) {                                                  
    	this.setVisible(false);
        Controlador.getInstance().accion(new Contexto(Events.GUI_MAIN, null));
    }                                                 

    private void jButtonActualizarCursoActionPerformed(java.awt.event.ActionEvent evt) {                                                       
    	this.setVisible(false);
    	this.gUIBuscarActualizar.setVisible(true);
    }                                                      

    private void jButtonBuscarCursoActionPerformed(java.awt.event.ActionEvent evt) {                                                   
    	this.setVisible(false);
    	this.gUIBuscarCurso.setVisible(true);
    }                                                  

    private void jButtonBajaCursoActionPerformed(java.awt.event.ActionEvent evt) {                                                 
    	this.setVisible(false);
    	this.gUIBajaCurso.setVisible(true);
    } 
    
	@Override
	public void actualizar(Contexto contexto) {
		
		GUIMensaje mensaje = new GUIMensaje();
		
		switch(contexto.getEvento()){
		case(Events.GUI_CURSO):
			this.setVisible(true);
		break;
		case(Events.RES_ALTA_CURSO_OK):
			this.setVisible(true);
			this.gUIAltaCurso.clearData();
			mensaje.mostrarMensaje("Se ha creado el curso con id "+(int)contexto.getDato(), null);
		break;
		
		case(Events.RES_ALTA_CURSO_KO):
			switch((int)contexto.getDato()){
			case(-1):
				mensaje.mostrarMensaje("El curso no es válido", null);
			break;
			case(-2):
				mensaje.mostrarMensaje("Error en la transacción", null);
			break;
			case(-3):
				mensaje.mostrarMensaje("El curso ya está activo", null);
			break;
			case(-4):
				mensaje.mostrarMensaje("El centro especificado no existe", null);
			break;
			case(-5):
				mensaje.mostrarMensaje("El centro especificado no está activo", null);
			break;
			case(-6):
				mensaje.mostrarMensaje("El periodo de fechas especificado para el curso no es válido", null);
			break;
			case(-7):
				mensaje.mostrarMensaje("El tipo de curso en la reactivación no es compatible", null);
			break;
			case(-8):
				mensaje.mostrarMensaje("El descuento debe ser inferior o igual a 100", null);
			break;
			case(-100):
				mensaje.mostrarMensaje("Error en la BBDD", null);
			break;
			}
		break;
		case(Events.RES_BAJA_CURSO_OK):
			this.setVisible(true);
			this.gUIBajaCurso.clearData();
			mensaje.mostrarMensaje("Se dio de baja el curso con id "+(int) contexto.getDato(), null);
		break;
		case(Events.RES_BAJA_CURSO_KO):
			switch((int)contexto.getDato()){
			case(-1):
				mensaje.mostrarMensaje("El curso no existe", null);
			break;
			case(-2):
				mensaje.mostrarMensaje("Error en la transacción", null);
			break;
			case(-3):
				mensaje.mostrarMensaje("El curso especificado ya estaba dado de baja", null);
			break;
			case(-4):
				mensaje.mostrarMensaje("El centro especificado no existe", null);
			break;
			case(-5):
				mensaje.mostrarMensaje("El centro especificado no está activo", null);
			break;
			case(-6):
				mensaje.mostrarMensaje("Hay alumnos matriculados en ese curso", null);
			break;
			case(-100):
				mensaje.mostrarMensaje("Error en la BBDD", null);
			break;	
			}
		break;
		case (Events.RES_BUSCAR_ACTUALIZAR_CURSO_OK):
			this.gUIBuscarActualizar.clearData();
			this.gUIActualizarCurso.actualizar(contexto);
		break;
		case(Events.RES_BUSCAR_ACTUALIZAR_CURSO_KO):
			mensaje.mostrarMensaje("No existe ningún curso con ese id", null);
		break;
		case(Events.RES_ACTUALIZAR_CURSO_OK):
			this.setVisible(true);
			this.gUIActualizarCurso.setVisible(false);
			mensaje.mostrarMensaje("Se ha actualizado el curso con id "+(int)contexto.getDato(), null);
		break;
		case(Events.RES_ACTUALIZAR_CURSO_KO):
			switch((int)contexto.getDato()){
			case(-1):
				mensaje.mostrarMensaje("El curso especificado no es válido", null);
			break;
			case(-2):
				mensaje.mostrarMensaje("Error en la transacción", null);
			break;
			case(-3):
				mensaje.mostrarMensaje("El centro especificado no existe", null);
			break;
			case(-4):
				mensaje.mostrarMensaje("El centro especificado no está activo", null);
			break;
			case(-5):
				mensaje.mostrarMensaje("El curso especificado ya existe y/o su id no coincide", null);
			break;
			case(-6):
				mensaje.mostrarMensaje("El periodo de fechas especificado para el curso no es válido", null);
			break;
			case(-7):
				mensaje.mostrarMensaje("El curso especificado no existe", null);
			break;
			case(-8):
				mensaje.mostrarMensaje("El número de plazas totales es inferior al número de matriculados", null);
			break;
			case(-9):
				mensaje.mostrarMensaje("El descuento debe ser inferior o igual a 100", null);
			break;
			case(-100):
				mensaje.mostrarMensaje("Error en la BBDD", null);
			break;	
			}
		break;
		case(Events.RES_BUSCAR_CURSO_OK):
			this.gUIBuscarCurso.actualizar(contexto);
		break;
		case(Events.RES_BUSCAR_CURSO_KO):
			mensaje.mostrarMensaje("No existe ningún curso con ese id ", null);
		break;
		case(Events.RES_MOSTRAR_CURSOS_OK):
			this.gUIMostrarCursos.actualizar(contexto);
		break;
		case(Events.RES_MOSTRAR_CURSOS_KO):
			mensaje.mostrarMensaje("No hay cursos activos", null);
		break;
		}
	}
	
	// Variables declaration - do not modify                     
    private javax.swing.JButton jButtonActualizarCurso;
    private javax.swing.JButton jButtonAltaCurso;
    private javax.swing.JButton jButtonBajaCurso;
    private javax.swing.JButton jButtonBuscarCurso;
    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonMenuInicio;
    private javax.swing.JButton jButtonMostrarCursos;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelTitle;
    // End of variables declaration
}