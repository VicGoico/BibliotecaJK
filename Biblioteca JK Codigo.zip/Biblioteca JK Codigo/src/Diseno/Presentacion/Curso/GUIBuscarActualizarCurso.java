package Diseno.Presentacion.Curso;

import javax.swing.JFrame;

import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUI;
import Diseno.Presentacion.Controlador.Controlador;

public class GUIBuscarActualizarCurso  extends JFrame implements GUI {

   public GUIBuscarActualizarCurso() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.jLabelAvisoId.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    
    private void initComponents() {

    	jLabelTitle = new javax.swing.JLabel();
        jButtonCurso = new javax.swing.JButton();
        jButtonCerrar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabelId = new javax.swing.JLabel();
        jLabelAvisoId = new javax.swing.JLabel();
        jTextFieldFechaFin = new javax.swing.JTextField();
        jTextFieldFechaIni = new javax.swing.JTextField();
        jTextFieldId = new javax.swing.JTextField();
        jLabelNombre = new javax.swing.JLabel();
        jTextFieldNombre = new javax.swing.JTextField();
        jTextFieldDescripcion = new javax.swing.JTextField();
        jLabelApellidos = new javax.swing.JLabel();
        jLabelDNI = new javax.swing.JLabel();
        jLabelCarnet = new javax.swing.JLabel();
        jLabelEmail = new javax.swing.JLabel();
        jTextFieldPlazas = new javax.swing.JTextField();
        jLabelTelefono = new javax.swing.JLabel();
        jTextFieldPrecio = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldIdCentro = new javax.swing.JTextField();
        jLabelFont = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitle.setText("Biblioteca J.K");
        getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, -1, -1));

        jButtonCurso.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCurso.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCurso.setText("Buscar Curso");
        jButtonCurso.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCurso.setContentAreaFilled(false);
        jButtonCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuscarActualizarCursoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCurso, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 450, -1));

        jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCerrar.setText("Cancelar");
        jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCerrar.setContentAreaFilled(false);
        jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, 450, -1));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Actualizar Curso");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, -1, -1));

        jLabelId.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelId.setForeground(new java.awt.Color(255, 255, 255));
        jLabelId.setText("Id:");
        getContentPane().add(jLabelId, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, 30));

        jLabelAvisoId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoId.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoId.setText("Debe ser un número mayor que 0");
        getContentPane().add(jLabelAvisoId, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 140, 210, 20));

        jTextFieldFechaFin.setEditable(false);
        jTextFieldFechaFin.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldFechaFin.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldFechaFin.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldFechaFin, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, 210, 30));

        jTextFieldFechaIni.setEditable(false);
        jTextFieldFechaIni.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldFechaIni.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldFechaIni.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldFechaIni, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 240, 210, 30));

        jTextFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldId.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextFieldId.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, 210, 30));

        jLabelNombre.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelNombre.setForeground(new java.awt.Color(255, 255, 255));
        jLabelNombre.setText("Nombre del Curso:");
        getContentPane().add(jLabelNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, 30));

        jTextFieldNombre.setEditable(false);
        jTextFieldNombre.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldNombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldNombre.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextFieldNombre.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 210, 30));

        jTextFieldDescripcion.setEditable(false);
        jTextFieldDescripcion.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldDescripcion.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldDescripcion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 200, 210, 30));

        jLabelApellidos.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelApellidos.setForeground(new java.awt.Color(255, 255, 255));
        jLabelApellidos.setText("Descripción:");
        getContentPane().add(jLabelApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, 30));

        jLabelDNI.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelDNI.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDNI.setText("Fecha Inicio:");
        getContentPane().add(jLabelDNI, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, -1, 30));

        jLabelCarnet.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelCarnet.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCarnet.setText("Fecha de Fin:");
        getContentPane().add(jLabelCarnet, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, 30));

        jLabelEmail.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelEmail.setForeground(new java.awt.Color(255, 255, 255));
        jLabelEmail.setText("Nº de plazas:");
        getContentPane().add(jLabelEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, 30));

        jTextFieldPlazas.setEditable(false);
        jTextFieldPlazas.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldPlazas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldPlazas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldPlazas, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 320, 210, 30));

        jLabelTelefono.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabelTelefono.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTelefono.setText("Precio:");
        getContentPane().add(jLabelTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, -1, 30));

        jTextFieldPrecio.setEditable(false);
        jTextFieldPrecio.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldPrecio.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldPrecio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 360, 210, 30));

        jLabel2.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Id del Centro:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, -1, 30));

        jTextFieldIdCentro.setEditable(false);
        jTextFieldIdCentro.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldIdCentro.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldIdCentro.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldIdCentro.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldIdCentro, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 400, 210, 30));

        jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
        getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 530));

        pack();
    }

    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCerrarActionPerformed
    	this.clearData();
        Controlador.getInstance().accion(new Contexto(Events.GUI_CURSO, null));
    }

    private void jButtonBuscarActualizarCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCursoActionPerformed
    	int nErrores = 0, id = 0;
        if(!this.jTextFieldId.getText().matches("^([1-9]{1}[0-9]*)$")) {
    		nErrores++;
    		this.jLabelAvisoId.setVisible(true);
    	}
    	else {
    		id = Integer.parseInt(this.jTextFieldId.getText());
    		this.jLabelAvisoId.setVisible(false);
    	}
        if(nErrores == 0) {
        	Controlador.getInstance().accion(new Contexto(Events.GUI_BUSCAR_ACTUALIZAR_CURSO, id));
        }
    }//GEN-LAST:event_jButtonCursoActionPerformed

 // Variables declaration - do not modify                     
    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonCurso;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelApellidos;
    private javax.swing.JLabel jLabelAvisoId;
    private javax.swing.JLabel jLabelCarnet;
    private javax.swing.JLabel jLabelDNI;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelId;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelTelefono;
    private javax.swing.JLabel jLabelTitle;
    private javax.swing.JTextField jTextFieldDescripcion;
    private javax.swing.JTextField jTextFieldFechaFin;
    private javax.swing.JTextField jTextFieldFechaIni;
    private javax.swing.JTextField jTextFieldId;
    private javax.swing.JTextField jTextFieldIdCentro;
    private javax.swing.JTextField jTextFieldNombre;
    private javax.swing.JTextField jTextFieldPlazas;
    private javax.swing.JTextField jTextFieldPrecio;
    // End of variables declaration     
   
	@Override
	public void actualizar(Contexto contexto) {}
	
	public void clearData() {
		this.jTextFieldId.setText("");
		this.jLabelAvisoId.setVisible(false);
		this.setVisible(false);
	}
}
