/**
 * 
 */
package Diseno.Presentacion.Trabajador;

import Diseno.Presentacion.GUI;

import javax.swing.JFrame;

import Diseno.Presentacion.Contexto;

public abstract class GUITrabajador extends JFrame implements GUI {

	private static GUITrabajador instance;

	public static GUITrabajador getInstance() {
		if(instance == null) {
			instance = new GUITrabajadorImp();
		}
		return instance;
	}

	public abstract void actualizar(Contexto contexto);
}