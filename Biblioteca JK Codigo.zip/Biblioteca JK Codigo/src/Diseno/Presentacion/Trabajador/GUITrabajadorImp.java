/**
 * 
 */
package Diseno.Presentacion.Trabajador;

import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUIMensaje;
import Diseno.Presentacion.Controlador.Controlador;


public class GUITrabajadorImp extends GUITrabajador{

	private GUIAltaTrabajador gUI_AltaTrabajador;

	private GUIActualizarTrabajador gUIActualizarTrabajador;

	private GUIDesmatricularse gUIDesmatricular;

	private GUIBajaTrabajador gUIBajaTrabajador;

	private GUIBuscarActualizarTrabajador gUIBuscarActualizarTrabajador;

	private GUIBuscarTrabajador gUIBuscarTrabajador;

	private GUIMatricularse gUIMatricular;

	private GUIMostrarMatriculas gUIMostrarMatriculas;

	private GUIMostrarTrabajadores gUIMostrarTrabajadores;
	
	public GUITrabajadorImp() {
		 this.gUI_AltaTrabajador = new GUIAltaTrabajador();
		 this.gUIActualizarTrabajador = new GUIActualizarTrabajador();
		 this.gUIBajaTrabajador = new GUIBajaTrabajador();
		 this.gUIBuscarActualizarTrabajador = new GUIBuscarActualizarTrabajador();
		 this.gUIBuscarTrabajador = new GUIBuscarTrabajador();
		 this.gUIDesmatricular = new GUIDesmatricularse();
		 this.gUIMatricular = new GUIMatricularse();
		 this.gUIMostrarMatriculas = new GUIMostrarMatriculas();
		 this.gUIMostrarTrabajadores = new GUIMostrarTrabajadores();
		 this.initGUI();
		 this.setLocationRelativeTo(null);
	}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initGUI() {

        jLabelTitle = new javax.swing.JLabel();
        jButtonAltaTrabajador = new javax.swing.JButton();
        jButtonBuscarTrabajador = new javax.swing.JButton();
        jButtonMostrarTrabajadores = new javax.swing.JButton();
        jButtonActualizarTrabajador = new javax.swing.JButton();
        jButtonMatricular = new javax.swing.JButton();
        jButtonMenuInicio = new javax.swing.JButton();
        jButtonCerrar = new javax.swing.JButton();
        jButtonBajaTrabajador = new javax.swing.JButton();
        jButtonMostrarMatriculas = new javax.swing.JButton();
        jButtonDesmatricular = new javax.swing.JButton();
        jLabelFont = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitle.setText("Biblioteca J.K");
        getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jButtonAltaTrabajador.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonAltaTrabajador.setForeground(new java.awt.Color(255, 255, 255));
        jButtonAltaTrabajador.setText("Alta Trabajador");
        jButtonAltaTrabajador.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonAltaTrabajador.setContentAreaFilled(false);
        jButtonAltaTrabajador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAltaTrabajadorActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAltaTrabajador, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 450, 30));

        jButtonBuscarTrabajador.setBackground(new java.awt.Color(255, 255, 255));
        jButtonBuscarTrabajador.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBuscarTrabajador.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBuscarTrabajador.setText("Buscar Trabajador");
        jButtonBuscarTrabajador.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBuscarTrabajador.setContentAreaFilled(false);
        jButtonBuscarTrabajador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuscarTrabajadorActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonBuscarTrabajador, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 450, -1));

        jButtonMostrarTrabajadores.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMostrarTrabajadores.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMostrarTrabajadores.setText("Mostrar Trabajadores");
        jButtonMostrarTrabajadores.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMostrarTrabajadores.setContentAreaFilled(false);
        jButtonMostrarTrabajadores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMostrarTrabajadoresActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMostrarTrabajadores, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 450, -1));

        jButtonActualizarTrabajador.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonActualizarTrabajador.setForeground(new java.awt.Color(255, 255, 255));
        jButtonActualizarTrabajador.setText("Actualizar Trabajador");
        jButtonActualizarTrabajador.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonActualizarTrabajador.setContentAreaFilled(false);
        jButtonActualizarTrabajador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActualizarTrabajadorActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonActualizarTrabajador, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 450, -1));

        jButtonMatricular.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMatricular.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMatricular.setText("Matricular en Curso");
        jButtonMatricular.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMatricular.setContentAreaFilled(false);
        jButtonMatricular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMatricularActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMatricular, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 440, 450, -1));

        jButtonMenuInicio.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMenuInicio.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMenuInicio.setText("Menu de Inicio");
        jButtonMenuInicio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMenuInicio.setContentAreaFilled(false);
        jButtonMenuInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenuInicioActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMenuInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 640, 450, -1));

        jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCerrar.setText("Cerrar");
        jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCerrar.setContentAreaFilled(false);
        jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 590, 450, -1));

        jButtonBajaTrabajador.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBajaTrabajador.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBajaTrabajador.setText("Baja Trabajador");
        jButtonBajaTrabajador.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBajaTrabajador.setContentAreaFilled(false);
        jButtonBajaTrabajador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBajaTrabajadorActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonBajaTrabajador, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 450, -1));

        jButtonMostrarMatriculas.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMostrarMatriculas.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMostrarMatriculas.setText("Mostrar Matrículas");
        jButtonMostrarMatriculas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMostrarMatriculas.setContentAreaFilled(false);
        jButtonMostrarMatriculas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMostrarMatriculasActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMostrarMatriculas, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, 450, -1));

        jButtonDesmatricular.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonDesmatricular.setForeground(new java.awt.Color(255, 255, 255));
        jButtonDesmatricular.setText("Desmatricular de Curso");
        jButtonDesmatricular.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonDesmatricular.setContentAreaFilled(false);
        jButtonDesmatricular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDesmatricularActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonDesmatricular, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 540, 450, -1));

        jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
        getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 690));

        pack();
    }// </editor-fold>                        

    private void jButtonAltaTrabajadorActionPerformed(java.awt.event.ActionEvent evt) {                                                      
        this.setVisible(false);
        this.gUI_AltaTrabajador.setVisible(true);
    }                                                     

    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {                                              
        System.exit(0);
    }                                             

    private void jButtonMostrarTrabajadoresActionPerformed(java.awt.event.ActionEvent evt) {                                                           
        this.setVisible(false);
        this.gUIMostrarTrabajadores.setVisible(true);
    }                                                          

    private void jButtonMenuInicioActionPerformed(java.awt.event.ActionEvent evt) { 
    	this.setVisible(false);
        Controlador.getInstance().accion(new Contexto(Events.GUI_MAIN, null));
    }                                                 

    private void jButtonDesmatricularActionPerformed(java.awt.event.ActionEvent evt) {                                                     
        this.setVisible(false);
        this.gUIDesmatricular.setVisible(true);
    }                                                    

    private void jButtonActualizarTrabajadorActionPerformed(java.awt.event.ActionEvent evt) {                                                            
    	this.setVisible(false);
    	this.gUIBuscarActualizarTrabajador.setVisible(true);
    }                                                           

    private void jButtonBajaTrabajadorActionPerformed(java.awt.event.ActionEvent evt) {                                                      
    	this.setVisible(false);
    	this.gUIBajaTrabajador.setVisible(true);
    }                                                     

    private void jButtonBuscarTrabajadorActionPerformed(java.awt.event.ActionEvent evt) {                                                        
    	this.setVisible(false);
    	this.gUIBuscarTrabajador.setVisible(true);
    }                                                       

    private void jButtonMostrarMatriculasActionPerformed(java.awt.event.ActionEvent evt) {                                                         
    	this.setVisible(false);
    	this.gUIMostrarMatriculas.setVisible(true);
    }                                                        

    private void jButtonMatricularActionPerformed(java.awt.event.ActionEvent evt) {                                                  
    	this.setVisible(false);
    	this.gUIMatricular.setVisible(true);
    }
    
	@Override
	public void actualizar(Contexto contexto) {
		GUIMensaje mensaje = new GUIMensaje();
		switch(contexto.getEvento()) {
		case(Events.GUI_TRABAJADOR):
			this.setVisible(true);
		break;
		case(Events.RES_ALTA_TRABAJADOR_OK):
			this.setVisible(true);
			this.gUI_AltaTrabajador.clearData();
			mensaje.mostrarMensaje("Se ha creado el trabajador con id= " + (int) contexto.getDato(), null);
			break;
		case(Events.RES_ALTA_TRABAJADOR_KO):
			switch((int) contexto.getDato()) {
			case(-1):
			mensaje.mostrarMensaje("Error por defecto", null);
			case(-2):
			mensaje.mostrarMensaje("Error en la transaction", null);
			break;
			case(-3):
			mensaje.mostrarMensaje("El trabajador ya esta activo", null);
			break;
			case(-100):
			mensaje.mostrarMensaje("Error de la base de datos", null);
			break;
			}
		break;
		case(Events.RES_ACTUALIZAR_TRABAJADOR_OK):
			this.setVisible(true);
			this.gUIActualizarTrabajador.setVisible(false);
			mensaje.mostrarMensaje("Se ha actualizado el trabajador con id= " + (int) contexto.getDato(), null);
			break;
		case(Events.RES_ACTUALIZAR_TRABAJADOR_KO):
			switch((int) contexto.getDato()) {
			case(-1):
			mensaje.mostrarMensaje("Error por defecto", null);
			break;
			case(-2):
			mensaje.mostrarMensaje("Error en la transaccion", null);
			break;
			case(-3):
			mensaje.mostrarMensaje("El trabajador no se ha encontrado", null);
			break;
			case(-4):
			mensaje.mostrarMensaje("El trabajador no está activo", null);
			break;
			case(-5):
			mensaje.mostrarMensaje("Ese DNI ya está en uso", null);
			break;
			case(-100):
			mensaje.mostrarMensaje("Error de la base de datos", null);
			break;
			}
		break;
		case(Events.RES_BUSCAR_TRABAJADOR_OK):
			this.gUIBuscarTrabajador.actualizar(contexto);
			break;
		case(Events.RES_BUSCAR_TRABAJADOR_KO):
			mensaje.mostrarMensaje("No existe ningún trabajador con ese id", null);
			break;
		case(Events.RES_BUSCAR_ACTUALIZAR_TRABAJADOR_OK):
			this.gUIBuscarActualizarTrabajador.clearData();
			this.gUIActualizarTrabajador.actualizar(contexto);
			break;
		case(Events.RES_BUSCAR_ACTUALIZAR_TRABAJADOR_KO):
			mensaje.mostrarMensaje("No existe ningún trabajador con ese id", null);
			break;
		case(Events.RES_BAJA_TRABAJADOR_OK):
			this.setVisible(true);
			this.gUIBajaTrabajador.clearData();
			mensaje.mostrarMensaje("Se ha dado de baja el trabajador con id= " + (int) contexto.getDato(), null);
			break;
		case(Events.RES_BAJA_TRABAJADOR_KO):
			switch((int) contexto.getDato()) {
				case(-1):
				mensaje.mostrarMensaje("Error en la transaccion", null);
				break;
				case(-2):
				mensaje.mostrarMensaje("El trabajador no existe", null);
				break;
				case(-3):
				mensaje.mostrarMensaje("El trabajador no esta activo", null);
				break;
				case(-4):
				mensaje.mostrarMensaje("El trabajador tiene matriculas activas", null);
				break;
				case(-100):
				mensaje.mostrarMensaje("Error de la base de datos", null);
				break;
			}
			break;
		case(Events.RES_MOSTRAR_TRABAJADOR_OK):
			this.gUIMostrarTrabajadores.actualizar(contexto);
			break;
		case(Events.RES_MOSTRAR_TRABAJADOR_KO):
			mensaje.mostrarMensaje("No hay trabajadores", null);
			break;
		case(Events.RES_MATRICULAR_OK):
			this.setVisible(true);
			mensaje.mostrarMensaje("Se ha matriculado", null);
			this.gUIMatricular.clearData();
			break;
		case(Events.RES_MATRICULAR_KO):
			switch((int) contexto.getDato()) {
			case(-1):
			mensaje.mostrarMensaje("Error por defecto", null);
			break;
			case(-2):
			mensaje.mostrarMensaje("Error en la transaccion", null);
			break;
			case(-3):
			mensaje.mostrarMensaje("El curso no existe", null);
			break;
			case(-4):
			mensaje.mostrarMensaje("El trabajador no existe", null);
			break;
			case(-5):
			mensaje.mostrarMensaje("El curso no esta activo", null);
			break;
			case(-6):
			mensaje.mostrarMensaje("El trabajador no esta activo", null);
			break;
			case(-7):
			mensaje.mostrarMensaje("No hay plazas disponibles", null);
			break;
			case(-8):
			mensaje.mostrarMensaje("La matricula ya existe y esta activa", null);
			break;
			case(-100):
			mensaje.mostrarMensaje("Error de la base de datos", null);
			break;
			}
		break;
		case(Events.RES_DESMATRICULAR_OK):
			this.gUIDesmatricular.clearData();
			this.setVisible(true);
			mensaje.mostrarMensaje("Se ha desmatriculado", null);
			break;
		case(Events.RES_DESMATRICULAR_KO):
			switch((int) contexto.getDato()) {
			case(-1):
			mensaje.mostrarMensaje("Error por defecto", null);
			break;
			case(-2):
			mensaje.mostrarMensaje("Error en la transaccion", null);
			break;
			case(-3):
			mensaje.mostrarMensaje("El curso no existe", null);
			break;
			case(-4):
			mensaje.mostrarMensaje("El trabajador no existe", null);
			break;
			case(-5):
			mensaje.mostrarMensaje("El curso no esta activo", null);
			break;
			case(-6):
			mensaje.mostrarMensaje("El trabajador no esta activo", null);
			break;
			case(-7):
			mensaje.mostrarMensaje("La matricula no existe", null);
			break;
			case(-8):
			mensaje.mostrarMensaje("La matricula ya esta desactivada", null);
			break;
			case(-100):
			mensaje.mostrarMensaje("Error de la base de datos", null);
			break;
			}
		break;
		case(Events.RES_MOSTRAR_MATRICULAS_OK):
			this.gUIMostrarMatriculas.actualizar(contexto);
			break;
		case(Events.RES_MOSTRAR_MATRICULAS_KO):
			mensaje.mostrarMensaje("No hay matriculas", null);
			break;
		}
	}
	
	// Variables declaration - do not modify                     
    private javax.swing.JButton jButtonActualizarTrabajador;
    private javax.swing.JButton jButtonAltaTrabajador;
    private javax.swing.JButton jButtonBajaTrabajador;
    private javax.swing.JButton jButtonBuscarTrabajador;
    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonDesmatricular;
    private javax.swing.JButton jButtonMatricular;
    private javax.swing.JButton jButtonMenuInicio;
    private javax.swing.JButton jButtonMostrarMatriculas;
    private javax.swing.JButton jButtonMostrarTrabajadores;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelTitle;
    // End of variables declaration
}