package Diseno.Presentacion.Editorial;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUIMensaje;
import Diseno.Presentacion.Cliente.GUIActualizarCliente;
import Diseno.Presentacion.Controlador.Controlador;

public class GUIEditorialImp extends GUIEditorial {
	
	private GUIBuscarActualizarEditorial gUIBuscarActualizarEditorial;
	
	private GUIMostrarEditorial gUIMostrar;
	
	private GUIBajaEditorial gUIBaja;
	
	private GUIAltaEditorial gUIAlta;
	
	private GUIBuscarEditorial gUIBuscar;
	
	private GUIActualizarEditorial gUIActualizar;
	
	// Crear los botone spork qino menudo plan, 2 horas para verlo jajajaaj
	public GUIEditorialImp()  {
		this.gUIAlta = new GUIAltaEditorial();
		this.gUIBaja = new GUIBajaEditorial();
		this.gUIActualizar = new GUIActualizarEditorial();
		this.gUIBuscar = new GUIBuscarEditorial();
		this.gUIMostrar = new GUIMostrarEditorial();
		initGUI();
		this.setLocationRelativeTo(null);
		this.gUIBuscarActualizarEditorial = new GUIBuscarActualizarEditorial();
	}
	
	@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initGUI() {

        jLabelTitle = new javax.swing.JLabel();
        jButtonAltaEditorial = new javax.swing.JButton();
        jButtonBuscarEditorial = new javax.swing.JButton();
        jButtonMostrarEditoriales = new javax.swing.JButton();
        jButtonActualizarEditoriales = new javax.swing.JButton();
        jButtonBajaEditoriales = new javax.swing.JButton();
        jButtonMenuInicio = new javax.swing.JButton();
        jButtonCerrar = new javax.swing.JButton();
        jLabelFont = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitle.setText("Biblioteca J.K");
        getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jButtonAltaEditorial.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonAltaEditorial.setForeground(new java.awt.Color(255, 255, 255));
        jButtonAltaEditorial.setText("Alta Editorial");
        jButtonAltaEditorial.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonAltaEditorial.setContentAreaFilled(false);
        jButtonAltaEditorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAltaEditorialActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAltaEditorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 450, 30));

        jButtonBuscarEditorial.setBackground(new java.awt.Color(255, 255, 255));
        jButtonBuscarEditorial.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBuscarEditorial.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBuscarEditorial.setText("Buscar Editorial");
        jButtonBuscarEditorial.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBuscarEditorial.setContentAreaFilled(false);
        jButtonBuscarEditorial.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent evt) {
				jButtonBuscarEditorialActiPerformed(evt);
			}        	
        });
        getContentPane().add(jButtonBuscarEditorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 450, -1));

        jButtonMostrarEditoriales.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMostrarEditoriales.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMostrarEditoriales.setText("Mostrar Editoriales");
        jButtonMostrarEditoriales.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMostrarEditoriales.setContentAreaFilled(false);
        jButtonMostrarEditoriales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMostrarEditorialesActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMostrarEditoriales, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 450, -1));

        jButtonActualizarEditoriales.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonActualizarEditoriales.setForeground(new java.awt.Color(255, 255, 255));
        jButtonActualizarEditoriales.setText("Actualizar Editorial");
        jButtonActualizarEditoriales.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonActualizarEditoriales.setContentAreaFilled(false);
        jButtonActualizarEditoriales.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent evt) {
				jButtonActualizarEditorialesActionPerformed(evt);
			}
        });
        getContentPane().add(jButtonActualizarEditoriales, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 450, -1));

        jButtonBajaEditoriales.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonBajaEditoriales.setForeground(new java.awt.Color(255, 255, 255));
        jButtonBajaEditoriales.setText("Baja Editorial");
        jButtonBajaEditoriales.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonBajaEditoriales.setContentAreaFilled(false);
        jButtonBajaEditoriales.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent evt) {
				jButtonBajaEditorialesActionPerformed(evt);
			}
		});
        getContentPane().add(jButtonBajaEditoriales, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 450, -1));

        jButtonMenuInicio.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonMenuInicio.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMenuInicio.setText("Menu de Inicio");
        jButtonMenuInicio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonMenuInicio.setContentAreaFilled(false);
        jButtonMenuInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenuInicioActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonMenuInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, 450, -1));

        jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCerrar.setText("Cerrar");
        jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCerrar.setContentAreaFilled(false);
        jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 550, 450, -1));

        jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
        getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 640));

        pack();
    }// </editor-fold>                        
	
	// Oculto la ventana con el menu de Editorial y hago visible la ventana con los datos a rellenar de BAJA
    private void jButtonAltaEditorialActionPerformed(java.awt.event.ActionEvent evt) {                                                     
        this.setVisible(false);
        this.gUIAlta.setVisible(true);
    }  
    
	private void jButtonBajaEditorialesActionPerformed(ActionEvent evt) {
		this.setVisible(false);
		this.gUIBaja.setVisible(true);
	}

	private void jButtonBuscarEditorialActiPerformed(ActionEvent evt) {
		this.setVisible(false);
		this.gUIBuscar.setVisible(true);
	}                                           

    private void jButtonMostrarEditorialesActionPerformed(java.awt.event.ActionEvent evt) {                                                          
       this.setVisible(false);
       this.gUIMostrar.setVisible(true);
    }                                                         

    private void jButtonActualizarEditorialesActionPerformed(ActionEvent evt) {
		this.setVisible(false);
		this.gUIBuscarActualizarEditorial.setVisible(true);
	}

    private void jButtonMenuInicioActionPerformed(java.awt.event.ActionEvent evt) {                                                  
    	this.setVisible(false);
        Controlador.getInstance().accion(new Contexto(Events.GUI_MAIN, null));
    }  
    
    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {                                              
        System.exit(0);
    }  
    
 // Variables declaration - do not modify                     
    private javax.swing.JButton jButtonActualizarEditoriales;
    private javax.swing.JButton jButtonAltaEditorial;
    private javax.swing.JButton jButtonBajaEditoriales;
    private javax.swing.JButton jButtonBuscarEditorial;
    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonMenuInicio;
    private javax.swing.JButton jButtonMostrarEditoriales;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelTitle;
    // End of variables declaration
    
	    
	@Override
	public void actualizar(Contexto contexto) {
		GUIMensaje mensaje = new GUIMensaje();
		switch(contexto.getEvento()) {
		// Caso en el k sale bien
		case (Events.RES_ALTA_EDITORIAL_OK):
			this.setVisible(true);
			this.gUIAlta.clearData();
			mensaje.mostrarMensaje("Se ha creado la editorial con id= " + (int) contexto.getDato(), null);
			break;
		case (Events.RES_ALTA_EDITORIAL_KO):
			switch((int) contexto.getDato()) {
			case(-1):
			mensaje.mostrarMensaje("La editorial no es válida", null);
			break;
			case(-100):
			mensaje.mostrarMensaje("Error de la base de datos", null);
			break;
			}
			break;
		case (Events.RES_BAJA_EDITORIAL_OK):
			this.setVisible(true);
			this.gUIBaja.clearData();
			mensaje.mostrarMensaje("Se ha dado de baja la editorial con id= " + (int) contexto.getDato(), null);
			break;
		case (Events.RES_BAJA_EDITORIAL_KO):
			switch((int) contexto.getDato()) {
			case(-1):
			mensaje.mostrarMensaje("La editorial no es válida", null);
			break;
			case(-2):
				mensaje.mostrarMensaje("La editorial no está activa", null);
				break;
			case(-3):
				mensaje.mostrarMensaje("La editorial tiene libros activos", null);
				break;
			case(-100):
			mensaje.mostrarMensaje("Error de la base de datos", null);
			break;
			}
			break;
		case (Events.RES_ACTUALIZAR_EDITORIAL_OK):
			this.setVisible(true);
			this.gUIActualizar.setVisible(false);
			mensaje.mostrarMensaje("Se ha actualizado la editorial con id= " + (int) contexto.getDato(), null);
			break;
		case (Events.RES_ACTUALIZAR_EDITORIAL_KO):
			switch((int) contexto.getDato()) {
			case(-1):
			mensaje.mostrarMensaje("La editorial no es válida", null);
			break;
			case(-2):
				mensaje.mostrarMensaje("El nombre de la editorial ya existe", null);
				break;
			case(-3):
				mensaje.mostrarMensaje("La editorial no está activa", null);
				break;
			case(-4):
				mensaje.mostrarMensaje("La editorial no existe", null);
				break;
			case(-100):
			mensaje.mostrarMensaje("Error de la base de datos", null);
			break;
			}
			break;
		case (Events.RES_BUSCAR_ACTUALIZAR_EDITORIAL_OK):
			this.gUIBuscarActualizarEditorial.clearData();
			this.gUIActualizar.actualizar(contexto);
			break;
		case (Events.RES_BUSCAR_ACTUALIZAR_EDITORIAL_KO):
			mensaje.mostrarMensaje("No existe ninguna editorial con ese id", null);
			break;
		case(Events.RES_BUSCAR_EDITORIAL_OK):
			this.gUIBuscar.actualizar(contexto);
			break;
		case(Events.RES_BUSCAR_EDITORIAL_KO):
			mensaje.mostrarMensaje("No existe ninguna editorial con ese id", null);
			break;
		case (Events.RES_MOSTRAR_EDITORIAL_OK):
			this.gUIMostrar.actualizar(contexto);
			break;
		case (Events.RES_MOSTRAR_EDITORIAL_KO):
			mensaje.mostrarMensaje("No hay editoriales", null);
			break;
		case (Events.GUI_EDITORIAL):
			this.setVisible(true);
			break;
		}
		
	}
}