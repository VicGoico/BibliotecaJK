package Diseno.Presentacion.Editorial;

import Diseno.Presentacion.GUI;

import javax.swing.JFrame;

import Diseno.Presentacion.Contexto;

/** 
* <!-- begin-UML-doc -->
* <!-- end-UML-doc -->
* @author Bolil
* @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
*/
@SuppressWarnings("serial")
public abstract class GUIEditorial extends JFrame implements GUI {

	private static GUIEditorial instance;

	public static GUIEditorial getInstance() {
		if(instance == null){
			instance = new GUIEditorialImp();
		}
		return instance;
	}

	public abstract void actualizar(Contexto contexto);
}