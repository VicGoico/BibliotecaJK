package Diseno.Presentacion.Editorial;

import javax.swing.JLabel;

import Diseno.Negocio.Editorial.TEditorial;
import Diseno.Presentacion.Contexto;
import Diseno.Presentacion.Events;
import Diseno.Presentacion.GUI;
import Diseno.Presentacion.Controlador.Controlador;

public class GUIActualizarEditorial extends javax.swing.JFrame implements GUI{

    /**
     * Creates new form interfaz
     */
    public GUIActualizarEditorial() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.jLabelAvisoId.setVisible(false);
        this.jLabelAvisoNombre.setVisible(false);
        this.jLabelAvisoDireccion.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelTitle = new JLabel(); // javax.swing.JLabel();
        jButtonEditorial = new javax.swing.JButton();
        jButtonCerrar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldId = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldDireccion = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextFieldNombre = new javax.swing.JTextField();
        jLabelAvisoDireccion = new javax.swing.JLabel();
        jLabelAvisoNombre = new javax.swing.JLabel();
        jLabelAvisoId = new javax.swing.JLabel();
        jLabelFont = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelTitle.setFont(new java.awt.Font("Old English Text MT", 1, 48)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTitle.setText("Biblioteca J.K");
        getContentPane().add(jLabelTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jButtonEditorial.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonEditorial.setForeground(new java.awt.Color(255, 255, 255));
        jButtonEditorial.setText("Guardar Editorial");
        jButtonEditorial.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonEditorial.setContentAreaFilled(false);
        jButtonEditorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditorialActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonEditorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 450, -1));

        jButtonCerrar.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jButtonCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCerrar.setText("Cancelar");
        jButtonCerrar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButtonCerrar.setContentAreaFilled(false);
        jButtonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCerrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, 450, -1));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Actualizar Editorial");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, -1, -1));

        jLabel2.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Id de la Editorial:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, 30));

        jTextFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldId.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldId.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 220, 210, 30));

        jLabel3.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Dirección de la Editorial:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, 30));

        jTextFieldDireccion.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldDireccion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        getContentPane().add(jTextFieldDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 320, 210, 30));

        jLabel4.setFont(new java.awt.Font("Old English Text MT", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Nombre de la Editorial:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, 30));

        jTextFieldNombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 51, 0)));
        jTextFieldNombre.setSelectionColor(new java.awt.Color(153, 51, 0));
        getContentPane().add(jTextFieldNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 270, 210, 30));

        jLabelAvisoDireccion.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoDireccion.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoDireccion.setText("Este campo es obligatorio");
        getContentPane().add(jLabelAvisoDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 350, 210, 20));

        jLabelAvisoNombre.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoNombre.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoNombre.setText("Este campo es obligatorio");
        getContentPane().add(jLabelAvisoNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 300, 210, 20));

        jLabelAvisoId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabelAvisoId.setForeground(new java.awt.Color(255, 255, 255));
        jLabelAvisoId.setText("Debe ser un número mayor que 0");
        getContentPane().add(jLabelAvisoId, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 250, 210, 20));

        jLabelFont.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Wallpapers-books.jpg"))); // NOI18N
        getContentPane().add(jLabelFont, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 530));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCerrarActionPerformed
       this.setVisible(false);
       Controlador.getInstance().accion(new Contexto(Events.GUI_EDITORIAL, null));
    }//GEN-LAST:event_jButtonCerrarActionPerformed

    private void jButtonEditorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditorialActionPerformed
    	int nErrores = 0, id= 0;
    	String nombre = "", direccion ="";
    	if(!this.jTextFieldId.getText().matches("^([1-9]{1}[0-9]*)$")) {
    		nErrores++;
    		this.jLabelAvisoId.setVisible(true);
    	}
    	else {
    		id = Integer.parseInt(this.jTextFieldId.getText());
    		this.jLabelAvisoId.setVisible(false);
    	}
    	if(!this.jTextFieldNombre.getText().matches("^(?!\\s*$).+")){
    		nErrores++;
    		this.jLabelAvisoNombre.setVisible(true);
    	}
    	else {
    		nombre = this.jTextFieldNombre.getText();
    		this.jLabelAvisoNombre.setVisible(false);
    	}
    	if(!this.jTextFieldDireccion.getText().matches("^(?!\\s*$).+")){
    		nErrores++;
    		this.jLabelAvisoDireccion.setVisible(true);
    	}
    	else {
    		direccion = this.jTextFieldDireccion.getText();
    		this.jLabelAvisoDireccion.setVisible(false);
    	}
    	// Si todo bien lo pasamos a la capa negocio
    	if(nErrores == 0){
    		TEditorial tEditorial = new TEditorial(id, nombre, direccion, true, 0);
    		Controlador.getInstance().accion(new Contexto(Events.GUI_ACTUALIZAR_EDITORIAL, tEditorial));
    	}
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCerrar;
    private javax.swing.JButton jButtonEditorial;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabelAvisoDireccion;
    private javax.swing.JLabel jLabelAvisoId;
    private javax.swing.JLabel jLabelAvisoNombre;
    private javax.swing.JLabel jLabelFont;
    private javax.swing.JLabel jLabelTitle;
    private javax.swing.JTextField jTextFieldId;
    private javax.swing.JTextField jTextFieldDireccion;
    private javax.swing.JTextField jTextFieldNombre;
    // End of variables declaration//GEN-END:variables
	@Override
	public void actualizar(Contexto contexto) {
		// Saltan excepciones si lo descomento
		TEditorial tEdi = (TEditorial) contexto.getDato();
		this.jTextFieldId.setText(""+tEdi.getIdEditorial());
		this.jTextFieldNombre.setText(tEdi.getNombre());
		this.jTextFieldDireccion.setText(tEdi.getDireccion());
		this.setVisible(true);
	}
}
