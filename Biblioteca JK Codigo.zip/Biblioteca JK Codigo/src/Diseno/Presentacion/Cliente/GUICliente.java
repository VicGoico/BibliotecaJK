/**
 * 
 */
package Diseno.Presentacion.Cliente;

import Diseno.Presentacion.GUI;

import javax.swing.JFrame;

import Diseno.Presentacion.Contexto;

public abstract class GUICliente extends JFrame implements GUI {

	private static GUICliente instance;

	public static GUICliente getInstance() {
		if(instance == null)
			instance = new GUIClienteImp();
		return instance;
	}

}