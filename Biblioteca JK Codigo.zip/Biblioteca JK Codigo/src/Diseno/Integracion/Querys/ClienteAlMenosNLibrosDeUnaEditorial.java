/**
 * 
 */
package Diseno.Integracion.Querys;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Diseno.Integracion.Transaccion.Transaction;
import Diseno.Integracion.Transaccion.TransactionManager;
import Diseno.Negocio.Cliente.TCliente;
import Diseno.Negocio.Cliente.TLibroEditorial;

public class ClienteAlMenosNLibrosDeUnaEditorial implements Query {

	public ArrayList<TCliente> execute(Object object) {
		int idEditorial = ((TLibroEditorial)object).getIdEditorial();
		int nLibros = ((TLibroEditorial)object).getnLib();
		ArrayList<TCliente> listaClientes = null;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if (transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			if (connection != null) {
				try {
				String query = "SELECT DISTINCT `id`,`nombre`,`apellidos`,`dni`,`carnet`,`email`,"
						+ "`telefono`,`activo` FROM cliente JOIN (SELECT COUNT(idCliente) AS total, idCliente FROM prestamo JOIN "
						+ "(SELECT libro.id AS LibroId FROM libro WHERE libro.idEditorial ='"+ idEditorial +"') AS libroPrestamo "
						+ "WHERE prestamo.idLibro = LibroId GROUP BY idCliente) AS prestamoCliente "
						+ "WHERE cliente.id = idCliente AND total >=" + nLibros + "";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				ResultSet resultSet = preparedStatement.executeQuery(query);
				TCliente tCliente;
				listaClientes = new ArrayList<>();
				while(resultSet.next()) {
					tCliente = new TCliente(
							resultSet.getInt("id"),
							resultSet.getString("nombre"),
							resultSet.getString("apellidos"),
							resultSet.getString("DNI"),
							resultSet.getString("carnet"),
							resultSet.getString("email"),
							resultSet.getInt("telefono"),
							resultSet.getBoolean("activo")
							);
					listaClientes.add(tCliente);
				}
				}catch (SQLException e){
					listaClientes = null;
				}
			}
		}
		if(listaClientes.isEmpty()) listaClientes = null;
		return listaClientes;
	}
}