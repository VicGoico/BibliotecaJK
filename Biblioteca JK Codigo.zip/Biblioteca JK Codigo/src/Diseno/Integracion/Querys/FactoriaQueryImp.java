/**
 * 
 */
package Diseno.Integracion.Querys;

public class FactoriaQueryImp extends FactoriaQuery {

	@Override
	public ClienteConLibrosDeUnGeneroYNPaginas generateClienteConLibrosDeUnGeneroYNPaginas() {
		return new ClienteConLibrosDeUnGeneroYNPaginas();
	}

	@Override
	public ClienteAlMenosNLibrosDeUnaEditorial generateClienteAlMenosNLibrosDeUnaEditorial() {
		return new ClienteAlMenosNLibrosDeUnaEditorial();
	}
}