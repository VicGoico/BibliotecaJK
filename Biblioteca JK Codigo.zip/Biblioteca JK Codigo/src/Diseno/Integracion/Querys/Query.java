/**
 * 
 */
package Diseno.Integracion.Querys;


public interface Query {

	public Object execute(Object object);
}