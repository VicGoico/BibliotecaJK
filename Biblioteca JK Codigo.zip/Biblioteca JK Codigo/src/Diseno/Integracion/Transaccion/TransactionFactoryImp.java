/**
 * 
 */
package Diseno.Integracion.Transaccion;

public class TransactionFactoryImp extends TransactionFactory {
	public Transaction createTransaction() {
		Transaction t = new TransactionMySQL();
		return t;
	}
}