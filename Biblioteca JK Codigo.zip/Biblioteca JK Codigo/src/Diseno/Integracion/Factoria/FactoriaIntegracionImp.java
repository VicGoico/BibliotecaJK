/**
 * 
 */
package Diseno.Integracion.Factoria;

import Diseno.Integracion.Cliente.DAOCliente;
import Diseno.Integracion.Cliente.DAOClienteImp;
import Diseno.Integracion.Editorial.DAOEditorial;
import Diseno.Integracion.Editorial.DAOEditorialImp;
import Diseno.Integracion.Libro.DAOLibro;
import Diseno.Integracion.Libro.DAOLibroImp;

public class FactoriaIntegracionImp extends FactoriaIntegracion {

	@Override
	public DAOCliente crearDAOCliente() {
		return new DAOClienteImp();
	}

	@Override
	public DAOEditorial crearDAOEditorial() {
		return new DAOEditorialImp();
	}

	@Override
	public DAOLibro crearDAOLibro() {
		return new DAOLibroImp();
	}
}