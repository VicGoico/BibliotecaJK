/**
 * 
 */
package Diseno.Integracion.Factoria;

import Diseno.Integracion.Cliente.DAOCliente;
import Diseno.Integracion.Editorial.DAOEditorial;
import Diseno.Integracion.Libro.DAOLibro;

public abstract class FactoriaIntegracion {
	
	private static FactoriaIntegracion instance;
	
	public synchronized static FactoriaIntegracion getInstance() {
		if(instance == null) {
			instance = new FactoriaIntegracionImp();
		}
		return instance;
	}

	public abstract DAOCliente crearDAOCliente();

	public abstract DAOEditorial crearDAOEditorial();

	public abstract DAOLibro crearDAOLibro();
}