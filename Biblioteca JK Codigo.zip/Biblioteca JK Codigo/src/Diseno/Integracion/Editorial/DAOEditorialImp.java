package Diseno.Integracion.Editorial;

import Diseno.Integracion.Transaccion.Transaction;
import Diseno.Integracion.Transaccion.TransactionManager;
import Diseno.Negocio.Editorial.TEditorial;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DAOEditorialImp implements DAOEditorial 
{
	public int alta(TEditorial tEditorial)
	{
		int id = -100;
		TransactionManager transactionDaoEd = TransactionManager.getInstance();
		Transaction transaction = transactionDaoEd.getTransaccion();

		if (transaction != null)
		{
			Connection connection = (Connection) transaction.getResource();
			if (connection != null)
			{
				PreparedStatement prepStatement;

				try
				{
					String insert = "INSERT INTO editorial (nombre, direccion, libros_activos, activo) VALUES (?,?,?,?)";
					prepStatement = connection.prepareStatement(insert);
					
					prepStatement.setString(1, tEditorial.getNombre());
					prepStatement.setString(2, tEditorial.getDireccion());
					prepStatement.setInt(3, tEditorial.getNumLibrosActivos());
					prepStatement.setBoolean(4, tEditorial.getActivo());
					
					prepStatement.executeUpdate();
					prepStatement.close();

					prepStatement = connection.prepareStatement("SELECT last_insert_id() as last_id from editorial");
					ResultSet resultSet = prepStatement.executeQuery();

					if (resultSet.next())
						id = resultSet.getInt("last_id");

					prepStatement.close();
					resultSet.close();

				} 
				catch (SQLException e) 
				{
					id = -100;
				}
			}
		}
		return id;
	}

	public int baja(int idEditorial)
	{
		int id = -100;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		
		if (transaction != null) 
		{
			Connection object = (Connection) transaction.getResource();
			if (object != null)
			{
				try 
				{
					String query = "UPDATE editorial SET activo=0 WHERE id=?";
					PreparedStatement preparedStatement = object.prepareStatement(query);
					preparedStatement.setInt(1, idEditorial);
					preparedStatement.executeUpdate();
					preparedStatement.close();
					id = idEditorial;
				} 
				catch (SQLException e)
				{
					id = -100;
				}
			}

		}
		return id;
	}

	public int modificar(TEditorial tEditorial)
	{
		int id = -100;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		
		if (transaction != null) 
		{
			Connection object = (Connection) transaction.getResource();
			if (object != null) 
			{
				try 
				{
					String query = "UPDATE editorial SET nombre=?, direccion=?, libros_activos=?, activo=? WHERE id=?";
					PreparedStatement preparedStatement = object.prepareStatement(query);
					preparedStatement.setString(1, tEditorial.getNombre());
					preparedStatement.setString(2, tEditorial.getDireccion());
					preparedStatement.setInt(3, tEditorial.getNumLibrosActivos());
					preparedStatement.setBoolean(4, tEditorial.getActivo());
					preparedStatement.setInt(5,  tEditorial.getIdEditorial());				
					preparedStatement.executeUpdate();
					id = tEditorial.getIdEditorial();
					preparedStatement.close();
				} 
				catch (SQLException e)
				{
					id = -100;
				}
			}

		}
		return id;
	}

	public TEditorial buscar(int idEditorial)
	{
		TEditorial tEditorial = null;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		
		if (transaction != null)
		{
			Connection connection = (Connection) transaction.getResource();
			if (connection != null)
			{
				try
				{
					PreparedStatement prepareStatement = connection
							.prepareStatement("SELECT * FROM editorial WHERE id=? FOR UPDATE");
					prepareStatement.setInt(1, idEditorial);
					ResultSet resultSet = prepareStatement.executeQuery();
					
					if (resultSet.next()) 
					{
						String nombre, direccion;
						int numLibrosActivos;
						boolean activo;
						nombre = resultSet.getString("nombre");
						direccion = resultSet.getString("direccion");
						activo = resultSet.getBoolean("activo");
						numLibrosActivos = resultSet.getInt("libros_activos");
						tEditorial = new TEditorial(idEditorial, nombre, direccion, activo, numLibrosActivos);
					}
					
					prepareStatement.close();
					resultSet.close();
				} 
				catch (SQLException e)
				{
					tEditorial = null;
				}
			}
		}
		return tEditorial;
	}

	public ArrayList<TEditorial> mostrar() 
	{
		TEditorial tEditorial;
		ArrayList<TEditorial> editoriales = new ArrayList<>();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		
		if (transaction != null)
		{
			Connection connection = (Connection) transaction.getResource();
			if (connection != null) 
			{
				try 
				{
					PreparedStatement prepareStatement = connection.prepareStatement("SELECT * FROM editorial WHERE activo=1");
					ResultSet resultSet = prepareStatement.executeQuery();
					
					while (resultSet.next())
					{
						String nombre, direccion;
						int numLibrosActivos, idEditorial;
						boolean activo;

						idEditorial = resultSet.getInt("id");
						nombre = resultSet.getString("nombre");
						direccion = resultSet.getString("direccion");
						activo = resultSet.getBoolean("activo");
						numLibrosActivos = resultSet.getInt("libros_activos");
						tEditorial = new TEditorial(idEditorial, nombre, direccion, activo, numLibrosActivos);
						editoriales.add(tEditorial);
					}
					prepareStatement.close();
					resultSet.close();
				} 
				catch (SQLException e) 
				{
					tEditorial = null;
				}
			}
		}
		if(editoriales.isEmpty()) editoriales = null;
		return editoriales;
	}

	public TEditorial buscarPorNombre(String NombreEditorial) 
	{
		TEditorial tEditorial = null;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
	
		if (transaction != null)
		{
			Connection object = (Connection) transaction.getResource();
			if (object != null) 
			{
				try 
				{
					String query = "SELECT * FROM editorial WHERE nombre=? FOR UPDATE";
					PreparedStatement preparedStatement = object.prepareStatement(query);
					preparedStatement.setString(1, NombreEditorial);
					ResultSet resultSet = preparedStatement.executeQuery();
					
					if (resultSet.next()) {
						tEditorial = new TEditorial(resultSet.getInt("id"), resultSet.getString("nombre"),
								resultSet.getString("direccion"), resultSet.getBoolean("activo"),
								resultSet.getInt("libros_activos"));
					}
					
					preparedStatement.close();
					resultSet.close();
				} 
				catch (SQLException e)
				{
					tEditorial = null;
				}
			}
		}
		return tEditorial;
	}
}