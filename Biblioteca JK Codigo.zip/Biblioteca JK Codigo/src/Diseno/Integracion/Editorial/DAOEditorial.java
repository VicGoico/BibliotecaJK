package Diseno.Integracion.Editorial;

import Diseno.Negocio.Editorial.TEditorial;

import java.util.ArrayList;

public interface DAOEditorial {
	
	public int alta(TEditorial tEditorial);

	public int baja(int idEditorial);

	public int modificar(TEditorial tEditorial);

	public TEditorial buscar(int idEditorial);

	public ArrayList<TEditorial> mostrar();

	public TEditorial buscarPorNombre(String NombreEditorial);
}