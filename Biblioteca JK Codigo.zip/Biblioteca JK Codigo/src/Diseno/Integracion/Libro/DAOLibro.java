package Diseno.Integracion.Libro;

import Diseno.Negocio.Libro.TLibro;

import java.util.ArrayList;

public interface DAOLibro {
	
	public int altaLibro(TLibro tLibro);
	
	public int bajaLibro(int id);

	public int actualizarLibro(TLibro tLibro);

	public TLibro buscarLibro(int id);

	public ArrayList<TLibro> mostrarLibros();

	public ArrayList<TLibro> buscarPorAutor(String autores);

	public TLibro buscarPorISBN(String isbn);
}