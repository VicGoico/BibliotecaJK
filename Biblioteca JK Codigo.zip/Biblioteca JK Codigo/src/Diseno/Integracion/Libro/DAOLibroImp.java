package Diseno.Integracion.Libro;

import Diseno.Integracion.Transaccion.Transaction;
import Diseno.Integracion.Transaccion.TransactionManager;
import Diseno.Negocio.Libro.Asignatura;
import Diseno.Negocio.Libro.Genero;
import Diseno.Negocio.Libro.TLibro;
import Diseno.Negocio.Libro.TLibroLiteratura;
import Diseno.Negocio.Libro.TLibroTexto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DAOLibroImp implements DAOLibro {
	
	public int altaLibro(TLibro tLibro) {
		int id = -100;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			
			if(connection != null) {
				
				try {
					PreparedStatement prepareStatement = connection.prepareStatement("INSERT INTO libro (titulo, autores, ISBN, nPag, unidades_totales, unidades_prestadas, idEditorial, activo) VALUES (?,?,?,?,?,?,?,?)");
					prepareStatement.setString(1, tLibro.getTitulo());
					prepareStatement.setString(2, tLibro.getAutor());
					prepareStatement.setString(3, tLibro.getISBN());
					prepareStatement.setInt(4, tLibro.getPaginas());
					prepareStatement.setInt(5, tLibro.getUnidadesTotales());
					prepareStatement.setInt(6, tLibro.getUnidadesPrestadas());
					prepareStatement.setInt(7, tLibro.getEditorial());
					prepareStatement.setBoolean(8, tLibro.getActivo());
					prepareStatement.executeUpdate();
					prepareStatement.close();
					prepareStatement = connection.prepareStatement("SELECT last_insert_id() as last_id from libro");
					ResultSet resultSet = prepareStatement.executeQuery();
					
					if(resultSet.next()) {
						id = resultSet.getInt("last_id");
						if(tLibro instanceof TLibroLiteratura){
							TLibroLiteratura tLibroLit = (TLibroLiteratura) tLibro;
							prepareStatement = connection.prepareStatement("INSERT INTO libroliteratura (id, genero) VALUES (?,?)");
							prepareStatement.setInt(1, id);
							prepareStatement.setString(2, Genero.transform(tLibroLit.getGenero()));
						}
						else{
							TLibroTexto tLibroTexto = (TLibroTexto) tLibro;
							prepareStatement.close();
							prepareStatement = connection.prepareStatement("INSERT INTO librotexto (id, asignatura) VALUES (?,?)");
							prepareStatement.setInt(1, id);
							prepareStatement.setString(2, Asignatura.transform(tLibroTexto.getAsignatura()));
						}
						prepareStatement.executeUpdate();
					}
					
					prepareStatement.close();
					resultSet.close();
					
				} catch (SQLException e) {
					id = -100;
				}
			}
		}
		return id;
	}

	public int bajaLibro(int id) {
		int r = -100;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		
		if (transaction != null) {
			Connection object = (Connection) transaction.getResource();
			
			if (object != null) {
				try {
					String query = "UPDATE libro SET activo = 0 WHERE id = ?";
					PreparedStatement preparedStatement = object.prepareStatement(query);
					preparedStatement.setInt(1, id);
					preparedStatement.executeUpdate();
					preparedStatement.close();
					r = id;
				} catch (SQLException e) {
					r = -100;
				}
			}
		}
		return r;
	}

	public int actualizarLibro(TLibro tLibro) {
		int id = -100;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		
		if (transaction != null) {
			Connection object = (Connection) transaction.getResource();
			
			if (object != null) {
				try {
					String query = "UPDATE libro SET titulo= ?, autores = ?, ISBN = ?, nPag = ?, unidades_totales = ?, unidades_prestadas = ?, idEditorial = ?, activo = ? WHERE id = ?";
					PreparedStatement preparedStatement = object.prepareStatement(query);
					preparedStatement.setString(1, tLibro.getTitulo());
					preparedStatement.setString(2, tLibro.getAutor());
					preparedStatement.setString(3, tLibro.getISBN());
					preparedStatement.setInt(4, tLibro.getPaginas());
					preparedStatement.setInt(5, tLibro.getUnidadesTotales());
					preparedStatement.setInt(6, tLibro.getUnidadesPrestadas());
					preparedStatement.setInt(7, tLibro.getEditorial());
					preparedStatement.setBoolean(8, tLibro.getActivo() ? true : false);
					preparedStatement.setInt(9, tLibro.getID());
					preparedStatement.executeUpdate();
					id = tLibro.getID();
					preparedStatement.close();
					
					if(tLibro instanceof TLibroLiteratura){
						TLibroLiteratura tLibroLit = (TLibroLiteratura) tLibro;
						preparedStatement = object.prepareStatement("SELECT * FROM libroliteratura WHERE id = ?");
						preparedStatement.setInt(1, id);
						ResultSet result = preparedStatement.executeQuery();
						if(!result.next()){
							preparedStatement.close();
							preparedStatement = object.prepareStatement("INSERT INTO libroliteratura (id, genero) VALUES (?,?)");
							PreparedStatement preparedSt = object.prepareStatement("DELETE FROM librotexto WHERE id = ?");
							preparedStatement.setInt(1, id);
							preparedStatement.setString(2, Genero.transform(tLibroLit.getGenero()));
							preparedSt.setInt(1, id);
							preparedStatement.executeUpdate();
							preparedSt.executeUpdate();
							preparedStatement.close();
							preparedSt.close();
						}
						else{
							preparedStatement.close();
							preparedStatement = object.prepareStatement("UPDATE libroliteratura SET genero = ? WHERE id = ?");
							preparedStatement.setString(1, Genero.transform(tLibroLit.getGenero()));
							preparedStatement.setInt(2, id);
							preparedStatement.executeUpdate();
							preparedStatement.close();
						}
						result.close();
					}
					else{
						TLibroTexto tLibroTexto = (TLibroTexto) tLibro;
						preparedStatement.close();
						preparedStatement = object.prepareStatement("SELECT * FROM librotexto WHERE id = ?");
						preparedStatement.setInt(1, id);
						ResultSet result = preparedStatement.executeQuery();
						if(!result.next()){
							preparedStatement.close();
							preparedStatement = object.prepareStatement("INSERT INTO librotexto (id, asignatura) VALUES (?,?)");
							PreparedStatement preparedSt = object.prepareStatement("DELETE FROM libroliteratura WHERE id = ?");
							preparedStatement.setInt(1, id);
							preparedStatement.setString(2, Asignatura.transform(tLibroTexto.getAsignatura()));
							preparedSt.setInt(1, id);
							preparedStatement.executeUpdate();
							preparedSt.executeUpdate();
							preparedStatement.close();
							preparedSt.close();
						}
						else{
							preparedStatement.close();
							preparedStatement = object.prepareStatement("UPDATE librotexto SET asignatura = ? WHERE id = ?");
							preparedStatement.setString(1, Asignatura.transform(tLibroTexto.getAsignatura()));
							preparedStatement.setInt(2, id);
							preparedStatement.executeUpdate();
							preparedStatement.close();
						}
						result.close();
					}
					
				} catch (SQLException e) {
					id = -100;
				}
			}
		}
		return id;
	}

	public TLibro buscarLibro(int id) {
		TLibro tLibroRes = null, tLibro = null;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			
			if(connection != null) {
				try {
					PreparedStatement prepareStatement = connection.prepareStatement("SELECT * FROM libro WHERE id= ? FOR UPDATE");
					prepareStatement.setInt(1, id);
					ResultSet resultSet = prepareStatement.executeQuery();
					
					if(resultSet.next()) {
						tLibroRes = new TLibro(resultSet.getInt("id"),
								resultSet.getString("titulo"),
								resultSet.getString("autores"),
								resultSet.getString("ISBN"),
								resultSet.getInt("nPag"),
								resultSet.getInt("unidades_totales"),
								resultSet.getInt("unidades_prestadas"),
								resultSet.getInt("idEditorial"),
								resultSet.getBoolean("activo"));
						prepareStatement = connection.prepareStatement("SELECT * FROM librotexto WHERE id = ?");
						prepareStatement.setInt(1, id);
						ResultSet result = prepareStatement.executeQuery();
						if(result.next()){
							tLibro = new TLibroTexto(tLibroRes.getID(), tLibroRes.getTitulo(), tLibroRes.getAutor(), tLibroRes.getISBN(),
									tLibroRes.getPaginas(),tLibroRes.getUnidadesTotales(), tLibroRes.getUnidadesPrestadas(),
									tLibroRes.getEditorial(), tLibroRes.getActivo(), Asignatura.transform(result.getString("asignatura")));
						}
						else{
							prepareStatement.close();
							result.close();
							prepareStatement = connection.prepareStatement("SELECT * FROM libroliteratura WHERE id = ?");
							prepareStatement.setInt(1, id);
							result = prepareStatement.executeQuery();
							if(result.next())
								tLibro = new TLibroLiteratura(tLibroRes.getID(), tLibroRes.getTitulo(), tLibroRes.getAutor(), tLibroRes.getISBN(),
											tLibroRes.getPaginas(),tLibroRes.getUnidadesTotales(), tLibroRes.getUnidadesPrestadas(),
									tLibroRes.getEditorial(), tLibroRes.getActivo(), Genero.transform(result.getString("genero")));
							
						}
						result.close();
					}
					prepareStatement.close();
					resultSet.close();
				} catch (SQLException e) {
					tLibro = null;
				}
			}
		}
		return tLibro;
	}

	public ArrayList<TLibro> mostrarLibros() {
		TLibro tLibro = null, tLibroRes = null;
		ArrayList<TLibro> libros = new ArrayList<>();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			
			if(connection != null) {
				try {
					PreparedStatement prepareStatement = connection.prepareStatement("SELECT * FROM libro WHERE activo=1");
					ResultSet resultSet = prepareStatement.executeQuery();
					
					while(resultSet.next()) {
						tLibroRes = new TLibro(resultSet.getInt("id"),
								resultSet.getString("titulo"),
								resultSet.getString("autores"),
								resultSet.getString("ISBN"),
								resultSet.getInt("nPag"),
								resultSet.getInt("unidades_totales"),
								resultSet.getInt("unidades_prestadas"),
								resultSet.getInt("idEditorial"),
								resultSet.getBoolean("activo"));
						PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM librotexto WHERE id = ?");
						preparedStatement.setInt(1, tLibroRes.getID());
						ResultSet result = preparedStatement.executeQuery();
						if(result.next()){
							tLibro = new TLibroTexto(tLibroRes.getID(), tLibroRes.getTitulo(), tLibroRes.getAutor(), tLibroRes.getISBN(),
									tLibroRes.getPaginas(),tLibroRes.getUnidadesTotales(), tLibroRes.getUnidadesPrestadas(),
									tLibroRes.getEditorial(), tLibroRes.getActivo(), Asignatura.transform(result.getString("asignatura")));
						}
						else{
							preparedStatement.close();
							result.close();
							preparedStatement = connection.prepareStatement("SELECT * FROM libroliteratura WHERE id = ?");
							preparedStatement.setInt(1, tLibroRes.getID());
							result = preparedStatement.executeQuery();
							if(result.next())
									tLibro = new TLibroLiteratura(tLibroRes.getID(), tLibroRes.getTitulo(), tLibroRes.getAutor(), tLibroRes.getISBN(),
											tLibroRes.getPaginas(),tLibroRes.getUnidadesTotales(), tLibroRes.getUnidadesPrestadas(),
											tLibroRes.getEditorial(), tLibroRes.getActivo(), Genero.transform(result.getString("genero")));
						}
						libros.add(tLibro);
						preparedStatement.close();
						result.close();
					}
					prepareStatement.close();
					resultSet.close();
				} catch (SQLException e) {
					tLibro = null;
				}
			}
		}
		if(libros.isEmpty()) libros = null;
		return libros;
	}

	public ArrayList<TLibro> buscarPorAutor(String autores) {
		TLibro tLibro = null, tLibroRes = null;
		ArrayList<TLibro> libros = new ArrayList<>();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			
			if(connection != null) {
				try {
					PreparedStatement prepareStatement = connection.prepareStatement("SELECT * FROM libro WHERE autores = ?");
					prepareStatement.setString(1, autores);
					ResultSet resultSet = prepareStatement.executeQuery();
					
					while(resultSet.next()) {
							tLibroRes = new TLibro(resultSet.getInt("id"),
									resultSet.getString("titulo"),
									resultSet.getString("autores"),
									resultSet.getString("ISBN"),
									resultSet.getInt("nPag"),
									resultSet.getInt("unidades_totales"),
									resultSet.getInt("unidades_prestadas"),
									resultSet.getInt("idEditorial"),
									resultSet.getBoolean("activo"));
							PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM librotexto WHERE id = ?");
							preparedStatement.setInt(1, resultSet.getInt("id"));
							ResultSet result = preparedStatement.executeQuery();
							if(result.next()){
								tLibro = new TLibroTexto(tLibroRes.getID(), tLibroRes.getTitulo(), tLibroRes.getAutor(), tLibroRes.getISBN(),
										tLibroRes.getPaginas(),tLibroRes.getUnidadesTotales(), tLibroRes.getUnidadesPrestadas(),
										tLibroRes.getEditorial(), tLibroRes.getActivo(), Asignatura.transform(result.getString("asignatura")));
							}
							else{
								preparedStatement.close();
								result.close();
								preparedStatement = connection.prepareStatement("SELECT * FROM libroliteratura WHERE id = ?");
								preparedStatement.setInt(1, tLibroRes.getID());
								result = preparedStatement.executeQuery();
								if(result.next())
									tLibro = new TLibroLiteratura(tLibroRes.getID(), tLibroRes.getTitulo(), tLibroRes.getAutor(), tLibroRes.getISBN(),
											tLibroRes.getPaginas(),tLibroRes.getUnidadesTotales(), tLibroRes.getUnidadesPrestadas(),
											tLibroRes.getEditorial(), tLibroRes.getActivo(), Genero.transform(result.getString("genero")));
							}
							libros.add(tLibro);
							preparedStatement.close();
							result.close();
					}
					prepareStatement.close();
					resultSet.close();
				} catch (SQLException e) {
					tLibro = null;
				}
			}
		}
		if(libros.isEmpty()) libros = null;
		return libros;
	}

	public TLibro buscarPorISBN(String isbn) {
		TLibro tLibro = null, tLibroRes = null;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			
			if(connection != null) {
				try {
					PreparedStatement prepareStatement = connection.prepareStatement("SELECT * FROM libro WHERE ISBN= ? FOR UPDATE");
					prepareStatement.setString(1, isbn);
					ResultSet resultSet = prepareStatement.executeQuery();
					
					if(resultSet.next()) {
						tLibroRes = new TLibro(resultSet.getInt("id"),
								resultSet.getString("titulo"),
								resultSet.getString("autores"),
								resultSet.getString("ISBN"),
								resultSet.getInt("nPag"),
								resultSet.getInt("unidades_totales"),
								resultSet.getInt("unidades_prestadas"),
								resultSet.getInt("idEditorial"),
								resultSet.getBoolean("activo"));
						prepareStatement = connection.prepareStatement("SELECT * FROM librotexto WHERE id = ?");
						prepareStatement.setInt(1, tLibroRes.getID());
						ResultSet result = prepareStatement.executeQuery();
						if(result.next()){
							tLibro = new TLibroTexto(tLibroRes.getID(), tLibroRes.getTitulo(), tLibroRes.getAutor(), tLibroRes.getISBN(),
									tLibroRes.getPaginas(),tLibroRes.getUnidadesTotales(), tLibroRes.getUnidadesPrestadas(),
									tLibroRes.getEditorial(), tLibroRes.getActivo(), Asignatura.transform(result.getString("asignatura")));
						}
						else{
							prepareStatement.close();
							result.close();
							prepareStatement = connection.prepareStatement("SELECT * FROM libroliteratura WHERE id = ?");
							prepareStatement.setInt(1, tLibroRes.getID());
							result = prepareStatement.executeQuery();
							if(result.next())
									tLibro = new TLibroLiteratura(tLibroRes.getID(), tLibroRes.getTitulo(), tLibroRes.getAutor(), tLibroRes.getISBN(),
											tLibroRes.getPaginas(),tLibroRes.getUnidadesTotales(), tLibroRes.getUnidadesPrestadas(),
											tLibroRes.getEditorial(), tLibroRes.getActivo(), Genero.transform(result.getString("genero")));
						}
						result.close();
					}
					prepareStatement.close();
					resultSet.close();
				} catch (SQLException e) {
					tLibro = null;
				}
			}
		}
		return tLibro;
	}
}