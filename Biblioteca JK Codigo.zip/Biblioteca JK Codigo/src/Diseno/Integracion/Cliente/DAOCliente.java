/**
 * 
 */
package Diseno.Integracion.Cliente;

import Diseno.Negocio.Cliente.TCliente;
import Diseno.Negocio.Cliente.TPrestamo;

import java.util.ArrayList;
import java.util.Date;


public interface DAOCliente {

	public int altaCliente(TCliente tCliente);

	public int bajaCliente(int id);

	public int actualizarCliente(TCliente tCliente);

	public TCliente buscarCliente(int id);

	public ArrayList<TCliente> mostrarClientes();

	public TCliente buscarPorDNI(String DNI);

	public boolean realizarPrestamo(TPrestamo tPrestamo);

	public TPrestamo buscarPrestamo(int idCliente, int idLibro, Date fechaI);

	public ArrayList<TPrestamo> mostrarPrestamos();

	public boolean devolverPrestamo(TPrestamo tPrestamo);
	
	public boolean buscarPrestamosActivosCliente(int idCliente);
}