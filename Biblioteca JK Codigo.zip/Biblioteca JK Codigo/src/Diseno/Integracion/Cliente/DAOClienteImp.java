/**
 * 
 */
package Diseno.Integracion.Cliente;

import Diseno.Integracion.Transaccion.Transaction;
import Diseno.Integracion.Transaccion.TransactionManager;
import Diseno.Negocio.Cliente.TCliente;
import Diseno.Negocio.Cliente.TPrestamo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;


public class DAOClienteImp implements DAOCliente {

	public int altaCliente(TCliente tCliente) {
		int id = -100;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			if(connection != null) {
				String nombre, apellidos, DNI, email, carnet;
				int telefono;
				boolean activo;
				nombre = tCliente.getNombre();
				apellidos = tCliente.getApellidos();
				DNI = tCliente.getDNI();
				carnet = tCliente.getCarnet();
				email = tCliente.getEmail();
				telefono = tCliente.getTelefono();
				activo = tCliente.getActivo();
				try {
					String insert = "INSERT INTO cliente (nombre, apellidos, dni, carnet, email, telefono, activo) VALUES(?,?,?,?,?,?,?)";
					PreparedStatement prepareStatement = connection.prepareStatement(insert);
					prepareStatement.setString(1, nombre);
					prepareStatement.setString(2, apellidos);
					prepareStatement.setString(3, DNI);
					prepareStatement.setString(4, carnet);
					prepareStatement.setString(5, email);
					prepareStatement.setInt(6, telefono);
					prepareStatement.setBoolean(7, activo);// Cuando lo das de alta siempre esta activo
					prepareStatement.executeUpdate();
					prepareStatement.close();
					prepareStatement = connection.prepareStatement("SELECT last_insert_id() as last_id from cliente");
					ResultSet resultSet = prepareStatement.executeQuery();
					if(resultSet.next()) {
						id = resultSet.getInt("last_id");
					}
					prepareStatement.close();
					resultSet.close();
				} catch (SQLException e) {
					id = -100;
				}
			}
		}
		return id;
	}


	public int bajaCliente(int id) {
		int r = -100;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if (transaction != null) {
			Connection object = (Connection) transaction.getResource();
			if (object != null) {
				try {
					String query = "UPDATE cliente SET activo=0 WHERE id=?";
					PreparedStatement preparedStatement = object.prepareStatement(query);
					preparedStatement.setInt(1, id);
					preparedStatement.executeUpdate();
					preparedStatement.close();
					r = id;
				} catch (SQLException e) {
					r = -100;
				}
			}
		}
		return r;
	}


	public int actualizarCliente(TCliente tCliente) {
		int id = -100;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if (transaction != null) {
			Connection object = (Connection) transaction.getResource();
			if (object != null) {
				String nombre, apellidos, DNI, email, carnet;
				int telefono, idCliente;
				boolean activo;
				idCliente = tCliente.getIdCliente();
				nombre = tCliente.getNombre();
				apellidos = tCliente.getApellidos();
				DNI = tCliente.getDNI();
				carnet = tCliente.getCarnet();
				email = tCliente.getEmail();
				telefono = tCliente.getTelefono();
				activo = tCliente.getActivo();
				try {
					String query = "UPDATE cliente SET nombre=?, apellidos=?, dni=?, carnet=?, email=?, telefono=?, activo=? WHERE id=?";
					PreparedStatement prepareStatement = object.prepareStatement(query); 
					prepareStatement.setString(1, nombre);
					prepareStatement.setString(2, apellidos);
					prepareStatement.setString(3, DNI);
					prepareStatement.setString(4, carnet);
					prepareStatement.setString(5, email);
					prepareStatement.setInt(6, telefono);
					if(activo){
						prepareStatement.setInt(7, 1);
					}
					else{
						prepareStatement.setInt(7, 0);
					}
					prepareStatement.setInt(8, idCliente);
					prepareStatement.executeUpdate();
					prepareStatement.close();
					id = idCliente;
					} catch (SQLException e) {
					id = -100;
				}
			}

		}
		return id;
	}

	public TCliente buscarCliente(int id) {
		TCliente tCliente = null;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			if(connection != null) {
				try {
					PreparedStatement prepareStatement = connection.prepareStatement("SELECT * FROM cliente WHERE id=? FOR UPDATE");
					prepareStatement.setInt(1, id);
					ResultSet resultSet = prepareStatement.executeQuery();
					if(resultSet.next()) {
						String nombre, apellidos, DNI, email, carnet;
						int telefono;
						boolean activo;
						nombre = resultSet.getString("nombre");
						apellidos = resultSet.getString("apellidos");
						DNI = resultSet.getString("dni");
						carnet = resultSet.getString("carnet");
						email = resultSet.getString("email");
						telefono = resultSet.getInt("telefono");
						activo = resultSet.getBoolean("activo");
						tCliente = new TCliente(id, nombre, apellidos, DNI, carnet, email, telefono, activo);
					}
					prepareStatement.close();
					resultSet.close();
				} catch (SQLException e) {
					tCliente = null;
				}
			}
		}
		return tCliente;
	}

	public ArrayList<TCliente> mostrarClientes() {
		TCliente tCliente;
		ArrayList<TCliente> clientes = new ArrayList<>();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			if(connection != null) {
				try {
					PreparedStatement prepareStatement = connection.prepareStatement("SELECT * FROM cliente where activo=1");
					ResultSet resultSet = prepareStatement.executeQuery();
					while(resultSet.next()) {
						String nombre, apellidos, DNI, email, carnet;
						int id, telefono;
						boolean activo;
						id = resultSet.getInt("id");
						nombre = resultSet.getString("nombre");
						apellidos = resultSet.getString("apellidos");
						DNI = resultSet.getString("dni");
						carnet = resultSet.getString("carnet");
						email = resultSet.getString("email");
						telefono = resultSet.getInt("telefono");
						activo = resultSet.getBoolean("activo");
						tCliente = new TCliente(id, nombre, apellidos, DNI, carnet, email, telefono, activo);
						clientes.add(tCliente);
					}
					prepareStatement.close();
					resultSet.close();
				} catch (SQLException e) {
					tCliente = null;
				}
			}
		}
		if(clientes.isEmpty()) clientes = null;
		return clientes;
	}

	/** 
	* (non-Javadoc)
	* @see DAOCliente#buscarPorDNI(String DNI)
	* @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public TCliente buscarPorDNI(String DNI) {
		TCliente tCliente = null;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if (transaction != null) {
			Connection object = (Connection) transaction.getResource();
			if (object != null) {
				try{
					String query = "SELECT * FROM cliente WHERE dni='" + DNI + "' FOR UPDATE";
					PreparedStatement preparedStatement =  object.prepareStatement(query);
					ResultSet resultSet = preparedStatement.executeQuery();
					if(resultSet.next()) {
						tCliente = new TCliente(
								resultSet.getInt("id"),
								resultSet.getString("nombre"),
								resultSet.getString("apellidos"),
								resultSet.getString("dni"),
								resultSet.getString("carnet"),
								resultSet.getString("email"),
								resultSet.getInt("telefono"),
								resultSet.getBoolean("activo")
								);
					}
					preparedStatement.close();
					resultSet.close();
				} catch (SQLException e) {
					tCliente = null;
				}
			}

		}
		return tCliente;
	}

	/** 
	* (non-Javadoc)
	* @see DAOCliente#realizarPrestamo(TPrestamo tPrestamo)
	* @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public boolean realizarPrestamo(TPrestamo tPrestamo) {
		boolean correcto = false;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			if(connection != null) {
				try {
					int idCliente, idLibro;
					Date fechaI, fechaF;
					boolean devuelto;
					idCliente = tPrestamo.getIdCliente();
					idLibro = tPrestamo.getIdLibro();
					fechaI = tPrestamo.getFechaI();
					fechaF = tPrestamo.getFechaF();
					devuelto = tPrestamo.getDevuelto();
					PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO prestamo (idCliente, idLibro, fechaI, fechaF, devuelto) VALUES (?,?,?,?,?)");
					preparedStatement.setInt(1, idCliente);
					preparedStatement.setInt(2, idLibro);
					preparedStatement.setDate(3, new java.sql.Date( fechaI.getTime()));
					preparedStatement.setDate(4, new java.sql.Date( fechaF.getTime()));
					preparedStatement.setBoolean(5, devuelto);
					preparedStatement.executeUpdate();
					correcto = true;
					preparedStatement.close();
				} catch (SQLException e) {
					correcto = false;
				}
			}
		}
		return correcto;
	}

	public TPrestamo buscarPrestamo(int idCliente, int idLibro, Date fechaI) {
		TPrestamo tPrestamo = null;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			if(connection != null) {
				try {
					PreparedStatement prepareStatement = connection.prepareStatement("SELECT * FROM prestamo WHERE idCliente=? AND idLibro=? AND fechaI=?");
					prepareStatement.setInt(1, idCliente);
					prepareStatement.setInt(2, idLibro);
					prepareStatement.setDate(3, new java.sql.Date( fechaI.getTime()));
					ResultSet resultSet = prepareStatement.executeQuery();
					if(resultSet.next()) {
						Date fechaF;
						boolean devuelto;
						fechaF = resultSet.getDate("fechaF");
						devuelto = resultSet.getBoolean("devuelto");
						tPrestamo = new TPrestamo(idCliente, idLibro, fechaI, fechaF, devuelto);
					}
					prepareStatement.close();
					resultSet.close();
				} catch (SQLException e) {
					tPrestamo = null;
				}
			}
		}
		return tPrestamo;
	}

	public boolean buscarPrestamosActivosCliente(int idCliente) {
		boolean pendientes = true;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			if(connection != null) {
				try {
					PreparedStatement prepareStatement = connection.prepareStatement("SELECT * FROM prestamo WHERE idCliente=? AND devuelto=0");
					prepareStatement.setInt(1, idCliente);
					ResultSet resultSet = prepareStatement.executeQuery();
					if(resultSet.next()) {
						pendientes =  true;
					}
					else pendientes = false;
					prepareStatement.close();
					resultSet.close();
				} catch (SQLException e) {
					pendientes = true;;
				}
			}
		}
		return pendientes;
	}
	
	
	
	public ArrayList<TPrestamo> mostrarPrestamos() {
		TPrestamo tPrestamo = null;
		ArrayList<TPrestamo> prestamos = new ArrayList<>();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if(transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			if(connection != null) {
				try {
					PreparedStatement prepareStatement = connection.prepareStatement("SELECT * FROM prestamo");
					ResultSet resultSet = prepareStatement.executeQuery();
					while(resultSet.next()) {
						int idCliente, idLibro;
						Date fechaI, fechaF;
						boolean devuelto;
						idCliente = resultSet.getInt("idCliente");
						idLibro = resultSet.getInt("idLibro");
						fechaI = resultSet.getDate("fechaI");
						fechaF = resultSet.getDate("fechaF");
						devuelto = resultSet.getBoolean("devuelto");
						tPrestamo = new TPrestamo(idCliente, idLibro, fechaI, fechaF, devuelto);
						prestamos.add(tPrestamo);
					}
					prepareStatement.close();
					resultSet.close();
				} catch (SQLException e) {
					prestamos = null;
				}
			}
		}
		if(prestamos.isEmpty()) prestamos = null;
		return prestamos;
	}

	
	public boolean devolverPrestamo(TPrestamo tPrestamo) {
		boolean r = true;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.getTransaccion();
		if (transaction != null) {
			Connection connection = (Connection) transaction.getResource();
			if (connection != null) {
				try {
					int idCliente = tPrestamo.getIdCliente();
					int idLibro = tPrestamo.getIdLibro();
					Date fechaI = tPrestamo.getFechaI();
					String query = "UPDATE prestamo SET devuelto=1 WHERE idCliente=? AND idLibro=? AND fechaI=?";
					PreparedStatement preparedStatement = connection.prepareStatement(query);
					preparedStatement.setInt(1, idCliente);
					preparedStatement.setInt(2, idLibro);
					preparedStatement.setDate(3, new java.sql.Date( fechaI.getTime()));
					
					preparedStatement.executeUpdate();
					preparedStatement.close();
				} catch (SQLException e) {
					r = false;
				}
			}

		}
		return r;
	}
}