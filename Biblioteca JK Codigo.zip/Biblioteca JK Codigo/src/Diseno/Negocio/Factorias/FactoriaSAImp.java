package Diseno.Negocio.Factorias;

import Diseno.Negocio.Centro.SACentro;
import Diseno.Negocio.Centro.SACentroImp;
import Diseno.Negocio.Cliente.SACliente;
import Diseno.Negocio.Cliente.SAClienteImp;
import Diseno.Negocio.Curso.SACurso;
import Diseno.Negocio.Curso.SACursoImp;
import Diseno.Negocio.Editorial.SAEditorial;
import Diseno.Negocio.Editorial.SAEditorialImp;
import Diseno.Negocio.Libro.SALibroImp;
import Diseno.Negocio.Trabajador.SATrabajador;
import Diseno.Negocio.Trabajador.SATrabajadorImp;

public class FactoriaSAImp extends FactoriaSA {

	@Override
	public SAEditorial crearSAEditorial() {
		return new SAEditorialImp();
	}

	@Override
	public SACliente crearSACliente() {
		return new SAClienteImp();
	}

	@Override
	public SALibroImp crearSALibro() {
		return new SALibroImp();
	}

	@Override
	public SACurso crearSACurso() {
		return new SACursoImp();
	}

	@Override
	public SATrabajador crearSATrabajador() {
		return new SATrabajadorImp();
	}

	@Override
	public SACentro crearSACentro() {
		return new SACentroImp();
	}

}
