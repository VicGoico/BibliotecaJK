package Diseno.Negocio.Factorias;

import Diseno.Negocio.Editorial.SAEditorial;
import Diseno.Negocio.Libro.SALibro;
import Diseno.Negocio.Trabajador.SATrabajador;
import Diseno.Negocio.Centro.SACentro;
import Diseno.Negocio.Cliente.SACliente;
import Diseno.Negocio.Curso.SACurso;

public abstract class FactoriaSA {
	
	
	private static FactoriaSA instance;
	
	public synchronized static FactoriaSA getInstance() {
		if(instance == null) {
			instance = new FactoriaSAImp();
		}
		return instance;
	}

	public abstract SAEditorial crearSAEditorial();

	public abstract SACliente crearSACliente();

	public abstract SALibro crearSALibro();
	
	public abstract SACurso crearSACurso();

	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @return
	* @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public abstract SATrabajador crearSATrabajador();
	
	public abstract SACentro crearSACentro();
}