package Diseno.Negocio.Editorial;

import java.util.ArrayList;

public interface SAEditorial {
	
	public int altaEditorial(TEditorial tEditorial);

	public int bajaEditorial(int idEditorial);

	public int actualizarEditorial(TEditorial tEditorial);

	public TEditorial buscarEditorial(int idEditorial);

	public ArrayList<TEditorial> mostrarEditoriales();
}