package Diseno.Negocio.Editorial;

public class TEditorial {
	
	private int idEditorial;
	private String nombre;
	private String direccion;
	private boolean activo;
	private int numLibrosActivos;

	public TEditorial(int idEditorial, String nombre, String direccion, boolean activo, int numLibrosActivos) {
		this.idEditorial = idEditorial;
		this.nombre = nombre;
		this.direccion = direccion;
		this.activo = activo;
		this.numLibrosActivos = numLibrosActivos;
	}

	public TEditorial(String nombre, String direccion, boolean activo, int numLibrosActivos) {
		this.nombre = nombre;
		this.direccion = direccion;
		this.activo = activo;
		this.numLibrosActivos = numLibrosActivos;
	}

	public int getIdEditorial() {
		return this.idEditorial;
	}

	public String getNombre() {
		return this.nombre;
	}

	public String getDireccion() {
		return this.direccion;
	}

	public int getNumLibrosActivos() {
		return this.numLibrosActivos;
	}

	public boolean getActivo() {
		return this.activo;
	}

	public void setIdEditorial(int idEditorial) {
		this.idEditorial = idEditorial;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public void setNumLibrosActivos(int numLibrosActivos) {
		this.numLibrosActivos = numLibrosActivos;
	}

	
	public void setActivo(boolean activo) {
		this.activo = activo;
	}
}