package Diseno.Negocio.Editorial;

import java.util.ArrayList;

import Diseno.Integracion.Editorial.DAOEditorialImp;
import Diseno.Integracion.Factoria.FactoriaIntegracionImp;
import Diseno.Integracion.Transaccion.Transaction;
import Diseno.Integracion.Transaccion.TransactionManager;

public class SAEditorialImp implements SAEditorial {

	public int altaEditorial(TEditorial tEditorial) {
		int idDevuelve = -1;
		String nombre = tEditorial.getNombre();
		TransactionManager manager = TransactionManager.getInstance();
		Transaction transaccion = manager.nuevaTransaccion();
		if (transaccion != null) {
			transaccion.start();
			FactoriaIntegracionImp factoriaDAO = new FactoriaIntegracionImp();
			DAOEditorialImp DAoEditorial = (DAOEditorialImp) factoriaDAO.crearDAOEditorial();
			TEditorial tEditorialLeido = DAoEditorial.buscarPorNombre(nombre);

			if (tEditorialLeido == null) {// No existe
				idDevuelve = DAoEditorial.alta(tEditorial);
				transaccion.commit();
			} 
			else {
				if (!tEditorialLeido.getActivo()) {// Reactivacion
					tEditorial.setActivo(true);
					tEditorial.setIdEditorial(tEditorialLeido.getIdEditorial());
					idDevuelve = DAoEditorial.modificar(tEditorial);
					transaccion.commit();
				} 
				else {
					transaccion.rollback();
				}
			}
		}
		manager.eliminaTransaccion();

		return idDevuelve;
	}

	public int bajaEditorial(int idEditorial) {
		int idDevuelve = -1;
		TransactionManager manager = TransactionManager.getInstance();
		Transaction transaccion = manager.nuevaTransaccion();
		if (transaccion != null) {
			transaccion.start();
			FactoriaIntegracionImp factoriaDAO = new FactoriaIntegracionImp();
			DAOEditorialImp DAoEditorial = (DAOEditorialImp) factoriaDAO.crearDAOEditorial();
			TEditorial TEditorialLeido = DAoEditorial.buscar(idEditorial);
			if (TEditorialLeido == null) {// No existe libro
				transaccion.rollback();
			} 
			else {
				int numLibrosActivos = TEditorialLeido.getNumLibrosActivos();
				if (numLibrosActivos == 0) {
					if (TEditorialLeido.getActivo()) {
						idDevuelve = DAoEditorial.baja(idEditorial);
						transaccion.commit();
					} 
					else {
						idDevuelve = -2;
						transaccion.rollback();
					}
				} 
				else {
					idDevuelve = -3;
					transaccion.rollback();
				}
			}
		}
		manager.eliminaTransaccion();
		return idDevuelve;
	}

	public int actualizarEditorial(TEditorial tEditorial) {
		int idDevuelve = -1;
		TransactionManager manager = TransactionManager.getInstance();
		Transaction transaccion = manager.nuevaTransaccion();
		if (transaccion != null) {
			transaccion.start();
			FactoriaIntegracionImp factoriaDAO = new FactoriaIntegracionImp();
			DAOEditorialImp DAoEditorial = (DAOEditorialImp) factoriaDAO.crearDAOEditorial();
			TEditorial tLeido = DAoEditorial.buscar(tEditorial.getIdEditorial());
			if(tLeido == null){// No existe
				idDevuelve = -4;
				transaccion.rollback();
			}
			else{// Existe
				tEditorial.setNumLibrosActivos(tLeido.getNumLibrosActivos());// Nos aseguramos de no perder los libros activos de la editorial
				if(tLeido.getActivo()){ // Esta Activo
					if(tLeido.getNombre().equalsIgnoreCase(tEditorial.getNombre())){// Si son el mismo nombre
						tEditorial.setActivo(tLeido.getActivo());
						idDevuelve = DAoEditorial.modificar(tEditorial);
						transaccion.commit();
					}
					else{// Nombre distinto
						TEditorial tLeidoOtraVez = DAoEditorial.buscarPorNombre(tEditorial.getNombre());
						if(tLeidoOtraVez == null){// No existe el nuevo nombre
							idDevuelve = DAoEditorial.modificar(tEditorial);
							transaccion.commit();
						}
						else{// Ya existe el nuevo nombre
							idDevuelve = -2;
							transaccion.rollback();
						}
					}
				}
				else{// esta inactivo
					idDevuelve = -3;
					transaccion.rollback();
				}
			}
		}
		manager.eliminaTransaccion();
		return idDevuelve;
	}

	public TEditorial buscarEditorial(int idEditorial) {
		TEditorial tDevuelta = null;
		TransactionManager manager = TransactionManager.getInstance();
		Transaction transaccion = manager.nuevaTransaccion();
		if (transaccion != null) {
			transaccion.start();
			FactoriaIntegracionImp factoriaDAO = new FactoriaIntegracionImp();
			DAOEditorialImp DAoEditorial = (DAOEditorialImp) factoriaDAO.crearDAOEditorial();
			tDevuelta = DAoEditorial.buscar(idEditorial);
			transaccion.commit();
		}
		manager.eliminaTransaccion();
		return tDevuelta;
	}

	public ArrayList<TEditorial> mostrarEditoriales() {
		TransactionManager manager = TransactionManager.getInstance();
		Transaction transaccion = manager.nuevaTransaccion();
		ArrayList<TEditorial> editoriales = null;
		if (transaccion != null) {
			transaccion.start();
			FactoriaIntegracionImp factoriaDAO = new FactoriaIntegracionImp();
			DAOEditorialImp DAoEditorial = (DAOEditorialImp) factoriaDAO.crearDAOEditorial();
			editoriales = DAoEditorial.mostrar();
			transaccion.commit();
		}
		manager.eliminaTransaccion();
		return editoriales;
	}
}