/**
 * 
 */
package Diseno.Negocio.Trabajador;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import java.io.Serializable;
import javax.persistence.NamedQuery;
import javax.persistence.NamedQueries;
import java.util.ArrayList;
import Diseno.Negocio.Curso.Curso;
import javax.persistence.OneToMany;
import javax.persistence.Version;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

@Entity
@NamedQueries({
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Matricularse.findByidMatricula", query = "select obj from Matricularse obj where :idMatricula = obj.idMatricula "),
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Matricularse.findByactivo", query = "select obj from Matricularse obj where :activo = obj.activo "),
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Matricularse.findByversion", query = "select obj from Matricularse obj where :version = obj.version "),
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Matricularse.mostrarMatriculas", query = "select obj from Matricularse obj")})
public class Matricularse implements Serializable {

	private static final long serialVersionUID = 0;

	private boolean activo;

	@Version
	private int version;
	
	@EmbeddedId private IdMatricula idMatricula;
	
	@ManyToOne
	@MapsId("idTrabajador") private Trabajador trabajador;
	
	@ManyToOne
	@MapsId("idCurso") private Curso curso;
	

	public Matricularse() {
	}
	
	public Matricularse(Curso curso, Trabajador trabajador) {
		this.trabajador = trabajador;
		this.curso = curso;
	}

	

	public boolean getActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}

	public Trabajador getTrabajador() {
		return trabajador;
	}

	public void setTrabajador(Trabajador trabajador) {
		this.trabajador = trabajador;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	public IdMatricula getId() {
		return idMatricula;
	}

	public void setId(IdMatricula id) {
		this.idMatricula = id;
	}

	public TMatricula entityToTransfer() {
		return new TMatricula(this.idMatricula.getIdTrabajador(), this.idMatricula.getIdCurso(), this.activo);
	}
}