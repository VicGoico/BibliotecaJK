/**
 * 
 */
package Diseno.Negocio.Trabajador;

import java.util.ArrayList;

public interface SATrabajador {

	public int altaTrabajador(TTrabajador tTrabjador);

	public TTrabajador buscarTrabajador(int idTrabajador);

	public ArrayList<TTrabajador> mostrarTrabajadores();

	public int actualizarTrabajador(TTrabajador tTrabajador);

	public int bajaTrabajador(int idTrabajador);

	public int matricularse(TMatricula tTrabajadorCurso);

	public ArrayList<TMatricula> mostrarMatricular();

	public int desmatricularse(TMatricula tTrabajadorCurso);
}