/**
 * 
 */
package Diseno.Negocio.Trabajador;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author Bolil
 * @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class TTrabajador {

	private int id;

	private String nombre;

	private String apellido;

	private String DNI;

	private String cargo;

	private double salario;

	private Boolean activo;

	public TTrabajador(int id, String nombre, String apellido, String DNI, String cargo, double salario, boolean activo) {
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.DNI = DNI;
		this.cargo = cargo;
		this.salario = salario;
		this.activo = activo;
	}

	public TTrabajador(String nombre, String apellido, String DNI, String cargo, double salario, boolean activo) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.DNI = DNI;
		this.cargo = cargo;
		this.salario = salario;
		this.activo = activo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getDNI() {
		return DNI;
	}

	public void setDNI(String dNI) {
		DNI = dNI;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}
	
	
}