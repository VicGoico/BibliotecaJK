/**
 * 
 */
package Diseno.Negocio.Trabajador;


public class TMatricula {

	private int idTrabajador;

	private int idCurso;

	private boolean activo;
	
	public TMatricula(int idTrabajador, int idCurso, boolean activo) {
		this.idTrabajador = idTrabajador;
		this.idCurso = idCurso;
		this.activo = activo;
	}

	public int getIdTrabajador() {
		return idTrabajador;
	}

	public void setIdTrabajador(int idTrabajador) {
		this.idTrabajador = idTrabajador;
	}

	public int getIdCurso() {
		return idCurso;
	}

	public void setIdCurso(int idCurso) {
		this.idCurso = idCurso;
	}

	public boolean isActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	
}