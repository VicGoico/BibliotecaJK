/**
 * 
 */
package Diseno.Negocio.Trabajador;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import java.io.Serializable;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.NamedQueries;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.OneToMany;
import javax.persistence.Version;

@Entity
@NamedQueries({
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Trabajador.findByid", query = "select obj from Trabajador obj where :id = obj.id "),
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Trabajador.findBynombre", query = "select obj from Trabajador obj where :nombre = obj.nombre "),
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Trabajador.findByapellidos", query = "select obj from Trabajador obj where :apellidos = obj.apellidos "),
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Trabajador.findByDNI", query = "select obj from Trabajador obj where :DNI = obj.DNI "),
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Trabajador.findBycargo", query = "select obj from Trabajador obj where :cargo = obj.cargo "),
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Trabajador.findBysalario", query = "select obj from Trabajador obj where :salario = obj.salario "),
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Trabajador.findByactivo", query = "select obj from Trabajador obj where :activo = obj.activo "),
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Trabajador.findByversion", query = "select obj from Trabajador obj where :version = obj.version "),
		@NamedQuery(name = "Diseno.Negocio.Trabajador.Trabajador.mostrarTrabajador", query = "select obj from Trabajador obj where obj.activo = 1")})
public class Trabajador implements Serializable {

	private static final long serialVersionUID = 0;

	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String nombre;

	private String apellidos;

	private String DNI;

	private String cargo;

	private double salario;

	private Boolean activo;
	
	private int numMatriculas;
	
	@OneToMany (mappedBy="trabajador")
	private Collection<Matricularse> matricula;

	@Version
	private int version;

	public Trabajador() {
	}

	public Trabajador(TTrabajador tTrabajador) {
		if(tTrabajador.getId() > -1) this.id = tTrabajador.getId(); //En las funciones que no requieran id (alta) se mandará -1 desde presentación
		this.nombre = tTrabajador.getNombre();
		this.apellidos = tTrabajador.getApellido();
		this.DNI = tTrabajador.getDNI();
		this.cargo = tTrabajador.getCargo();
		this.salario = tTrabajador.getSalario();
		this.activo = tTrabajador.getActivo();
	}

	public int getId() {
		return this.id;
	}

	public String getNombre() {
		return this.nombre;
	}

	public String getApellido() {
		return this.apellidos;
	}

	public String getDNI() {
		return this.DNI;
	}

	public String getCargo() {
		return this.cargo;
	}

	public double getSalario() {
		return this.salario;
	}

	public Boolean getActivo() {
		return this.activo;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setApellido(String apellido) {
		this.apellidos = apellido;
	}

	public void setDNI(String DNI) {
		this.DNI = DNI;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}
	
	public int getNumMatriculas() {
		return this.numMatriculas;
	}

	public void setNumMatriculas(int numMatriculas) {
		this.numMatriculas = numMatriculas;
	}
	
	public Collection<Matricularse> getMatricula() {
		return matricula;
	}

	public void setMatricula(Collection<Matricularse> matricula) {
		this.matricula = matricula;
	}
	
	public TTrabajador entityToTransfer() {
		return new TTrabajador(this.id, this.nombre, this.apellidos, this.DNI, this.cargo, this.salario, this.activo);
	}
}