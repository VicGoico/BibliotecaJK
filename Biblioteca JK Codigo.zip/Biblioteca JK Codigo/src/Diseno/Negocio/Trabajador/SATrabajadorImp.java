/**
 * 
 */
package Diseno.Negocio.Trabajador;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import Diseno.Negocio.Curso.Curso;

public class SATrabajadorImp implements SATrabajador {
	
	/*
	 * -1: error por defecto
	 * -2: error transaction
	 * -3: ya esta activo
	 * -100: error base de datos
	 * */
	public int altaTrabajador(TTrabajador tTrabajador) {
		int id = -1;
		if (tTrabajador != null){
			String DNI = tTrabajador.getDNI();
			try{
				EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("BibliotecaJK");
				EntityManager entitymanager = emfactory.createEntityManager();
				EntityTransaction entitytransaction = entitymanager.getTransaction();
				if (entitytransaction != null){
					entitytransaction.begin();
					TypedQuery<Trabajador> query = entitymanager.createNamedQuery("Diseno.Negocio.Trabajador.Trabajador.findByDNI", Trabajador.class).setParameter("DNI", DNI);
					List<Trabajador> lista = query.getResultList();
					if(lista.isEmpty()) {
						tTrabajador.setActivo(true);
						Trabajador trabajador = new Trabajador(tTrabajador);
						trabajador.setNumMatriculas(0);
						entitymanager.persist(trabajador);
						entitytransaction.commit();
						id = trabajador.getId();
					}
					else {
						Trabajador trabajadorResult = lista.get(0);
						boolean activo = trabajadorResult.getActivo();
						if(activo) {
							id = -3;
							entitytransaction.rollback();
						}
						else{
							//Reactivacion y actualizacion
							trabajadorResult.setActivo(true);
							trabajadorResult.setNombre(tTrabajador.getNombre());
							trabajadorResult.setApellido(tTrabajador.getApellido());
							trabajadorResult.setCargo(tTrabajador.getCargo());
							trabajadorResult.setSalario(tTrabajador.getSalario());
							entitytransaction.commit();
							id = trabajadorResult.getId(); 
						}
					}
				}
				else{
					id = -2;
				}
				entitymanager.close();
				emfactory.close();
			} catch (PersistenceException ex){
				id = -100;
			}
		}	
		return id;
	}


	public TTrabajador buscarTrabajador(int idTrabajador) {
		TTrabajador tTrabajador = null;
		try {
			EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager entitymanager = emfactory.createEntityManager();
			EntityTransaction entitytransaction = entitymanager.getTransaction();
			if (entitytransaction != null){
				entitytransaction.begin();
				
				Trabajador trabajador = entitymanager.find(Trabajador.class, idTrabajador);
				
				if(trabajador == null)
					entitytransaction.rollback();
				else {
					tTrabajador = trabajador.entityToTransfer();
					entitytransaction.commit();
				}
			}
			entitymanager.close();
			emfactory.close();
		} catch(PersistenceException ex) {}
		
		return tTrabajador;
	}

	public ArrayList <TTrabajador> mostrarTrabajadores() {
		List<Trabajador> listaTrabajador = null;
		ArrayList<TTrabajador> listaTTrabajadores = new ArrayList<>();
		try {
			EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager entitymanager = emfactory.createEntityManager();
			EntityTransaction entitytransaction = entitymanager.getTransaction();
			if (entitytransaction != null){
				entitytransaction.begin();
				TypedQuery<Trabajador> query = entitymanager.createNamedQuery("Diseno.Negocio.Trabajador.Trabajador.mostrarTrabajador", Trabajador.class);
				listaTrabajador = query.getResultList();
				for(int i = 0; i < listaTrabajador.size(); ++i) {
					listaTTrabajadores.add(listaTrabajador.get(i).entityToTransfer());
				}
				if(listaTTrabajadores.size() == 0) {
					listaTTrabajadores = null;
					entitytransaction.rollback();
				}
				else entitytransaction.commit();
			}
			else {
				listaTTrabajadores = null;
			}
			entitymanager.close();
			emfactory.close();
		} catch(PersistenceException ex) {}
		return listaTTrabajadores;
	}

	/*
	 * -1: error por defecto
	 * -2: error transaction
	 * -3: Trabajador no encontrado
	 * -4: no esta activo
	 * -5: ese DNI ya está en uso
	 * -100: error base de datos
	 * */
	public int actualizarTrabajador(TTrabajador tTrabajador) {
		int idResult = -1;
		if(tTrabajador != null) {
			try {
				EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("BibliotecaJK");
				EntityManager entitymanager = emfactory.createEntityManager();
				EntityTransaction entitytransaction = entitymanager.getTransaction();
				if (entitytransaction != null){
					entitytransaction.begin();
					Trabajador trabajadorResult = entitymanager.find(Trabajador.class, tTrabajador.getId());
					if(trabajadorResult != null) {
						if(trabajadorResult.getActivo()) {
							TypedQuery<Trabajador> query = entitymanager.createNamedQuery("Diseno.Negocio.Trabajador.Trabajador.findByDNI", Trabajador.class).setParameter("DNI",tTrabajador.getDNI());
							List<Trabajador> lista = query.getResultList();
							if(lista.isEmpty() || lista.get(0).getId() == tTrabajador.getId()) {
								trabajadorResult.setNombre(tTrabajador.getNombre());
								trabajadorResult.setApellido(tTrabajador.getApellido());
								trabajadorResult.setDNI(tTrabajador.getDNI());
								trabajadorResult.setSalario(tTrabajador.getSalario());
								trabajadorResult.setCargo(tTrabajador.getCargo());
								entitytransaction.commit();
								idResult = tTrabajador.getId();
							}
							else {
								idResult = -5;
								entitytransaction.rollback();
							}
								
						}
						else {
							idResult = -4;
							entitytransaction.rollback();
						}
					}
					else {
						idResult = -3;
						entitytransaction.rollback();
					}
				}
				else idResult = -2;
				entitymanager.close();
				emfactory.close();
			} catch(PersistenceException ex) {
				idResult = -100;
			}
		}
		return idResult;	
	}

	/*
	 * -1: Error en la transaccion 
	 * -2: El trabajador no existe 
	 * -3: El trabajador no esta activo
	 * -4: El trabajador tiene matriculas activas
	 */
	public int bajaTrabajador(int idTrabajador) {
		try{
			EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager entitymanager = emfactory.createEntityManager();
			EntityTransaction entitytransaction = entitymanager.getTransaction();
			if (entitytransaction != null){
				entitytransaction.begin();
				Trabajador trabajador = entitymanager.find(Trabajador.class, idTrabajador);
				if (trabajador != null){
					if(trabajador.getNumMatriculas() == 0) {
						boolean activa = trabajador.getActivo();
						if (activa){
							trabajador.setActivo(false);
							entitytransaction.commit();
						}
						else{
							idTrabajador = -3;
							entitytransaction.rollback();
						}
					}
					else {
						idTrabajador = -4;
						entitytransaction.rollback();
					}
				}
				else{
					idTrabajador = -2;
					entitytransaction.rollback();
				}
			}
			else{
				idTrabajador = -1;
			}
			entitymanager.close();
			emfactory.close();
		}catch (PersistenceException ex){
			idTrabajador = -100;
		}
		
		return idTrabajador;
	}

	/*
	 * No usamos bloqueos, porque modificamos numMatrículas
	 * y el número de plazas en la entidad Curso
	 * y modificamos numMatrículas en la entidad Trabajador
	 */
	public int matricularse(TMatricula tTrabajadorCurso) {
		int id = -1;
		if(tTrabajadorCurso != null) {
			try {
				EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("BibliotecaJK");
				EntityManager entitymanager = emfactory.createEntityManager();
				EntityTransaction entitytransaction = entitymanager.getTransaction();
				if(entitytransaction != null) {
					entitytransaction.begin();
					Curso cursoResult = entitymanager.find(Curso.class, tTrabajadorCurso.getIdCurso());
					Trabajador trabajadorResult = entitymanager.find(Trabajador.class, tTrabajadorCurso.getIdTrabajador());
					if(cursoResult != null)  {
						if(trabajadorResult != null) {
							if(cursoResult.getActivo()) {
								if(trabajadorResult.getActivo()) {
									int plazas = cursoResult.getNumPlazas();
									if(plazas>0) {
										IdMatricula idMatricula = new IdMatricula(tTrabajadorCurso.getIdCurso(), tTrabajadorCurso.getIdTrabajador());
										Matricularse matricularseResult = entitymanager.find(Matricularse.class, idMatricula);
										if(matricularseResult == null) {
											int numMatriculados = cursoResult.getNumMatriculados();
											cursoResult.setNumMatriculados(numMatriculados + 1);
											cursoResult.setNumPlazas(plazas-1);
											//Se ha modificado la entidad Curso
											trabajadorResult.setNumMatriculas(trabajadorResult.getNumMatriculas() + 1);
											//Se ha modificado la entidad Trabajador
											Matricularse matricularse = new Matricularse(cursoResult, trabajadorResult);
											matricularse.setActivo(true);
											entitymanager.persist(matricularse);
											entitytransaction.commit();
											id = idMatricula.hashCode();
										} else {
											if(matricularseResult.getActivo()) {
												entitytransaction.rollback();
												id = -8;
											} else {
												//REACTIVACION
												int numMatriculados = cursoResult.getNumMatriculados();
												cursoResult.setNumMatriculados(numMatriculados + 1);
												cursoResult.setNumPlazas(plazas-1);
												trabajadorResult.setNumMatriculas(trabajadorResult.getNumMatriculas() + 1);
												matricularseResult.setActivo(true);
												entitytransaction.commit();
												id = idMatricula.hashCode();
											}
										}
									}
									else {
										id = -7;
									}
								}
								else {
									id = -6;
								}
	
							}
							else {
								id = -5;
							}
						}
						else {
							entitytransaction.rollback();
							id = -4;
						}
					}
					else {
						entitytransaction.rollback();
						id = -3;
					}
				}
				else {
					id = -2;
				}
				entitymanager.close();
				emfactory.close();
			} catch(PersistenceException ex) {
				id = -100;
			}
		}
		return id;
	}

	public ArrayList<TMatricula> mostrarMatricular() {
		List<Matricularse> listaMatricularse = null;
		ArrayList<TMatricula> listaTMatriculas = new ArrayList<>();
		try {
			EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager entitymanager = emfactory.createEntityManager();
			EntityTransaction entitytransaction = entitymanager.getTransaction();
			if (entitytransaction != null){
				entitytransaction.begin();
				TypedQuery<Matricularse> query = entitymanager.createNamedQuery("Diseno.Negocio.Trabajador.Matricularse.mostrarMatriculas", Matricularse.class);
				listaMatricularse = query.getResultList();
				for(int i = 0; i < listaMatricularse.size(); ++i) {
					listaTMatriculas.add(listaMatricularse.get(i).entityToTransfer());
				}
				if(listaTMatriculas.size() == 0) {
					listaTMatriculas = null;
					entitytransaction.rollback();
				}
				else entitytransaction.commit();
			}
			else {
				listaTMatriculas = null;
			}
			entitymanager.close();
			emfactory.close();
		} catch(PersistenceException ex) {}
		return listaTMatriculas;
	}

	/*
	 * ERROR
	 * -1: Error datos null
	 * -2: Error de transaccion
	 * -3: Curso no existe
	 * -4: Trabajador no existe
	 * -5: Curso no activo
	 * -6: Trabajador no activo
	 * -7: Matricula no encontrada
	 * -8: ya esta desmatriculado
	 */
	/*
	 * No usamos bloqueos, porque modificamos numMatrículas
	 * y el número de plazas en la entidad Curso
	 * y modificamos numMatrículas en la entidad Trabajador
	 */
	public int desmatricularse(TMatricula tTrabajadorCurso) {
		int id = -1;
		if(tTrabajadorCurso != null) {
			try {
				EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("BibliotecaJK");
				EntityManager entitymanager = emfactory.createEntityManager();
				EntityTransaction entitytransaction = entitymanager.getTransaction();
				if(entitytransaction != null) {
					entitytransaction.begin();
					Curso cursoResult = entitymanager.find(Curso.class, tTrabajadorCurso.getIdCurso());
					Trabajador trabajadorResult = entitymanager.find(Trabajador.class, tTrabajadorCurso.getIdTrabajador());
					if(cursoResult != null) {
						if(trabajadorResult != null) {
							if(cursoResult.getActivo()) {
								if(trabajadorResult.getActivo()) {
									IdMatricula idMatricula = new IdMatricula(tTrabajadorCurso.getIdCurso(), tTrabajadorCurso.getIdTrabajador());
									Matricularse matricularseResult = entitymanager.find(Matricularse.class, idMatricula);		
									if(matricularseResult == null) {
										entitytransaction.rollback();
										id = -7;
									} else {
										if(matricularseResult.getActivo()) {
											int plazas = cursoResult.getNumPlazas();
											cursoResult.setNumPlazas(plazas+1);
											int numMatriculados = cursoResult.getNumMatriculados();
											cursoResult.setNumMatriculados(numMatriculados - 1);
											//Se ha modificado la entidad Curso
											trabajadorResult.setNumMatriculas(trabajadorResult.getNumMatriculas() - 1);
											//Se ha modificado la entidad Trabajador
											matricularseResult.setActivo(false);
											entitytransaction.commit();
											id = idMatricula.hashCode();
											
										} else {
											entitytransaction.rollback();
											id = -8;
										}
									}
								} else {
									entitytransaction.rollback();
									id = -6;
								}
	
							} else {
								entitytransaction.rollback();
								id = -5;
							}
						} else {
							entitytransaction.rollback();
							id = -4;
						}
					} else {
						entitytransaction.rollback();
						id = -3;
					}
				}
				else {
					id = -2;
				}
				entitymanager.close();
				emfactory.close();
			} catch(PersistenceException ex) {
				id = -100;
			}
		}
		return id;
	}
}