/**
 * 
 */
package Diseno.Negocio.Trabajador;

import java.io.Serializable;
import javax.persistence.Embeddable;
import java.util.UUID;

@Embeddable
public class IdMatricula implements Serializable {

	private static final long serialVersionUID = 0;

	public IdMatricula() {
	}

	private int idCurso;

	private int idTrabajador;

	public IdMatricula(int idCurso, int idTrabajador) {
		this.idCurso = idCurso;
		this.idTrabajador = idTrabajador;
	}

	public int getIdCurso() {
		return this.idCurso;
	}

	public int getIdTrabajador() {
		return this.idTrabajador;
	}
	
	public void setIdCurso(int idCurso) {
		this.idCurso = idCurso;
	}

	public void setIdTrabajador(int idTrabajador) {
		this.idTrabajador = idTrabajador;
	}

	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof IdMatricula))
			return false;
		IdMatricula pk = (IdMatricula) obj;
		if (!(idCurso == pk.idCurso))
			return false;
		if (!(idTrabajador == pk.idTrabajador))
			return false;
		return true;
	}

	public int hashCode() {
		int n = 0;
		n += this.idCurso;
		n+= this.idTrabajador;
		return n;
	}
}