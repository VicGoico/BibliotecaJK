package Diseno.Negocio.Libro;

import java.util.ArrayList;

public interface SALibro {
	
	public int altaLibro(TLibro tLibro);

	public int bajaLibro(int id);

	public int actualizarLibro(TLibro tLibro);

	public TLibro buscarLibro(int id);

	public ArrayList<TLibro> mostrarLibros();

	public ArrayList<TLibro> buscarPorAutor(String autores);

	public TLibro buscarPorISBN(String ISBN);
}
