package Diseno.Negocio.Libro;

public class TLibroTexto extends TLibro {
	
	private Asignatura asignatura;

	public TLibroTexto(int idLibro, String titulo, String autor, String isbn, int nPaginas, int unidadesTotales,
			int unidadesPrestadas, int idEditorial, boolean activo, Asignatura asignatura) {
		super(idLibro, titulo, autor, isbn, nPaginas, unidadesTotales, unidadesPrestadas, idEditorial, activo);
		this.asignatura = asignatura;
	}
	
	public TLibroTexto(String titulo, String autor, String isbn, int nPaginas, int unidadesTotales,
			int unidadesPrestadas, int idEditorial, boolean activo, Asignatura asignatura) {
		super(titulo, autor, isbn, nPaginas, unidadesTotales, unidadesPrestadas, idEditorial, activo);
		this.asignatura = asignatura;
	}

	public Asignatura getAsignatura() {
		return asignatura;
	}

	public void setAsignatura(Asignatura asignatura) {
		this.asignatura = asignatura;
	}

	@Override
	public String toString() {
		return asignatura.toString();
	}

}