package Diseno.Negocio.Libro;

import java.util.ArrayList;

public enum Genero {
	CIENCIA_FICCION, HISTORICO, ROMANTICO, AVENTURA, TERROR, INFANTIL;
	
	public static ArrayList<String> getGeneros() {
		ArrayList<String> generos = new ArrayList<>();
		for(Genero it : Genero.values()) {
			generos.add(""+it);
		}
		return generos;
	}
	
	public static String transform(Genero gen){
		String result = "";
		switch(gen){
		case CIENCIA_FICCION: result = "CIENCIA_FICCION"; break;
		case HISTORICO: result = "HISTORICO"; break;
		case ROMANTICO: result = "ROMANTICO"; break;
		case AVENTURA: result = "AVENTURA"; break;
		case TERROR: result = "TERROR"; break;
		case INFANTIL: result = "INFANTIL"; break;
		}
		
		return result;
	}
	
	public static Genero transform(String str){
		Genero gen = null;
		switch(str){
		case "CIENCIA_FICCION": gen = CIENCIA_FICCION; break;
		case "HISTORICO": gen = HISTORICO; break;
		case "ROMANTICO": gen = ROMANTICO; break;
		case "AVENTURA": gen = AVENTURA; break;
		case "TERROR": gen = TERROR; break;
		case "INFANTIL": gen = INFANTIL; break;
		}
		return gen;
		
	}
}
