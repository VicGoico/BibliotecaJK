package Diseno.Negocio.Libro;

import java.util.ArrayList;

import Diseno.Integracion.Editorial.DAOEditorial;
import Diseno.Integracion.Factoria.FactoriaIntegracion;
import Diseno.Integracion.Libro.DAOLibro;
import Diseno.Integracion.Transaccion.Transaction;
import Diseno.Integracion.Transaccion.TransactionManager;
import Diseno.Negocio.Editorial.TEditorial;

public class SALibroImp implements SALibro {

	public int altaLibro(TLibro tLibro) {
		// begin-user-code
		// TODO Auto-generated method stub
		int id = -1;
		if(tLibro != null){
			TransactionManager transactionManager = TransactionManager.getInstance();
			Transaction transaction = transactionManager.nuevaTransaccion();
			if(transaction != null){
				transaction.start();
				DAOEditorial daoeditorial = FactoriaIntegracion.getInstance().crearDAOEditorial();
				DAOLibro daolibro = FactoriaIntegracion.getInstance().crearDAOLibro();
				TEditorial tEditorial = daoeditorial.buscar(tLibro.getEditorial());
				if(tEditorial != null){
					if(tEditorial.getActivo()){
						TLibro tlibroisbn = daolibro.buscarPorISBN(tLibro.getISBN());
						if(tlibroisbn != null){ 
							if(!tlibroisbn.getActivo()){ //reactivación
								tLibro.setID(tlibroisbn.getID());
								tLibro.setActivo(true);
								int idResActu = daolibro.actualizarLibro(tLibro);
								if(idResActu > 0){
									TEditorial teditorialresult = daoeditorial.buscar(tlibroisbn.getEditorial());
									if(teditorialresult != null){ //sumamos el libro a la nueva editorial
										int numLibrosActivos = tEditorial.getNumLibrosActivos();
										numLibrosActivos++;
										tEditorial.setNumLibrosActivos(numLibrosActivos);
										daoeditorial.modificar(tEditorial);
										id = idResActu;
										transaction.commit();
									}
									else{ //la editorial actualizada en el libro no existe
										id = -2;
										transaction.rollback();
									}
								}
								else{ //no se puede actualizar
									id = -100;
									transaction.rollback();
								}
							}
							else{ //libro activo
								id = -3;
								transaction.rollback();
							}
						}
						else{ //se puede meter el libro
							//tLibro.setActivo(true);
							int idResult = daolibro.altaLibro(tLibro);
							if(idResult > 0){ //se ha hecho bien el alta
								int numLibrosActivos = tEditorial.getNumLibrosActivos();
								numLibrosActivos++;
								tEditorial.setNumLibrosActivos(numLibrosActivos);
								daoeditorial.modificar(tEditorial);
								transaction.commit();
								id= idResult;
							}
							else{ //no se puede hacer el alta
								id = -100;
								transaction.rollback();
							}
						}
					}
					else{ //editorial no activa
						id = -5;
						transaction.rollback();
					}
				}
				else{ //transfer editorial es null
					id = -2;
					transaction.rollback();
				}
			}
			transactionManager.eliminaTransaccion();
		}
		
		return id;
		// end-user-code
	}

	public int bajaLibro(int id) {
		// begin-user-code
		// TODO Auto-generated method stub
		int idResult = -1;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.nuevaTransaccion();
		if(transaction != null){
			transaction.start();
			DAOLibro daolibro = FactoriaIntegracion.getInstance().crearDAOLibro();
			TLibro tlibro = daolibro.buscarLibro(id);
			if(tlibro != null){
				if(tlibro.getActivo()){
					if(tlibro.getUnidadesPrestadas() == 0){ //si no hay libros prestados, procedemos a la baja
						idResult = daolibro.bajaLibro(id);
						if(idResult > 0){
							DAOEditorial daoeditorial = FactoriaIntegracion.getInstance().crearDAOEditorial();
							TEditorial tEditorial = daoeditorial.buscar(tlibro.getEditorial());
							//Actualizamos el n�mero de libros activos de la editorial
							int numLibrosActivos = tEditorial.getNumLibrosActivos();
							numLibrosActivos--;
							tEditorial.setNumLibrosActivos(numLibrosActivos);
							daoeditorial.modificar(tEditorial);
							transaction.commit();
						}
						else{ //no se ha podido dar de baja el libro
							idResult = -100;
							transaction.rollback();
						}
					}
					else{ //existen libros prestados
						idResult = -3;
						transaction.rollback();
					}
				}
				else{ //libro no activo
					idResult = -4;
					transaction.rollback();
				}
			}
			else{ //no existe el libro
				idResult = -2;
				transaction.rollback();
			}
		}
		transactionManager.eliminaTransaccion();
		
		return idResult;
		// end-user-code
	}

	public int actualizarLibro(TLibro tLibro) {
		// begin-user-code
		// TODO Auto-generated method stub
		int id = -1;
		if(tLibro != null){
			TransactionManager transactionManager = TransactionManager.getInstance();
			Transaction transaction = transactionManager.nuevaTransaccion();
			if(transaction != null){
				transaction.start();
				DAOLibro daolibro = FactoriaIntegracion.getInstance().crearDAOLibro();
				DAOEditorial daoeditorial = FactoriaIntegracion.getInstance().crearDAOEditorial();
				TLibro tlibroresult = daolibro.buscarLibro(tLibro.getID());
				if(tlibroresult != null){
					if(tlibroresult.getActivo()){
						if(tLibro.getUnidadesTotales() >= tlibroresult.getUnidadesPrestadas()){
							if(daolibro.buscarPorISBN(tLibro.getISBN()) == null){
								TEditorial teditorial = daoeditorial.buscar(tLibro.getEditorial());
								if(teditorial != null){
									if(teditorial.getActivo()){
										tLibro.setUnidadesPrestadas(tlibroresult.getUnidadesPrestadas());
										id = daolibro.actualizarLibro(tLibro);
										if(id > 0){
											TEditorial teditorialresult = daoeditorial.buscar(tlibroresult.getEditorial());
											int numLibrosActivos = teditorial.getNumLibrosActivos();
											int numLibrosActivosresult = teditorialresult.getNumLibrosActivos();
											if(tLibro.getEditorial() != tlibroresult.getEditorial()){ //si son distintas, se le resta al teditorialresult y se le suma al teditorial
												numLibrosActivos++;
												teditorial.setNumLibrosActivos(numLibrosActivos);
												numLibrosActivosresult--;
												teditorialresult.setNumLibrosActivos(numLibrosActivosresult);
												daoeditorial.modificar(teditorial);
												daoeditorial.modificar(teditorialresult);
											}
											transaction.commit();
										}
										else{ //no se ha podido actualizar
											id = -100;
											transaction.rollback();
										}
									}
									else{ //editorial no activa
										id = -5;
										transaction.rollback();
									}
								}
								else{ //no existe la editorial introducida
									id = -2;
									transaction.rollback();
								}
							}
							else{ //ya hay un libro con ese isbn, hay que comprobar que sea el mismo libro que estamos modificando
								if(tLibro.getID() == tlibroresult.getID()){
									TEditorial teditorial = daoeditorial.buscar(tLibro.getEditorial());
									if(teditorial != null){
										if(teditorial.getActivo()){
											tLibro.setUnidadesPrestadas(tlibroresult.getUnidadesPrestadas());
											id = daolibro.actualizarLibro(tLibro);
											if(id > 0){
												TEditorial teditorialresult = daoeditorial.buscar(tlibroresult.getEditorial());
												int numLibrosActivos = teditorial.getNumLibrosActivos();
												int numLibrosActivosresult = teditorialresult.getNumLibrosActivos();
												if(tLibro.getEditorial() != tlibroresult.getEditorial()){ //restar al antiguo, sumar al nuevo
													numLibrosActivos++;
													teditorial.setNumLibrosActivos(numLibrosActivos);
													numLibrosActivosresult--;
													teditorialresult.setNumLibrosActivos(numLibrosActivosresult);
													daoeditorial.modificar(teditorial);
													daoeditorial.modificar(teditorialresult);
												}
												transaction.commit();
											}
											else{ //no se ha podido actualizar
												id = -100;
												transaction.rollback();
											}
										}
									}
									else{ //editorial no activa
										id = -5;
										transaction.rollback();
									}
								}
								else{
									id = -1;
									transaction.rollback();
								}
							}
						}
						else{ //si las unidades totales que he puesto son menores que las prestadas en la base de datos
							id = -6;
							transaction.rollback();
						}
					}
					else{ //libro no activo
						id = -3;
						transaction.rollback();
					}
				}
				else{ //el libro no existe
					id = -1;
					transaction.rollback();
				}
			}
			transactionManager.eliminaTransaccion();
		}
		return id;
		// end-user-code
	}

	public TLibro buscarLibro(int id) {
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.nuevaTransaccion();
		TLibro tLibro = null;
		
		if (transaction != null) {
			transaction.start();
			DAOLibro daoLibro = FactoriaIntegracion.getInstance().crearDAOLibro();
			tLibro = daoLibro.buscarLibro(id);
			if (tLibro != null)
				transaction.commit();
			else
				transaction.rollback();
		}
		transactionManager.eliminaTransaccion();
		return tLibro;
	}

	public ArrayList<TLibro> mostrarLibros() {
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.nuevaTransaccion();
		ArrayList<TLibro> libros = null;
		
		if (transaction != null) {
			transaction.start();
			DAOLibro daoLibro = FactoriaIntegracion.getInstance().crearDAOLibro();
			libros = daoLibro.mostrarLibros();
			transaction.commit();
			transactionManager.eliminaTransaccion();
		}
		return libros;
	}

	public ArrayList<TLibro> buscarPorAutor(String autores) {
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.nuevaTransaccion();
		ArrayList<TLibro> libros = null;
		
		if (transaction != null) {
			transaction.start();
			DAOLibro daoLibro = FactoriaIntegracion.getInstance().crearDAOLibro();
			libros = daoLibro.buscarPorAutor(autores);
			transaction.commit();
			transactionManager.eliminaTransaccion();
		}
		return libros;
	}

	public TLibro buscarPorISBN(String ISBN) {
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.nuevaTransaccion();
		TLibro tLibro = null;
		
		if (transaction != null) {
			transaction.start();
			DAOLibro daoLibro = FactoriaIntegracion.getInstance().crearDAOLibro();
			tLibro = daoLibro.buscarPorISBN(ISBN);
			if (tLibro != null)
				transaction.commit();
			else
				transaction.rollback();
		}
		transactionManager.eliminaTransaccion();
		return tLibro;
	}
}