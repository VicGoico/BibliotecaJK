package Diseno.Negocio.Libro;

import java.util.ArrayList;

public enum Asignatura {
	MDL, MMI, GE, FC, FP, FEE;
	
	public static ArrayList<String> getAsignatura() {
		ArrayList<String> asignaturas = new ArrayList<>();
		for(Asignatura it : Asignatura.values()) {
			asignaturas.add(""+it);
		}
		return asignaturas;
	}
	
	public static String transform(Asignatura asig){
		String result = "";
		switch(asig){
		case MDL: result = "MDL"; break;
		case MMI: result = "MMI"; break;
		case GE: result = "GE"; break;
		case FC: result = "FC"; break;
		case FP: result = "FP"; break;
		case FEE: result = "FEE"; break;
		}
		
		return result;
	}
	
	public static Asignatura transform(String str){
		Asignatura asig = null;
		switch(str){
		case "MDL": asig = MDL; break;
		case "MMI": asig = MMI; break;
		case "GE": asig = GE; break;
		case "FC": asig = FC; break;
		case "FP": asig = FP; break;
		case "FEE": asig = FEE; break;
		}
		
		return asig;
	}
}
