package Diseno.Negocio.Libro;

public class TLibroLiteratura extends TLibro {
	
	private Genero genero;
	
	public TLibroLiteratura(int idLibro, String titulo, String autor, String isbn, int nPaginas, int unidadesTotales,
			int unidadesPrestadas, int idEditorial, boolean activo, Genero genero) {
		super(idLibro, titulo, autor, isbn, nPaginas, unidadesTotales, unidadesPrestadas, idEditorial, activo);
		this.genero = genero;
	}
	
	public TLibroLiteratura(String titulo, String autor, String isbn, int nPaginas, int unidadesTotales,
			int unidadesPrestadas, int idEditorial, boolean activo, Genero genero) {
		super(titulo, autor, isbn, nPaginas, unidadesTotales, unidadesPrestadas, idEditorial, activo);
		this.genero = genero;
	}

	public Genero getGenero() {
		return genero;
	}

	public void setGenero(Genero genero) {
		this.genero = genero;
	}

	@Override
	public String toString() {
		return genero.toString();
	}
}