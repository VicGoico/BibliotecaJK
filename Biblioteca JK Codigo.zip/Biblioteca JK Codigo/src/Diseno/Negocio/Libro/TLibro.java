package Diseno.Negocio.Libro;

public class TLibro {
	
	private int idLibro;
	
	private String titulo;
	
	private String autor;
	
	private String ISBN;
	
	private int nPaginas;
	
	private int unidadesTotales;
	
	private int unidadesPrestadas;
	
	private boolean activo;
	
	private int idEditorial;

	public int getID() {
		return idLibro;
	}

	public String getTitulo() {
		return titulo;
	}

	public String getAutor() {
		return autor;
	}

	public String getISBN() {
		return ISBN;
	}
	
	public int getPaginas() {
		return nPaginas;
	}

	public int getUnidadesTotales() {
		return unidadesTotales;
	}

	public int getUnidadesPrestadas() {
		return unidadesPrestadas;
	}

	public boolean getActivo() {
		return activo;
	}

	public int getEditorial() {
		return idEditorial;
	}

	public void setID(int ID) {
		this.idLibro = ID;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public void setISBN(String ISBN) {
		this.ISBN = ISBN;
	}

	public void setPaginas(int numPaginas) {
		this.nPaginas = numPaginas;
	}

	public void setUnidadesTotales(int numUnidadesTotales) {
		this.unidadesTotales = numUnidadesTotales;
	}

	public void setUnidadesPrestadas(int numUnidadesPrestadas) {
		this.unidadesPrestadas = numUnidadesPrestadas;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}

	public void setEditorial(int IDEditorial) {
		this.idEditorial = IDEditorial;
	}

	public TLibro(String titulo, String autor, String isbn, int nPaginas, int unidadesTotales, int unidadesPrestadas,
			int idEditorial,boolean activo) {
		this.titulo = titulo;
		this.autor = autor;
		this.ISBN = isbn;
		this.nPaginas = nPaginas;
		this.unidadesTotales = unidadesTotales;
		this.unidadesPrestadas = unidadesPrestadas;
		this.activo = activo;
		this.idEditorial = idEditorial;
	}

	public TLibro(int idLibro, String titulo, String autor, String isbn, int nPaginas, int unidadesTotales,
			int unidadesPrestadas, int idEditorial, boolean activo) {
		this.idLibro = idLibro;
		this.titulo = titulo;
		this.autor = autor;
		this.ISBN = isbn;
		this.nPaginas = nPaginas;
		this.unidadesTotales = unidadesTotales;
		this.unidadesPrestadas = unidadesPrestadas;
		this.activo = activo;
		this.idEditorial = idEditorial;
	}
}