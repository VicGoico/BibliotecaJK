package Diseno.Negocio.Centro;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import java.io.Serializable;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.NamedQueries;
import java.util.ArrayList;
import Diseno.Negocio.Curso.Curso;
import javax.persistence.OneToMany;
import javax.persistence.Version;

@Entity
@NamedQueries({
		@NamedQuery(name = "Diseno.Negocio.Centro.Centro.findByidCentro", query = "select obj from Centro obj where :idCentro = obj.idCentro "),
		@NamedQuery(name = "Diseno.Negocio.Centro.Centro.findByversion", query = "select obj from Centro obj where :version = obj.version "),
		@NamedQuery(name = "Diseno.Negocio.Centro.Centro.findBynombre", query = "select obj from Centro obj where :nombre = obj.nombre "),
		@NamedQuery(name = "Diseno.Negocio.Centro.Centro.findBydireccion", query = "select obj from Centro obj where :direccion = obj.direccion "),
		@NamedQuery(name = "Diseno.Negocio.Centro.Centro.findBynumCursosActivos", query = "select obj from Centro obj where :numCursosActivos = obj.numCursosActivos "),
		@NamedQuery(name = "Diseno.Negocio.Centro.Centro.findByactivo", query = "select obj from Centro obj where :activo = obj.activo "),
		@NamedQuery(name = "Diseno.Negocio.Centro.Centro.findAll", query= "select obj from Centro obj where obj.activo = 1"),
		@NamedQuery(name = "Diseno.Negocio.Centro.Centro.findCursosDeCentro", query="select obj from Curso obj where :centro = obj.centro"),
		@NamedQuery(name = "Diseno.Negocio.Centro.Centro.findBycurso", query = "select obj from Centro obj where :curso MEMBER OF obj.curso ")})
public class Centro implements Serializable {
	private static final long serialVersionUID = 0;
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idCentro;
	@Version
	private int version;
	private String nombre;
	private String direccion;
	private int numCursosActivos;
	private boolean activo;
	
	@OneToMany(mappedBy = "centro")
	private ArrayList<Curso> curso;

	
	public Centro() {/*Se queda vacia esta constructora*/}

	public Centro(TCentro tCentro) {
		this.nombre = tCentro.getNombre();
		this.direccion = tCentro.getDireccion();
		this.numCursosActivos = tCentro.getNumCursosActivos();
		this.activo = tCentro.getActivo();
		this.curso = new ArrayList<Curso>();
	}

	public int getIdCentro() {
		return this.idCentro;
	}

	public String getNombre() {
		return this.nombre;
	}

	public String getDireccion() {
		return this.direccion;
	}

	public int getNumCursosActivos() {
		return this.numCursosActivos;
	}

	public boolean getActivo() {
		return this.activo;
	}

	public void setIdCentro(int idCentro) {
		this.idCentro = idCentro;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public void setNumCursosActivos(int numCursosActivos) {
		this.numCursosActivos = numCursosActivos;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}

	public TCentro entityToTransfer() {
		return new TCentro(this.idCentro, this.nombre, this.direccion, this.numCursosActivos, this.activo);
	}

	public ArrayList<Curso> getCurso() {
		return curso;
	}

	public void setCurso(ArrayList<Curso> curso) {
		this.curso = curso;
	}
}