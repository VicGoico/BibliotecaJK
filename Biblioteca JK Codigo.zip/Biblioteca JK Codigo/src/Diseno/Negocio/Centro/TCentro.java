
package Diseno.Negocio.Centro;

public class TCentro {

	private int idCentro;
	private String nombre;
	private String direccion;
	private int numCursosActivos;
	private boolean activo;

	public TCentro(int idCentro, String nombre, String direccion, int numCursosActivos, boolean activo) {
		this.idCentro = idCentro;
		this.nombre = nombre;
		this.direccion = direccion;
		this.numCursosActivos = numCursosActivos;
		this.activo = activo;
	}

	public TCentro(String nombre, String direccion, int numCursosActivos, boolean activo) {
		this.nombre = nombre;
		this.direccion = direccion;
		this.numCursosActivos = numCursosActivos;
		this.activo = activo;
	}

	public int getIdCentro() {
		return this.idCentro;
	}

	public String getNombre() {
		return this.nombre;
	}

	public String getDireccion() {
		return this.direccion;
	}
	
	public boolean getActivo() {
		return this.activo;
	}
	
	public int getNumCursosActivos() {
		return this.numCursosActivos;
	}
	
	public void setIdCentro(int idCentro) {
		this.idCentro = idCentro;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	
	public void setNumCursosActivos(int numCursosActivos) {
		this.numCursosActivos = numCursosActivos;
	}

}