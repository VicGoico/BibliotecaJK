package Diseno.Negocio.Centro;

import java.util.ArrayList;

public interface SACentro {
	public int altaCentro(TCentro tCentro);
	public int bajaCentro(int idCentro);
	public int actualizarCentro(TCentro tCentro);
	public TCentro buscarCentro(int idCentro);
	public ArrayList<TCentro> mostrarCentros();
	public int calcularCosteCursos(int idCentro);
}