package Diseno.Negocio.Centro;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import Diseno.Negocio.Curso.Curso;
import Diseno.Negocio.Curso.CursoADistancia;
import Diseno.Negocio.Curso.CursoPresencial;

public class SACentroImp implements SACentro {

	public int altaCentro(TCentro tCentro) {
		/*
		 * Glosario de errores
		 * 
		 * -1: fallo transaccion
		 * -2: existe el centro y no esta dado de baja
		 * -100: fallo en la BBDD
		 * 
		 */
		int id;
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager em = emf.createEntityManager();
			// El tipo es EntityTransaction
			if (em.getTransaction() != null) {
				em.getTransaction().begin();
				// Busco si el nombre ya existe en la BBDD
				//Centro tLeido = em.find(Centro.class, tCentro.getNombre());
				// Solo funciona si es lo que le pasamos es un atributo clave sino puff
				TypedQuery<Centro> query = em.createNamedQuery("Diseno.Negocio.Centro.Centro.findBynombre", Centro.class).setParameter("nombre", tCentro.getNombre());
				List<Centro> lista = query.getResultList();
				// Son iguales, ya existe el centro
				if (!lista.isEmpty()) {
					Centro centroLeido = lista.get(0);
					// Esta activo
					if (centroLeido.getActivo()) {
						id = -2;
						em.getTransaction().rollback();
					}
					// Reactivamos
					else {
						centroLeido.setActivo(true);
						centroLeido.setDireccion(tCentro.getDireccion());
						em.getTransaction().commit();
						id = centroLeido.getIdCentro();
					}
				}
				// No existe
				else {
					tCentro.setActivo(true);
					Centro cen = new Centro(tCentro);
					em.persist(cen);
					em.getTransaction().commit();
					id = cen.getIdCentro();
				}
			}
			else id = -1;
			em.close();
			emf.close();
		} catch (PersistenceException e) {
			id = -100;
		}
		return id;
	}

	public int bajaCentro(int idCentro) {
		/*
		 * Glosario de errores
		 * 
		 * -1: fallo al coger la transaccion 
		 * -2: no existe el centro con ese ID
		 * -3: existe y ya esta dado de baja
		 * -4: tiene cursos activos
		 * -100: fallo en la BBDD
		 * 
		 */
		int id;
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager em = emf.createEntityManager();
			// El tipo es EntityTransaction
			if (em.getTransaction() != null) {
				em.getTransaction().begin();
				Centro centroLeido = em.find(Centro.class, idCentro);
				// Existe
				if (centroLeido != null) {
					// Miro si ya esta dado de baja
					if(centroLeido.getActivo()){
						if(centroLeido.getNumCursosActivos() == 0){
							centroLeido.setActivo(false);
							id = idCentro;
							em.getTransaction().commit();
						}
						else {
							id = -4;
							em.getTransaction().rollback();
						}
					}
					// Ya esta dado de baja
					else{
						id = -3;
						em.getTransaction().rollback();
					}
					
				}
				// No existe
				else {
					id = -2;
					em.getTransaction().rollback();
				}
			}
			else id = -1;
			em.close();
			emf.close();
		} catch (PersistenceException e) {
			id = -100;
		}
		return id;
	}

	public int actualizarCentro(TCentro tCentro) {
		/*
		 * Glosario de errores
		 * 
		 * -1: fallo al coger la transaccion 
		 * -2: no existe el ID de centro en la BBDD
		 * -3: el id es valido, pero el Centro no esta activo 
		 * -4: el id es valido, pero el nuevo nombre de Centro ya existe
		 *  -100: fallo en la BBDD
		 * 
		 */
		int id;
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager em = emf.createEntityManager();
			// El tipo es EntityTransaction
			if (em.getTransaction() != null) {
				em.getTransaction().begin();
				// Miro si existe el ID
				Centro centroLeido = em.find(Centro.class, tCentro.getIdCentro());
				// Existe
				if (centroLeido != null) {
					if (centroLeido.getActivo()) {
						// Miro que el nuevo id no exista ya
						TypedQuery<Centro> lista = em.createNamedQuery("Diseno.Negocio.Centro.Centro.findBynombre", Centro.class).setParameter("nombre", tCentro.getNombre());
						
						// No existe o existe pero son nombres iguales con ids iguales, hago la actualizacion
						if (lista.getResultList().isEmpty() || (lista.getResultList().get(0).getIdCentro() == tCentro.getIdCentro())) { 
							centroLeido.setNombre(tCentro.getNombre());
							centroLeido.setDireccion(tCentro.getDireccion());
							
							id = tCentro.getIdCentro();
							em.getTransaction().commit();
						}
						// Existe
						else {
							id = -4;
							em.getTransaction().rollback();
						}
					} else {
						id = -3;
						em.getTransaction().rollback();
					}
				}
				// No existe
				else {
					id = -2;
					em.getTransaction().rollback();
				}
			}
			else id = -1;
			em.close();
			emf.close();
		} catch (PersistenceException e) {
			id = -100;
		}
		return id;
	}

	public TCentro buscarCentro(int idCentro) {
		/*
		 * Glosario de errores
		 * 
		 * null: en caso de no encontrar el centro o si no se puede hacer la conversion
		 * a TCentro
		 * 
		 */
		Centro centro = null;
		TCentro tCentro = null;
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager em = emf.createEntityManager();
			if (em.getTransaction() != null) {
				em.getTransaction().begin();
				centro = em.find(Centro.class, idCentro);
				// Si el centro no es null, se convierte a un TCentro
				if (centro != null) {
					tCentro = centro.entityToTransfer();
					em.getTransaction().commit();
				} else // Si es null, se hace rollback
				{
					tCentro = null;
					em.getTransaction().rollback();
				}
			}
			em.close();
			emf.close();
		} catch (PersistenceException e) {
			tCentro = null;
		}

		return tCentro;
	}

	public ArrayList<TCentro> mostrarCentros() {
		/*
		 * Glosario de errores
		 * 
		 * null: en caso de fallo de conexion a BBDD, o que no existan centros en la
		 * BBDD
		 */
		ArrayList<TCentro> listaCentros = new ArrayList<TCentro>();
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager em = emf.createEntityManager();
			if (em.getTransaction() != null) {
				em.getTransaction().begin();
				TypedQuery query = em.createNamedQuery("Diseno.Negocio.Centro.Centro.findAll", Centro.class);
				List<Centro> lista = query.getResultList();
				// Si la lista esta vacia, se hace rollback
				if (lista.isEmpty()) {
					listaCentros = null;
					em.getTransaction().rollback();
				} 
				else {
					// Convierto la lista a 
					for(Centro cen : lista){
						TCentro tCentro = cen.entityToTransfer();
						listaCentros.add(tCentro);
					}
					em.getTransaction().commit();
				}
			}
			em.close();
			emf.close();
		} catch (PersistenceException e) {
			listaCentros = null;
		}

		return listaCentros;
	}

	public int calcularCosteCursos(int idCentro) {
		/*
		 * Glosario de errores
		 * 
		 * -1: fallo al coger la transaccion
		 * -2: no existe el ID de centro en la BBDD
		 * -3: el id es valido, pero el Centro no esta activo 
		 * -4: no hay cursos asociados a ese centro 
		 * -100: fallo en la BBDD
		 * 
		 */
		int id = 0;
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager em = emf.createEntityManager();
			// El tipo es EntityTransaction
			if (em.getTransaction() != null) {
				em.getTransaction().begin();
				Centro centroLeido = em.find(Centro.class, idCentro);
				if (centroLeido != null) {
					if (centroLeido.getActivo()) {
						em.lock(centroLeido, LockModeType.OPTIMISTIC_FORCE_INCREMENT);
						
						// Miro que la lista no esta vacia
						if (centroLeido.getNumCursosActivos()!= 0) {
							//TypedQuery<Curso> lista = em.createNamedQuery("Diseno.Negocio.Curso.Curso.findBycentro", Curso.class).setParameter("centro", centroLeido);
							//TypedQuery<Curso> lista = (TypedQuery<Curso>) centroLeido.getCurso();
							//List<Curso> lista2 = lista.getResultList();
							ArrayList<Curso> lista = centroLeido.getCurso();
							
							// Recorro el vector
							for (Curso cur : lista) {
								id += cur.calcularPrecioCurso();
							}
							// Coste medio
							id = (id/lista.size());
							em.getTransaction().commit();
						} 
						else {
							id = -4;
							em.getTransaction().rollback();
						}

					} else {
						id = -3;
						em.getTransaction().rollback();
					}
				} else {
					id = -2;
					em.getTransaction().rollback();
				}
			}
			em.close();
			emf.close();
		} catch (PersistenceException e) {
			id = -100;
		}
		return id;
	}

}