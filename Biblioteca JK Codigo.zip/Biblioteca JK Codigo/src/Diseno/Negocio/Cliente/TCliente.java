/**
 * 
 */
package Diseno.Negocio.Cliente;


public class TCliente {

	private int idCliente;

	private String nombre;

	private String apellidos;

	private String DNI;

	private int telefono;

	private String carnetBiblioteca;

	private String email;

	private boolean activo;


	public TCliente(int id, String nombre, String apellidos, String DNI, String carnet, String email, int telefono,
			boolean activo) {
		this.idCliente = id;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.DNI = DNI;
		this.carnetBiblioteca = carnet;
		this.email = email;
		this.telefono = telefono;
		this.activo = activo;
	}
	
	public TCliente(String nombre, String apellidos, String DNI, String carnet, String email, int telefono,
			boolean activo) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.DNI = DNI;
		this.carnetBiblioteca = carnet;
		this.email = email;
		this.telefono = telefono;
		this.activo = activo;
	}


	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getDNI() {
		return DNI;
	}

	public void setDNI(String dNI) {
		DNI = dNI;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	public String getCarnet() {
		return carnetBiblioteca;
	}

	public void setCarnet(String carnet) {
		this.carnetBiblioteca = carnet;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean getActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}

	
}