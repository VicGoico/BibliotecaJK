/**
 * 
 */
package Diseno.Negocio.Cliente;

import Diseno.Negocio.Libro.Genero;

public class TGeneroPaginas {

	private Genero genero;

	private int nPag;
	
	public TGeneroPaginas(Genero genero, int nPag) {
		this.genero = genero;
		this.nPag = nPag;
	}

	public Genero getGenero() {
		return genero;
	}

	public void setGenero(Genero genero) {
		this.genero = genero;
	}

	public int getnPag() {
		return nPag;
	}

	public void setnPag(int nPag) {
		this.nPag = nPag;
	}
	
}