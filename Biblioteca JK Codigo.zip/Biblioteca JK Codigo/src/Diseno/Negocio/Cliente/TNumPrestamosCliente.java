package Diseno.Negocio.Cliente;

public class TNumPrestamosCliente {
	private int idCliente;
	private int nPrestamos;
	
	public TNumPrestamosCliente(int idCliente, int nPrestamos) {
		this.idCliente = idCliente;
		this.nPrestamos = nPrestamos;
	}
	
	public int getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public int getnPrestamos() {
		return nPrestamos;
	}
	public void setnPrestamos(int nPrestamos) {
		this.nPrestamos = nPrestamos;
	}
	
}	
