/**
 * 
 */
package Diseno.Negocio.Cliente;

import java.util.ArrayList;


public interface SACliente {

	public int altaCliente(TCliente tCliente);

	public int bajaCliente(int id);

	public int actualizarCliente(TCliente tCliente);

	public TCliente buscarCliente(int id);

	public ArrayList<TPrestamo> mostrarPrestamos();

	public ArrayList<TCliente> mostrarClientes();

	public ArrayList<String> realizarPrestamo(ArrayList<TPrestamo> listaTPrestamo);

	public boolean devolverPrestamo(TPrestamo tPrestamo);

	public ArrayList<TCliente> clientesAlMenosNLibrosDeUnaEditorial(TLibroEditorial tLibroEditorial);

	public ArrayList<TCliente> clientesConLibrosDeUnGeneroYNPaginas(TGeneroPaginas tGeneroPaginas);
}