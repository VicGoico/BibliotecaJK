/**
 * 
 */
package Diseno.Negocio.Cliente;

import java.util.Date;


public class TPrestamo {

	private int idCliente;

	private int idLibro;

	private Date fechaI;

	private Date fechaF;

	private boolean devuelto;


	public TPrestamo(int idCliente, int idLibro, Date fechaI, Date fechaF, boolean devuelto) {
		this.idCliente = idCliente;
		this.idLibro = idLibro;
		this.fechaI = fechaI;
		this.fechaF = fechaF;
		this.devuelto = devuelto;
	}
	
	public TPrestamo(int idCliente, int idLibro, Date fechaI) {
		this.idCliente = idCliente;
		this.idLibro = idLibro;
		this.fechaI = fechaI;
	}

	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public int getIdLibro() {
		return idLibro;
	}

	public void setIdLibro(int idLibro) {
		this.idLibro = idLibro;
	}

	public Date getFechaI() {
		return fechaI;
	}

	public void setFechaI(Date fechaI) {
		this.fechaI = fechaI;
	}

	public Date getFechaF() {
		return fechaF;
	}

	public void setFechaF(Date fechaF) {
		this.fechaF = fechaF;
	}

	public boolean getDevuelto() {
		return devuelto;
	}

	public void setDevuelto(boolean devuelto) {
		this.devuelto = devuelto;
	}


}