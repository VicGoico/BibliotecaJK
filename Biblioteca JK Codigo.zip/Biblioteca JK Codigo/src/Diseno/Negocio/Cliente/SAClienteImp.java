/**
 * 
 */
package Diseno.Negocio.Cliente;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import Diseno.Integracion.Cliente.DAOCliente;
import Diseno.Integracion.Editorial.DAOEditorial;
import Diseno.Integracion.Factoria.FactoriaIntegracion;
import Diseno.Integracion.Libro.DAOLibro;
import Diseno.Integracion.Querys.FactoriaQuery;
import Diseno.Integracion.Transaccion.Transaction;
import Diseno.Integracion.Transaccion.TransactionManager;
import Diseno.Negocio.Editorial.TEditorial;
import Diseno.Negocio.Libro.TLibro;


public class SAClienteImp implements SACliente {
	
	/*
	 * Error:
	 * -1: No se cumple la validez sintactica.
	 * -5: El cliente ya activo y no se puede reactivar.
	 * -100: Error en la gestión de la BDD.
	 */
	public int altaCliente(TCliente tCliente) {
		int id = -1;
		if (tCliente != null) {
			TransactionManager transactionManager = TransactionManager.getInstance();
			Transaction transaction = transactionManager.nuevaTransaccion();
			if (transaction != null) {
				transaction.start();
				DAOCliente daoCliente = FactoriaIntegracion.getInstance().crearDAOCliente();
				String DNI = tCliente.getDNI();
				TCliente tClienteResult = daoCliente.buscarPorDNI(DNI);
				if (tClienteResult== null) {
					tCliente.setActivo(true);
					id = daoCliente.altaCliente(tCliente);
					if(id == -100)
						transaction.rollback();
					else
						transaction.commit();
				}
				else {
					if (!tClienteResult.getActivo()) {
						int idResult = tCliente.getIdCliente();
						tCliente.setIdCliente(idResult);
						tCliente.setActivo(true);
						id = daoCliente.actualizarCliente(tCliente);
						if(id == -100) transaction.rollback();
						else transaction.commit();
					}
					else {
						id = -5;
						transaction.rollback();
					}
				}
			}
			transactionManager.eliminaTransaccion();
		}
		return id;
	}
	/*
	 * Error:
	 * -1: No se cumple la validez sintactica.
	 * -2: El cliente no existe y no se le puede dar de baja.
	 * -3: El cliente no esta activo por lo tanto se puede dar de baja
	 * -4: El cliente tiene préstamos sin devolver
	 * -100: Error en la gestión de la BDD.
	 */
	public int bajaCliente(int id) {
		int idRetorno = -1;
		DAOCliente daoCliente = FactoriaIntegracion.getInstance().crearDAOCliente();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.nuevaTransaccion();
		if (transaction != null) {
				transaction.start();
				TCliente tClienteResult = daoCliente.buscarCliente(id);
				if(tClienteResult != null) {
					boolean pendientes = daoCliente.buscarPrestamosActivosCliente(id);
					if(!pendientes) {
						if (tClienteResult.getActivo()) {
							idRetorno = daoCliente.bajaCliente(id);
							if(id == -100)
								transaction.rollback();
							else
								transaction.commit();
						}
						else {
							idRetorno = -3;
							transaction.rollback();
						}
					}
					else{ 
						idRetorno = -4;
						transaction.rollback();
					}
				}
				else {
					idRetorno = -2;
					transaction.rollback();
				}
			}
			
			transactionManager.eliminaTransaccion();
			return idRetorno;
		}
	/*
	 * Error:
	 * -1: Error en la transaccion
	 * -2: No existe el id
	 * -3: Transaccion incorrecta
	 * -4: El cliente buscado en a BDD no estaba activo.
	 * -6: Actualizado DNI
	 * -100: Error en la gestión de la BDD. 
	 */
	@SuppressWarnings("null")
	public int actualizarCliente(TCliente tCliente) {
		int id = -1;
		if (tCliente != null) {
				TransactionManager transactionManager = TransactionManager.getInstance();
				Transaction transaction = transactionManager.nuevaTransaccion();
				if (transaction != null) {
					transaction.start();
					DAOCliente daoCliente = FactoriaIntegracion.getInstance().crearDAOCliente();
					int idCliente = tCliente.getIdCliente();
					TCliente tClienteResult = daoCliente.buscarCliente(idCliente);
					if (tClienteResult != null) {
						String DNI = tCliente.getDNI();
						TCliente tClienteResult2 = daoCliente.buscarPorDNI(DNI);
						if (tClienteResult2 != null){
							if (tClienteResult.getIdCliente() == tClienteResult2.getIdCliente()){
								boolean resultActivo = tClienteResult2.getActivo();
								if(resultActivo){
									id = daoCliente.actualizarCliente(tCliente);
									if(id == -100)
										transaction.rollback();
									else
										transaction.commit();
								}
								else { //no activo
									id = -4;
									transaction.rollback();
								}
							}
							else{ //no coinciden los id
								id = -6;
								daoCliente.actualizarCliente(tClienteResult2);
							}
						}
						else{ // no existe DNI
							boolean resultActivo = tClienteResult.getActivo();
							if(resultActivo){
								id = daoCliente.actualizarCliente(tCliente);
								if(id == -100)
									transaction.rollback();
								else
									transaction.commit();
							}
						}
					}
					else{ //  no existe id
						id = -2;
						transaction.rollback();
					}
				}
				else { // transacion incorrecta
					id = -3;
					transaction.rollback();
				}
			transactionManager.eliminaTransaccion();
		}	
		return id;
	}


	public TCliente buscarCliente(int id) {
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.nuevaTransaccion();
		TCliente tCliente = null;
		if (transaction != null) {
			transaction.start();
			DAOCliente daoCliente = FactoriaIntegracion.getInstance().crearDAOCliente();
			tCliente = daoCliente.buscarCliente(id);
			if (tCliente != null)
				transaction.commit();
			else
				transaction.rollback();
		}
		transactionManager.eliminaTransaccion();
		return tCliente;
	}
	
	public ArrayList<TPrestamo> mostrarPrestamos() {
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.nuevaTransaccion();
		ArrayList<TPrestamo> prestamos = null;
		if (transaction != null) {
			transaction.start();
			DAOCliente daoCliente = FactoriaIntegracion.getInstance().crearDAOCliente();
			prestamos = daoCliente.mostrarPrestamos();
			transaction.commit();
		}
		transactionManager.eliminaTransaccion();
		return prestamos;
	}


	public ArrayList<TCliente> mostrarClientes() {
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.nuevaTransaccion();
		ArrayList<TCliente> clientes = null;
		if (transaction != null) {
			transaction.start();
			DAOCliente daoCliente = FactoriaIntegracion.getInstance().crearDAOCliente();
			clientes = daoCliente.mostrarClientes();
			transaction.commit();
		}
		transactionManager.eliminaTransaccion();
		return clientes;
	}


	public ArrayList<String> realizarPrestamo(ArrayList<TPrestamo> listaTPrestamo) {
		ArrayList<String> avisos = new ArrayList<>();
		boolean correcto = true;
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.nuevaTransaccion();
		if (transaction != null) {
			transaction.start();
			TPrestamo tPrestamo = (TPrestamo) listaTPrestamo.get(0);
			DAOCliente daoCliente = FactoriaIntegracion.getInstance().crearDAOCliente();
			int idCliente = tPrestamo.getIdCliente();
			TCliente tCliente = daoCliente.buscarCliente(idCliente);
			if(tCliente != null) {
				if(tCliente.getActivo()) {
					boolean pendientes = daoCliente.buscarPrestamosActivosCliente(idCliente);
					if(pendientes){
						avisos.add("El cliente de los prestamos tiene libros pendientes");
						correcto = false;
					}
					else {
						DAOLibro daoLibro = FactoriaIntegracion.getInstance().crearDAOLibro();
						for (int i = 0; i < listaTPrestamo.size(); i++) {
							tPrestamo = (TPrestamo) listaTPrestamo.get(i);
							int idLibro = tPrestamo.getIdLibro();
							Date fechaI = tPrestamo.getFechaI();
							Date fechaF = tPrestamo.getFechaF();
							SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
							String fechaIni = sdf.format(fechaI);
							String fechaFin = sdf.format(fechaF);
							TLibro tLibro = daoLibro.buscarLibro(idLibro);
							if(tLibro != null) {
								if(tLibro.getActivo()) {
									if(tLibro.getUnidadesPrestadas() + 1 <= tLibro.getUnidadesTotales()) {
										if(fechaI.before(fechaF)) {
											TPrestamo tPrestamoResult = daoCliente.buscarPrestamo(idCliente, idLibro, fechaI);
											if(tPrestamoResult == null) {
												boolean ok = daoCliente.realizarPrestamo(tPrestamo);
												if (!ok) {
													avisos.add("No se ha podido dar de alta el prestamo"+ (i +1) +":\n "
															+ "Datos: IdLibro= " +idLibro+ " IdCliente=" + idCliente
																	+ " FechaI= " + fechaIni + " FechaF= " + fechaFin);
													correcto = false;
												}
												else {
													avisos.add("Se ha dado de alta el prestamo"+ (i +1) +":\n "
															+ "Datos: IdLibro= " +idLibro+ " IdCliente=" + idCliente
																	+ " FechaI= " + fechaIni + " FechaF= " + fechaFin);
													tLibro.setUnidadesPrestadas(tLibro.getUnidadesPrestadas() + 1);
													int res = daoLibro.actualizarLibro(tLibro);
													if(res == -100) avisos.add("¡¡¡ERROR!!! No se ha podido cambiar el "
															+ "número de unidades prestadas del libro con id: " + idLibro
															+ " para el prestamo " + (i+1));
												}
											}
											else {
												avisos.add("El prestamo "+ (i +1) + " ya existe"+":\n "
														+ "Datos: IdLibro= " +idLibro+ " IdCliente=" + idCliente
														+ " FechaI= " + fechaIni + " FechaF= " + fechaFin);
												correcto = false;
											}
										}
										else {
											avisos.add("El prestamo "+ (i +1) + " tiene fechas no validas"+":\n "
													+ "Datos: IdLibro= " +idLibro+ " IdCliente=" + idCliente
													+ " FechaI= " + fechaIni + " FechaF= " + fechaFin);
											correcto = false;
										}
									}
									else {
										avisos.add("El libro del prestamo "+ (i +1) + " no tiene unidades disponibles"+":\n "
												+ "Datos: IdLibro= " +idLibro+ " IdCliente=" + idCliente
												+ " FechaI= " + fechaIni + " FechaF= " + fechaFin);
										correcto = false;
									}
								}
								else {
									avisos.add("El prestamo "+ (i +1) + " tiene un libro desactivado"+":\n "
											+ "Datos: IdLibro= " +idLibro+ " IdCliente=" + idCliente
											+ " FechaI= " + fechaIni + " FechaF= " + fechaFin);
									correcto = false;
								}
							}
							else {
								avisos.add("El prestamo "+ (i +1) + " tiene un libro no valido"+":\n "
										+ "Datos: IdLibro= " +idLibro+ " IdCliente=" + idCliente
										+ " FechaI= " + fechaIni + " FechaF= " + fechaFin);
								correcto = false;
							}							
						}
					}
				}
				else {
					avisos.add("El cliente de los prestamos no está activo");
					correcto = false;
				}
			}
			else {
				avisos.add("Los prestamos tienen un cliente no valido");
				correcto = false;	
			}
			if(correcto) transaction.commit();
			else transaction.rollback();
			transactionManager.eliminaTransaccion();
		}
		if(avisos.isEmpty()) return null;
		return avisos;
	}

	/** 
	* (non-Javadoc)
	* @see SACliente#devolverPrestamo(TPrestamo tPrestamo)
	* @generated "UML a Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public boolean devolverPrestamo(TPrestamo tPrestamo) {
		boolean ok = true;
		DAOCliente daoCliente = FactoriaIntegracion.getInstance().crearDAOCliente();
		TransactionManager transactionManager = TransactionManager.getInstance();
		Transaction transaction = transactionManager.nuevaTransaccion();
		if (transaction != null) {
			transaction.start();
			int idCliente = tPrestamo.getIdCliente();
			TCliente tClienteResult = daoCliente.buscarCliente(idCliente);
			int idLibro = tPrestamo.getIdLibro();
			DAOLibro daoLibro = FactoriaIntegracion.getInstance().crearDAOLibro();
			TLibro tLibroResult = daoLibro.buscarLibro(idLibro);
			if (tClienteResult != null && tLibroResult != null) {
				Date fechaI = tPrestamo.getFechaI();
				TPrestamo tPrestamoResult = daoCliente.buscarPrestamo(idCliente, idLibro, fechaI);
				if (tPrestamoResult != null) {
					boolean devuelto = tPrestamo.getDevuelto();
					if (!devuelto) {
						boolean estado = daoCliente.devolverPrestamo(tPrestamo);
						if (!estado) {
							ok = false;
							transaction.rollback();
						}
						else{
							tLibroResult.setUnidadesPrestadas(tLibroResult.getUnidadesPrestadas() - 1);
							daoLibro.actualizarLibro(tLibroResult);
							transaction.commit();
						}
					}
					else {
						ok = false;
						transaction.rollback();
					}
				}
				else {
					ok = false;
					transaction.rollback();
				}
			}
			else {
				ok = false;
				transaction.rollback();
			}
		}
		transactionManager.eliminaTransaccion();
		return ok;
	}

@SuppressWarnings("null")
public ArrayList<TCliente> clientesAlMenosNLibrosDeUnaEditorial(TLibroEditorial tLibroEditorial) {
		
		ArrayList<TCliente> clientes = null;
		if (tLibroEditorial != null) {
			TransactionManager transactionManager = TransactionManager.getInstance();
			Transaction transaction = transactionManager.nuevaTransaccion();
			if (transaction != null) {
				transaction.start();
				DAOEditorial daoEditorial = FactoriaIntegracion.getInstance().crearDAOEditorial();
				int id = tLibroEditorial.getIdEditorial();
				TEditorial tEditorial = daoEditorial.buscar(id);
				if (tEditorial != null) {
				FactoriaQuery factoriaQuery = FactoriaQuery.getInstance();
				clientes = factoriaQuery.generateClienteAlMenosNLibrosDeUnaEditorial().execute(tLibroEditorial);
				transaction.commit();
				}
				else 
					transaction.rollback();
			}
			else 
				transaction.rollback();
			transactionManager.eliminaTransaccion();
		}
		
	return clientes;
}

	
@SuppressWarnings("null")
public ArrayList<TCliente> clientesConLibrosDeUnGeneroYNPaginas(TGeneroPaginas tGeneroPaginas) {
		
		ArrayList<TCliente> clientes = null;
		if (tGeneroPaginas != null) {
			TransactionManager transactionManager = TransactionManager.getInstance();
			Transaction transaction = transactionManager.nuevaTransaccion();
			if (transaction != null) {
				transaction.start();
				FactoriaQuery factoriaQuery = FactoriaQuery.getInstance();
				clientes = factoriaQuery.generateClienteConLibrosDeUnGeneroYNPaginas().execute(tGeneroPaginas);
				transaction.commit();
			}
			else
				transaction.rollback();
			transactionManager.eliminaTransaccion();
		}
		return clientes;
	}

}