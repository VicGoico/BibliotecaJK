/**
 * 
 */
package Diseno.Negocio.Cliente;


public class TLibroEditorial {

	private int idEditorial;

	private int nLib;
	
	public TLibroEditorial(int idEditorial, int nLib) {
		this.idEditorial = idEditorial;
		this.nLib = nLib;
	}

	public int getIdEditorial() {
		return idEditorial;
	}

	public void setIdEditorial(int id) {
		this.idEditorial = id;
	}

	public int getnLib() {
		return nLib;
	}

	public void setnLib(int nLib) {
		this.nLib = nLib;
	}


}