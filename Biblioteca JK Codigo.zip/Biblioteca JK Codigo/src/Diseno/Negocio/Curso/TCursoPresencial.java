package Diseno.Negocio.Curso;

import java.util.Date;

import Diseno.Negocio.Centro.Centro;

public class TCursoPresencial extends TCurso {
	
	private int aula;
	private double tasa;
	
	public TCursoPresencial(int idCurso, String nombre, String descripcion, Date fechaInicio, Date fechaFinal, int numPlazas,
			double precio, int numMatriculados, int idCentro, Boolean activo, int aula, double tasa){
		super(idCurso, nombre, descripcion, fechaInicio, fechaFinal, numPlazas, precio, numMatriculados, idCentro, activo);
		this.aula = aula;
		this.tasa = tasa;
	}
	
	public TCursoPresencial(String nombre, String descripcion, Date fechaInicio, Date fechaFinal, int numPlazas,
			double precio, int numMatriculados, int idCentro, Boolean activo, int aula, double tasa){
		super(nombre, descripcion, fechaInicio, fechaFinal, numPlazas, precio, numMatriculados, idCentro, activo);
		this.aula = aula;
		this.tasa = tasa;
	}
	
	public int getAula() {
		return this.aula;
	}

	public double getTasa() {
		return this.tasa;
	}

	public void setAula(int aula) {
		this.aula = aula;
	}

	public void setTasa(double tasa) {
		this.tasa = tasa;
	}
}