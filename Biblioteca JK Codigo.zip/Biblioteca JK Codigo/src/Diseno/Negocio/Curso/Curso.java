package Diseno.Negocio.Curso;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.io.Serializable;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.NamedQueries;

import java.util.Collection;
import java.util.Date;
import Diseno.Negocio.Centro.Centro;
import Diseno.Negocio.Trabajador.Matricularse;

import javax.persistence.Version;
import javax.persistence.ManyToOne;
import javax.persistence.InheritanceType;
import javax.persistence.Inheritance;

@Inheritance(strategy = InheritanceType.JOINED)
@Entity
@NamedQueries({
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.findByid", query = "select obj from Curso obj where :id = obj.id "),
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.findBynombre", query = "select obj from Curso obj where :nombre = obj.nombre "),
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.findBydescripcion", query = "select obj from Curso obj where :descripcion = obj.descripcion "),
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.findByfechaInicio", query = "select obj from Curso obj where :fechaInicio = obj.fechaInicio "),
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.findByfechaFinal", query = "select obj from Curso obj where :fechaFinal = obj.fechaFinal "),
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.findBynumPlazas", query = "select obj from Curso obj where :numPlazas = obj.numPlazas "),
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.findByprecio", query = "select obj from Curso obj where :precio = obj.precio "),
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.findBynumMatriculados", query = "select obj from Curso obj where :numMatriculados = obj.numMatriculados "),
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.findByactivo", query = "select obj from Curso obj where :activo = obj.activo "),
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.findBycentro", query = "select obj from Curso obj where :centro = obj.centro "),
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.mostrarCurso", query = "select obj from Curso obj where obj.activo = 1"),
		@NamedQuery(name = "Diseno.Negocio.Curso.Curso.findByversion", query = "select obj from Curso obj where :version = obj.version ") })
		
public abstract class Curso implements Serializable {

	private static final long serialVersionUID = 0;
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	private String nombre;
	private String descripcion;
	private Date fechaInicio;
	private Date fechaFinal;
	private int numPlazas;
	private double precio;
	private int numMatriculados;
	private boolean activo;
	
	@ManyToOne
	private Centro centro;
	@OneToMany(mappedBy = "curso")
	private Collection<Matricularse> matricularse;
	@Version
	private int version;

	public Curso() {}
	
	public Curso(TCurso tCurso) {
		this.id = tCurso.getID();
		this.nombre = tCurso.getNombre();
		this.descripcion = tCurso.getDescripcion();
		this.fechaInicio = tCurso.getFechaInicio();
		this.fechaFinal = tCurso.getFechaFinal();
		this.numPlazas = tCurso.getNumPlazas();
		this.precio = tCurso.getPrecio();
		this.numMatriculados = tCurso.getNumMatriculados();
		this.activo = tCurso.getActivo();
	}

	public int getID() {
		return this.id;
	}

	public String getNombre() {
		return this.nombre;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public Date getFechaInicio() {
		return this.fechaInicio;
	}

	public Date getFechaFinal() {
		return this.fechaFinal;
	}

	public int getNumPlazas() {
		return this.numPlazas;
	}
	
	public double getPrecio() {
		return this.precio;
	}

	public int getNumMatriculados() {
		return this.numMatriculados;
	}
	
	public Centro getCentro(){
		return this.centro;
	}
	
	public Boolean getActivo() {
		return this.activo;
	}
	
	public Collection<Matricularse> getMatriculas(){
		return this.matricularse;
	}

	public void setID(int id) {
		this.id = id;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public void setFechaFinal(Date fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public void setNumPlazas(int numPlazas) {
		this.numPlazas = numPlazas;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public void setNumMatriculados(int numMatriculados) {
		this.numMatriculados = numMatriculados;
	}
	
	public void setCentro(Centro centro){
		this.centro = centro;
	}
	
	public void setActivo(Boolean activo) {
		this.activo = activo;
	}
	
	public void setMatriculas(Collection<Matricularse> matriculas){
		this.matricularse = matriculas;
	}

	public abstract TCurso EntityToTransfer();
	
	public abstract int calcularPrecioCurso();
}