package Diseno.Negocio.Curso;

import java.util.ArrayList;

public interface SACurso {
	
	public int altaCurso(TCurso tCurso);

	public int bajaCurso(int idCurso);

	public int actualizarCurso(TCurso tCurso);

	public TCurso buscarCurso(int id);

	public ArrayList<TCurso> mostrarCursos();
}