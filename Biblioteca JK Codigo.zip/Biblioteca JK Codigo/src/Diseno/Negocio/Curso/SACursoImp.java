package Diseno.Negocio.Curso;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Id;
import javax.persistence.LockModeType;
import javax.persistence.OptimisticLockException;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import Diseno.Negocio.Centro.Centro;


public class SACursoImp implements SACurso {
	
	/* Códigos de error
	 * -1: error por defecto; -2: error transaction
	 * -3: ya está activo; -4: el centro no existe
	 * -5: el centro no está activo; -6: la fecha de inicio es posterior a la fecha final
	 * -7: el tipo de curso no es compatible ; -8: El descuento debe ser inferior o igual a 100.
	 * -100: error base de datos
	 * */
	
	public int altaCurso(TCurso tCurso) {
		int id = -1;
		
		if(tCurso != null){
			Curso curso;
			if(tCurso instanceof TCursoADistancia)
				curso = new CursoADistancia((TCursoADistancia) tCurso);
			else curso = new CursoPresencial((TCursoPresencial) tCurso);
			
			try {
				EntityManagerFactory entityMF = Persistence.createEntityManagerFactory("BibliotecaJK");
				EntityManager entityM = entityMF.createEntityManager();
				if (entityM.getTransaction() != null) {
					entityM.getTransaction().begin();
					if(tCurso instanceof TCursoADistancia){
						if(((TCursoADistancia)tCurso).getDescuento() > 100){
							id = -8;
							entityM.getTransaction().rollback();
							entityM.close();
							entityMF.close();
							return id;
						}
					}
					if(tCurso.getFechaInicio().before(tCurso.getFechaFinal())){ //fechas dentro "del rango"
						TypedQuery<Curso> query = entityM.createNamedQuery("Diseno.Negocio.Curso.Curso.findBynombre", Curso.class).setParameter("nombre", tCurso.getNombre());
						if(query.getResultList().isEmpty()){ //si está vacía, buscamos el centro
							Centro centroLeido = entityM.find(Centro.class, tCurso.getIDCentro());
							if(centroLeido != null){ //centro existe, se puede meter
								if(centroLeido.getActivo()){
									//No ponemos el bloqueo porque al dar de alta un centro, tenemos que modificar el atributo
									//numCursosActivos del centro, y al hacer el commit, este aumentaría el número de versión.
									//entityM.lock(centroLeido, LockModeType.OPTIMISTIC_FORCE_INCREMENT);
									int cursosActivos = centroLeido.getNumCursosActivos() + 1; //al dar de alta, sumamos 1 al contador de cursos activos de un centro
									centroLeido.setNumCursosActivos(cursosActivos);
									centroLeido.getCurso().add(curso);
									curso.setCentro(centroLeido);
									entityM.persist(curso);
									entityM.getTransaction().commit();
									id = curso.getID();
								}
								else{
									id = -5;
									entityM.getTransaction().rollback();
								}
								
							}
							else{
								id = -4;
								entityM.getTransaction().rollback();
							}
						}
						else{ //Hay algún curso con ese nombre, intentar reactivación
							Curso cursoRes = query.getResultList().get(0);
							if(cursoRes.getActivo()){
								id = -3;
								entityM.getTransaction().rollback();
							}
							else{
								Centro centroLeido = entityM.find(Centro.class, tCurso.getIDCentro());
								if(centroLeido != null){
									if(centroLeido.getActivo()){
										//No ponemos el bloqueo porque al dar de alta un centro, tenemos que modificar el atributo
										//numCursosActivos del centro, y al hacer el commit, este aumentaría el número de versión.
										//entityM.lock(centroLeido, LockModeType.OPTIMISTIC_FORCE_INCREMENT);
										int cursosActivos = centroLeido.getNumCursosActivos() + 1;
										centroLeido.setNumCursosActivos(cursosActivos);
										cursoRes.setDescripcion(curso.getDescripcion());
										cursoRes.setFechaInicio(curso.getFechaInicio());
										cursoRes.setFechaFinal(curso.getFechaFinal());
										cursoRes.setCentro(centroLeido);
										cursoRes.setNumPlazas(curso.getNumPlazas());
										cursoRes.setPrecio(curso.getPrecio());
										cursoRes.setActivo(true);
										if(cursoRes instanceof CursoPresencial && curso instanceof CursoPresencial){
											CursoPresencial cursoPres = (CursoPresencial) curso;
											CursoPresencial cursoPresRes = (CursoPresencial) cursoRes;
											cursoPresRes.setAula(cursoPres.getAula());
											cursoPresRes.setTasa(cursoPres.getTasa());
											cursoRes = cursoPresRes;
											centroLeido.getCurso().add(cursoRes);
											entityM.getTransaction().commit();
											id = cursoRes.getID();
										}
										else if (cursoRes instanceof CursoADistancia && curso instanceof CursoADistancia){
											CursoADistancia cursoDist = (CursoADistancia) curso;
											CursoADistancia cursoDistRes = (CursoADistancia) cursoRes;
											cursoDistRes.setCorreo(cursoDist.getCorreo());
											cursoDistRes.setDescuento(cursoDist.getDescuento());
											cursoRes = cursoDistRes;
											centroLeido.getCurso().add(cursoRes);
											entityM.getTransaction().commit();
											id = cursoRes.getID();
										}
										else{
											id = -7;
											entityM.getTransaction().rollback();
										}
									}
									else{
										id = -5;
										entityM.getTransaction().rollback();
									}
								}
								else{
									id = -4;
									entityM.getTransaction().rollback();
								}
								
							}
						}
					}
					else{
						id = -6;
						entityM.getTransaction().rollback();
					}
					
				}
				else id = -2;
				
				entityM.close();
				entityMF.close();
				
			} catch (PersistenceException e) {
				id = -100;
				
			}
		}
		
		return id;
	}
	
	/* Códigos de error:
	 * -1: curso no existe; -2: error transaction
	 * -3: no está activo; -4: centro no existe
	 * -5: centro no activo; -6: no hay matrículas
	 * -100: error base de datos
	 * */
	
	public int bajaCurso(int idCurso) {
		try{
			EntityManagerFactory entityMF = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager entityM = entityMF.createEntityManager();
			EntityTransaction entityTransaction = entityM.getTransaction();
			
			if (entityTransaction != null){
				entityTransaction.begin();
				Curso curso = entityM.find(Curso.class, idCurso);
				if (curso != null){
					if (curso.getActivo()){
						if(curso.getNumMatriculados() == 0){
							curso.setActivo(false);
							Centro centroLeido = entityM.find(Centro.class, curso.getCentro().getIdCentro());
							if(centroLeido != null){
								if(centroLeido.getActivo()){
									int cursosActivos = centroLeido.getNumCursosActivos();
									cursosActivos--;
									centroLeido.setNumCursosActivos(cursosActivos);
									centroLeido.getCurso().remove(idCurso-1);
									entityTransaction.commit();
								}
								else{
									idCurso = -5;
									entityTransaction.rollback();
								}
							}
							else{
								idCurso = -4;
								entityTransaction.rollback();
							}
						}
						else{
							idCurso = -6;
							entityTransaction.rollback();
						}
					}
					else{
						idCurso = -3;
						entityTransaction.rollback();
					}
				}
				else{
					idCurso = -1;
					entityTransaction.rollback();
				}
			}
			
			else idCurso = -2;
		
			entityM.close();
			entityMF.close();
			
		} catch (PersistenceException ex){
			idCurso = -100;
		}
		
		return idCurso;
	}
	
	
	public TCurso buscarCurso(int id) {
		TCurso tCurso = null;
		
		try {
			EntityManagerFactory entityMF = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager entityM = entityMF.createEntityManager();
			EntityTransaction entityTransaction = entityM.getTransaction();
			
			if (entityTransaction != null){
				entityTransaction.begin();
				
				Curso curso = entityM.find(Curso.class, id);
				
				if(curso == null) entityTransaction.rollback();
				else {
					tCurso = curso.EntityToTransfer();
					entityTransaction.commit();
				}
			}
			
			entityM.close();
			entityMF.close();
		} 
		catch(PersistenceException ex) {}
		
		return tCurso;
	}
	
	/* Códigos de error:
	 * -1: error por defecto; -2: error transaction
	 * -3: el centro no existe -4: el centro no está activo;
	 * -5: curso existente y su id no coincide; -6: la fecha de inicio es posterior a la fecha final
	 * -7: curso no existe; -8: el número de matriculados supera al número total de plazas ;
	 * -9: el descuento debe ser inferior o igual a 100
	 * -100: error base de datos
	 * */
	
	public int actualizarCurso(TCurso tCurso) {
		int id = -1;
		if(tCurso != null){
			Curso curso;
			if(tCurso instanceof TCursoADistancia)
				curso = new CursoADistancia((TCursoADistancia) tCurso);
			else curso = new CursoPresencial((TCursoPresencial) tCurso);
			
			try{
				EntityManagerFactory entityMF = Persistence.createEntityManagerFactory("BibliotecaJK");
				EntityManager entityM = entityMF.createEntityManager();
				if(entityM.getTransaction() != null){
					entityM.getTransaction().begin();
					if(tCurso instanceof TCursoADistancia){
						if(((TCursoADistancia)tCurso).getDescuento() > 100){
							id = -9;
							entityM.getTransaction().rollback();
							entityM.close();
							entityMF.close();
							return id;
						}
					}
					Curso cursoRes = entityM.find(Curso.class, tCurso.getID());
					if(cursoRes != null){
						//No ponemos el bloqueo porque el atributo numCursosActivos de centro se modifica, y al hacer
						//el commit, el número de versión se modificaría.
						//entityM.lock(cursoRes, LockModeType.OPTIMISTIC_FORCE_INCREMENT);
						TypedQuery<Curso> query = entityM.createNamedQuery("Diseno.Negocio.Curso.Curso.findBynombre", Curso.class).setParameter("nombre", tCurso.getNombre());
						if(query.getResultList().isEmpty() || tCurso.getID() == query.getResultList().get(0).getID()){
							if(curso.getFechaInicio().before(curso.getFechaFinal())){ //si las fechas son correctas
								if(curso.getNumPlazas() >= cursoRes.getNumMatriculados()){
									Centro centroRes = entityM.find(Centro.class, tCurso.getIDCentro());
									if(centroRes != null){ //el centro existe
										if(centroRes.getActivo()){
											cursoRes.setNombre(curso.getNombre());
											cursoRes.setDescripcion(curso.getDescripcion());
											cursoRes.setFechaInicio(curso.getFechaInicio());
											cursoRes.setFechaFinal(curso.getFechaFinal());
											cursoRes.setNumPlazas(curso.getNumPlazas());
											cursoRes.setPrecio(curso.getPrecio());
											if(tCurso.getIDCentro() != cursoRes.getCentro().getIdCentro()){ //ids no coinciden, habrá que restar de la antigua y sumar a la nueva el numCursosActivos
												Centro antiguoCentro = entityM.find(Centro.class, cursoRes.getCentro().getIdCentro());
												int cursosActivosAntiguo = antiguoCentro.getNumCursosActivos();
												int cursosActivosNuevo = centroRes.getNumCursosActivos();
												cursosActivosAntiguo--;
												cursosActivosNuevo++;
												antiguoCentro.setNumCursosActivos(cursosActivosAntiguo);
												centroRes.setNumCursosActivos(cursosActivosNuevo);
												antiguoCentro.getCurso().remove(cursoRes.getID()-1);
												cursoRes.setCentro(centroRes);
											}
											if(cursoRes instanceof CursoPresencial){
												CursoPresencial cursoPres = (CursoPresencial) curso;
												CursoPresencial cursoPresRes = (CursoPresencial) cursoRes;
												cursoPresRes.setAula(cursoPres.getAula());
												cursoPresRes.setTasa(cursoPres.getTasa());
												cursoRes = cursoPresRes;
											}
											else{
												CursoADistancia cursoDist = (CursoADistancia) curso;
												CursoADistancia cursoDistRes = (CursoADistancia) cursoRes;
												cursoDistRes.setCorreo(cursoDist.getCorreo());
												cursoDistRes.setDescuento(cursoDist.getDescuento());
												cursoRes = cursoDistRes;
											}
											centroRes.getCurso().add(cursoRes);
											entityM.getTransaction().commit();
											id = cursoRes.getID();
										}
										else{
											id = -4;
											entityM.getTransaction().rollback();
										}
										
									}
									else{
										id = -3;
										entityM.getTransaction().rollback();
									}
								}
								else{
									id = -8;
									entityM.getTransaction().rollback();
								}
							}
							else{
								id = -6;
								entityM.getTransaction().rollback();
							}
						}
						else{
							id = -5;
							entityM.getTransaction().rollback();
						}
					}
					else{
						id = -7;
						entityM.getTransaction().rollback();
					}
				}
				else id = -2;
				
				entityM.close();
				entityMF.close();
				
			} catch(PersistenceException e){
				id = -100;
			}
		}
		
		return id;
	}
	
	public ArrayList<TCurso> mostrarCursos() {
		ArrayList<TCurso> cursos = new ArrayList<>();
		try{
			EntityManagerFactory entityMF = Persistence.createEntityManagerFactory("BibliotecaJK");
			EntityManager entityM = entityMF.createEntityManager();
			if(entityM.getTransaction() != null){
				entityM.getTransaction().begin();
				TypedQuery<Curso> query = entityM.createNamedQuery("Diseno.Negocio.Curso.Curso.mostrarCurso", Curso.class);
				for(Object i : query.getResultList()){ //iteramos sobre la lista para añadir cada elemento al arraylist
					cursos.add(((Curso)i).EntityToTransfer());
				}
				if(cursos.isEmpty()){ //si está vacía, el arraylist sería null, por tanto no muestra cursos.
					cursos = null;
					entityM.getTransaction().rollback();
				}
				else entityM.getTransaction().commit();
			}
			
			entityM.close();
			entityMF.close();
		} catch(PersistenceException e){
			cursos = null;
		}
		return cursos;
	}
}