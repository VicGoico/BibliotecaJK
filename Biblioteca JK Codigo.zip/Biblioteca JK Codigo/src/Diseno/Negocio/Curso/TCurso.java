/**
 * 
 */
package Diseno.Negocio.Curso;

import java.util.Date;

import Diseno.Negocio.Centro.Centro;

public class TCurso {

	private int idCurso;
	private String nombre;
	private String descripcion;
	private Date fechaInicio;
	private Date fechaFinal;
	private int numPlazas;
	private double precio;
	private int numMatriculados;
	private int idCentro;
	
	private Boolean activo;
	
	
	
	
	public int getID() {
		return this.idCurso;
	}

	public String getNombre() {
		return this.nombre;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public Date getFechaInicio() {
		return this.fechaInicio;
	}

	public Date getFechaFinal() {
		return this.fechaFinal;
	}

	public int getNumPlazas() {
		return this.numPlazas;
	}

	public double getPrecio() {
		return this.precio;
	}

	public int getNumMatriculados() {
		return this.numMatriculados;
	}
	
	public int getIDCentro(){
		return this.idCentro;
	}
	
	public Boolean getActivo() {
		return this.activo;
	}

	public void setID(int idCurso) {
		this.idCurso = idCurso;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public void setFechaFinal(Date fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public void setNumPlazas(int numPlazas) {
		this.numPlazas = numPlazas;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public void setNumMatriculados(int numMatriculados) {
		this.numMatriculados = numMatriculados;
	}
	
	public void setIDCentro(int idCentro){
		this.idCentro = idCentro;
	}
	
	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	public TCurso(int idCurso, String nombre, String descripcion, Date fechaInicio, Date fechaFinal, int numPlazas,
			double precio, int numMatriculados, int idCentro, Boolean activo) {
		this.idCurso = idCurso;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.fechaInicio = fechaInicio;
		this.fechaFinal = fechaFinal;
		this.numPlazas = numPlazas;
		this.precio = precio;
		this.numMatriculados = numMatriculados;
		this.idCentro = idCentro;
		this.activo = activo;
	}

	public TCurso(String nombre, String descripcion, Date fechaInicio, Date fechaFinal, int numPlazas, double precio,
			int numMatriculados, int idCentro, Boolean activo) {
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.fechaInicio = fechaInicio;
		this.fechaFinal = fechaFinal;
		this.numPlazas = numPlazas;
		this.precio = precio;
		this.numMatriculados = numMatriculados;
		this.idCentro = idCentro;
		this.activo = activo;
	}
}