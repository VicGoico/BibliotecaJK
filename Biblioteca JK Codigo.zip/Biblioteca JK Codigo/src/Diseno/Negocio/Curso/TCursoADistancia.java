/**
 * 
 */
package Diseno.Negocio.Curso;

import java.util.Date;

import Diseno.Negocio.Centro.Centro;

public class TCursoADistancia extends TCurso {
	
	private String correoEntregas;
	private int descuento;
	
	public TCursoADistancia(int idCurso, String nombre, String descripcion, Date fechaInicio, Date fechaFinal, int numPlazas,
			double precio, int numMatriculados, int idCentro, Boolean activo, String correoEntregas, int descuento){
		super(idCurso, nombre, descripcion, fechaInicio, fechaFinal, numPlazas, precio, numMatriculados, idCentro, activo);
		this.correoEntregas = correoEntregas;
		this.descuento = descuento;
	}
	
	public TCursoADistancia(String nombre, String descripcion, Date fechaInicio, Date fechaFinal, int numPlazas,
			double precio, int numMatriculados, int idCentro, Boolean activo, String correoEntregas, int descuento){
		super(nombre, descripcion, fechaInicio, fechaFinal, numPlazas, precio, numMatriculados, idCentro, activo);
		this.correoEntregas = correoEntregas;
		this.descuento = descuento;
	}
	
	public String getCorreo() {
		return this.correoEntregas;
	}

	public int getDescuento() {
		return this.descuento;
	}

	public void setCorreo(String correo) {
		this.correoEntregas = correo;
	}

	public void setDescuento(int descuento) {
		this.descuento = descuento;
	}
}