/**
 * 
 */
package Diseno.Negocio.Curso;

import javax.persistence.Entity;
import java.io.Serializable;
import javax.persistence.NamedQuery;
import javax.persistence.NamedQueries;

@Entity
@NamedQueries({
		@NamedQuery(name = "Diseno.Negocio.Curso.CursoADistancia.findByid", query = "select obj from CursoADistancia obj where :id = obj.id "),
		@NamedQuery(name = "Diseno.Negocio.Curso.CursoADistancia.findBycorreoEntregas", query = "select obj from CursoADistancia obj where :correoEntregas = obj.correoEntregas "),
		@NamedQuery(name = "Diseno.Negocio.Curso.CursoADistancia.findBydescuento", query = "select obj from CursoADistancia obj where :descuento = obj.descuento "),
		@NamedQuery(name = "Diseno.Negocio.Curso.CursoADistancia.findByversion", query = "select obj from CursoADistancia obj where :version = obj.version ") })
public class CursoADistancia extends Curso implements Serializable {

	private static final long serialVersionUID = 0;

	//private int id;
	private String correoEntregas;
	private int descuento;
	//private int version;
	
	public CursoADistancia() {}
	
	public CursoADistancia(TCursoADistancia tCursoDistancia) {
		super(tCursoDistancia);
		this.correoEntregas = tCursoDistancia.getCorreo();
		this.descuento = tCursoDistancia.getDescuento();
	}
	
	public String getCorreo() {
		return this.correoEntregas;
	}

	public int getDescuento() {
		return this.descuento;
	}

	public void setCorreo(String correo) {
		this.correoEntregas = correo;
	}

	public void setDescuento(int descuento) {
		this.descuento = descuento;
	}

	public TCursoADistancia EntityToTransfer() {
		return new TCursoADistancia(this.getID(), this.getNombre(), this.getDescripcion(), this.getFechaInicio(), this.getFechaFinal(),
				this.getNumPlazas(), this.getPrecio(), this.getNumMatriculados(), this.getCentro().getIdCentro(), this.getActivo(), this.correoEntregas, this.descuento);
	}

	@Override
	public int calcularPrecioCurso() {
		// TODO Auto-generated method stub
		return (int) (this.getPrecio() -(this.getPrecio() * (this.descuento/100)));
	}
}