/**
 * 
 */
package Diseno.Negocio.Curso;

import javax.persistence.Entity;
import java.io.Serializable;
import javax.persistence.NamedQuery;
import javax.persistence.NamedQueries;

@Entity
@NamedQueries({
		@NamedQuery(name = "Diseno.Negocio.Curso.CursoPresencial.findByid", query = "select obj from CursoPresencial obj where :id = obj.id "),
		@NamedQuery(name = "Diseno.Negocio.Curso.CursoPresencial.findByaula", query = "select obj from CursoPresencial obj where :aula = obj.aula "),
		@NamedQuery(name = "Diseno.Negocio.Curso.CursoPresencial.findBytasa", query = "select obj from CursoPresencial obj where :tasa = obj.tasa "),
		@NamedQuery(name = "Diseno.Negocio.Curso.CursoPresencial.findByversion", query = "select obj from CursoPresencial obj where :version = obj.version ") })
public class CursoPresencial extends Curso implements Serializable {

	private static final long serialVersionUID = 0;
	
	//private int id;
	private int aula;
	private double tasa;
	//private int version;
	
	public CursoPresencial() {}

	public int getAula() {
			return this.aula;
	}

	public double getTasa() {
		return this.tasa;
	}

	public void setAula(int aula) {
		this.aula = aula;
	}

	public void setTasa(double tasa) {
		this.tasa = tasa;
	}

	public CursoPresencial(TCursoPresencial tCursoPresencial) {
		super(tCursoPresencial);
		this.aula = tCursoPresencial.getAula();
		this.tasa = tCursoPresencial.getTasa();
	}

	public TCursoPresencial EntityToTransfer() {
		// begin-user-code
		// TODO Auto-generated method stub
		return new TCursoPresencial(this.getID(), this.getNombre(), this.getDescripcion(), this.getFechaInicio(), this.getFechaFinal(),
				this.getNumPlazas(), this.getPrecio(), this.getNumMatriculados(), this.getCentro().getIdCentro(), this.getActivo(), this.aula, this.tasa);
		// end-user-code
	}

	@Override
	public int calcularPrecioCurso() {
		// TODO Auto-generated method stub
		return (int) (this.getPrecio() + this.tasa);
	}
}